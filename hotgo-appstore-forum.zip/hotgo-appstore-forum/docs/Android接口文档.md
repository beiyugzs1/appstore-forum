# 应用商店 + 论坛 · Android 接口文档

> 对接方：Android 客户端 ｜ 后端：HotGo（GoFrame）+ MySQL ｜ 版本：v1

---

## 一、基本信息

| 项 | 值 |
| --- | --- |
| 接口根地址 | `https://a290f7a8ef50daa69.app.workbuddy.host` |
| C 端接口前缀 | `/api` |
| 完整示例 | `POST https://a290f7a8ef50daa69.app.workbuddy.host/api/site/login` |
| 传输协议 | HTTPS（生产环境请勿使用 HTTP） |
| 编码 | UTF-8 |
| 请求体格式 | `application/json`（**注意：不是 form-data**） |
| 时间格式 | `2026-10-12 17:30:00` |

### 统一响应结构

```json
{
  "code": 0,
  "message": "操作成功",
  "data": { },
  "timestamp": 1791798711,
  "traceID": "9b4871a2a3a541fd4073de5dbfd6c6f2"
}
```

- `code = 0` 表示成功，其余为失败。
- 分页接口的 `data` 中额外包含：`page`、`pageSize`、`pageCount`、`totalCount`、`list`。
- 分页请求参数统一为：`page`（第几页，从 1 开始）、`pageSize`（每页条数，最大 200）。

### 主要错误码

| code | 含义 | 客户端处理建议 |
| --- | --- | --- |
| 0 | 成功 | — |
| 61 | 登录身份已失效 | 用 refreshToken 调 `/api/site/refresh`；失败则回登录页 |
| -1 | 业务错误 | 直接 toast `message` |
| 51 | 参数校验失败 | 直接 toast `message` |

> `message` 为可直接展示给用户的中文文案。

---

## 二、鉴权：access + refresh 双令牌

### 令牌说明

| 令牌 | 有效期 | 用途 | 存放 |
| --- | --- | --- | --- |
| `accessToken` | **2 小时** | 调用所有需登录接口 | 内存 + 本地存储 |
| `refreshToken` | **30 天** | 换取新的 accessToken | 本地安全存储 |

accessToken 为 JWT 字符串；refreshToken 为 64 位随机串。

### 请求头

所有**需登录**的接口必须携带 accessToken，二选一：

```
X-Hotgo-Token: Bearer <accessToken>
```

> ⚠️ **请务必使用 `X-Hotgo-Token` 请求头**。
> 该部署环境的前置网关会覆盖 `Authorization` 请求头，使用 `Authorization` 会导致鉴权失败。
> （为兼容本地调试，服务端也支持 `Authorization: Bearer <token>`，但线上请用 `X-Hotgo-Token`。）

### 推荐接入流程

```
① 启动 → 检查本地 refreshToken
      ├─ 有 → 调 /api/site/refresh 换新 accessToken
      │        ├─ 成功 → 进入首页
      │        └─ 失败 → 清除本地令牌 → 登录页
      └─ 无 → 登录页
② 登录 /api/site/login → 保存 accessToken + refreshToken
③ 业务请求携带 X-Hotgo-Token
④ 收到 code=61 → 用 refreshToken 调 /api/site/refresh
        ├─ 成功 → 用新 accessToken 重发原请求（建议做 1 次重试）
        └─ 失败 → 清除令牌 → 登录页
⑤ 退出登录 → /api/site/logout（同时传 refreshToken）
```

> **令牌轮换**：每次调用 `/api/site/refresh` 都会返回**全新的 accessToken 和 refreshToken**，
> 旧的 refreshToken 立即失效。请务必用返回值覆盖本地存储，否则下次刷新会失败。

---

## 三、接口清单

### 1. 认证模块 `/api/site`

#### 1.1 账号密码登录

`POST /api/site/login` ｜ 免登录

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| account | string | 是 | 用户名 或 手机号 |
| password | string | 是 | 明文密码（HTTPS 传输） |

```json
{
  "code": 0,
  "message": "操作成功",
  "data": {
    "userId": 1,
    "username": "zhangsan",
    "nickname": "张三",
    "avatar": "",
    "isVip": true,
    "vipExpireAt": "2026-12-06 17:03:14",
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "1tBN8EfXEwDyRp5imuAr9IOG...",
    "expires": 7200
  }
}
```

> `expires` 单位为秒，表示 accessToken 剩余有效期，客户端可用于提前刷新。

#### 1.2 用户注册

`POST /api/site/register` ｜ 免登录

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| username | string | 是 | 4–20 位，唯一 |
| password | string | 是 | 6–32 位 |
| nickname | string | 否 | 昵称，不传则用用户名 |
| mobile | string | 否 | 手机号，唯一 |

返回：`{ "userId": 9, "username": "androiduser" }`

#### 1.3 刷新令牌

`POST /api/site/refresh` ｜ 免登录

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| refreshToken | string | 是 | 登录/上次刷新返回的 refreshToken |

返回：`{ "accessToken": "...", "refreshToken": "...", "expires": 7200 }`（**新的两个令牌**）

#### 1.4 退出登录

`POST /api/site/logout` ｜ 需登录

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| refreshToken | string | 否 | 传入则同时吊销刷新令牌 |

> 调用后当前 accessToken 立即失效。客户端应清除本地全部令牌。

---

### 2. 用户模块 `/api/user`

#### 2.1 获取个人资料

`GET /api/user/info` ｜ 需登录

```json
{
  "id": 1, "username": "zhangsan", "nickname": "张三", "avatar": "",
  "mobile": "13800000001", "email": "zhangsan@example.com", "gender": 1,
  "isVip": true, "vipPlanId": 1, "vipPlanName": "月度会员",
  "vipExpireAt": "2026-12-06 17:03:14", "inviteCode": "A1B2C3",
  "lastLoginAt": "2026-10-12 17:03:14", "createdAt": "2026-10-12 16:50:00"
}
```

#### 2.2 修改个人资料

`POST /api/user/updateProfile` ｜ 需登录

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| nickname | string | 昵称 |
| avatar | string | 头像 URL |
| gender | int | 0未知 / 1男 / 2女 |
| email | string | 邮箱 |
| mobile | string | 手机号（唯一） |

#### 2.3 修改密码

`POST /api/user/updatePwd` ｜ 需登录

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| oldPassword | string | 是 | 原密码 |
| newPassword | string | 是 | 6–32 位 |

#### 2.4 我的封禁 / 禁言状态

`GET /api/user/banStatus` ｜ 需登录

响应示例：

```json
{
  "code": 0,
  "data": {
    "banned": false,
    "muted": true,
    "globalBan": { "boardId": 0, "type": 2, "reason": "发布广告", "expireAt": "2026-11-01 00:00:00" },
    "boardBans": []
  }
}
```

| 字段 | 说明 |
| --- | --- |
| banned | 是否被封禁（禁止登录） |
| muted | 是否被禁言（可登录，禁止发帖/评论/举报） |
| globalBan | 全局处罚详情；`expireAt` 为 `null` 表示永久 |
| boardBans | 版块维度的处罚列表（版主操作的处罚） |

> **建议**：App 启动与进入发帖页时调用一次，据此禁用发帖按钮并展示处罚原因与解封时间。

---

### 3. VIP 卡密模块 `/api/vip`

#### 3.1 获取 VIP 套餐列表

`GET /api/vip/planList` ｜ 免登录

```json
{
  "list": [
    { "id": 1, "name": "月度会员", "type": 1, "durationDays": 30,
      "price": 19.9, "originalPrice": 29.9, "description": "30天VIP权益" }
  ]
}
```

`type`：1 月卡 / 2 季卡 / 3 年卡

#### 3.2 卡密激活 VIP

`POST /api/vip/activate` ｜ 需登录

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| cardNo | string | 是 | 卡号 |
| cardPwd | string | 是 | 卡密 |

```json
{
  "planName": "月度会员",
  "durationDays": 30,
  "beforeExpireAt": "2026-11-06 17:03:14",
  "afterExpireAt": "2026-12-06 17:03:14"
}
```

> **时长叠加规则**：若当前 VIP 未过期，从「当前到期时间」顺延；已过期则从「当前时间」开始计算。
> 服务端使用行锁 + 事务，同一张卡并发激活只会成功一次。

#### 3.3 我的激活记录

`GET /api/vip/myCardLog?page=1&pageSize=10` ｜ 需登录

返回 `list`，单项字段：`id`、`cardNo`、`planName`、`durationDays`、`afterExpireAt`、`createdAt`

---

### 4. 应用模块 `/api/app`

#### 4.1 应用分类

`GET /api/app/categoryList` ｜ 免登录

返回 `{ "list": [{ "id": 1, "name": "社交聊天", "icon": "" }] }`

#### 4.2 应用列表

`GET /api/app/list` ｜ 免登录

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| page | int | 页码，默认 1 |
| pageSize | int | 每页条数，默认 10 |
| categoryId | int64 | 分类筛选，可选 |
| keyword | string | 应用名/包名模糊搜索，可选 |

> 仅返回 **审核通过且已上架** 的应用。

列表项字段：`id`、`categoryId`、`categoryName`、`name`、`logo`、`packageName`、`versionName`、`versionCode`、`fileSize`、`description`、`developerName`、`downloadCount`、`vipOnly`

其中 `vipOnly=1` 表示**会员专属应用**，App 可在卡片上加「会员」角标（是否可下载以**详情接口**返回的 `vipRequired` 为准）。

#### 4.3 应用详情

`GET /api/app/detail?id=1` ｜ 免登录（**带 token 时会识别会员身份**）

返回字段：`fileMd5`、`screenshots`（字符串数组）、`downloadUrl`、`developerId`、`viewCount`、`updatedAt`，以及：

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| vipOnly | int | 是否**会员专属**应用：0 免费 / 1 会员专属 |
| vipRequired | bool | 当前用户是否需要开通会员才能下载 |
| downloadUrl | string | **非会员查看会员专属应用时为空字符串** |

> 每次调用会使 `viewCount` +1。
>
> **App 建议**：`vipRequired=true` 时把下载按钮替换为「开通会员下载」，不要直接发起下载请求。

#### 4.4 开发者提交应用

`POST /api/app/submit` ｜ 需登录

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| categoryId | int64 | 是 | 分类 ID |
| name | string | 是 | 应用名称 |
| packageName | string | 是 | 包名 |
| versionName | string | 是 | 版本名，如 `1.0.0` |
| downloadUrl | string | 是 | APK 下载地址 |
| logo | string | 否 | 图标 URL |
| versionCode | int | 否 | 版本号 |
| fileSize | int64 | 否 | 安装包字节数 |
| fileMd5 | string | 否 | 安装包 MD5 |
| description | string | 否 | 应用简介 |
| screenshots | []string | 否 | 截图 URL 数组 |

返回 `{ "id": 9 }`。提交后 `auditStatus=0`（待审核），需后台审核通过并上架后才能出现在 `/api/app/list`。

> 同一开发者、同一包名，若已存在待审核记录会拒绝重复提交。

#### 4.5 我提交的应用

`GET /api/app/myList?page=1&pageSize=10` ｜ 需登录

列表项：`id`、`name`、`logo`、`packageName`、`versionName`、`auditStatus`、`auditRemark`、`shelfStatus`、`downloadCount`、`createdAt`

`auditStatus`：0 待审核 / 1 已通过 / 2 已驳回（`auditRemark` 为驳回原因）

---

### 5. 论坛模块 `/api/forum`

#### 5.1 版块列表

`GET /api/forum/boardList` ｜ 免登录（**带 token 时会识别会员身份**）

```json
{
  "code": 0,
  "data": {
    "list": [
      { "id": 1, "name": "综合讨论", "icon": "", "description": "", "postCount": 1, "vipOnly": 0, "accessible": true },
      { "id": 6, "name": "会员专区", "icon": "", "description": "", "postCount": 0, "vipOnly": 1, "accessible": false }
    ]
  }
}
```

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| vipOnly | int | 是否**会员专享**版块：0 公开 / 1 会员专享 |
| accessible | bool | 当前用户是否可访问。非会员访问会员专享版块时为 `false` |

> **App 建议**：`vipOnly=1 && accessible=false` 时正常展示版块（带「会员」角标），点击后引导开通会员，不要直接隐藏版块。
> 会员专享版块的**帖子列表、帖子详情、评论列表、发帖、评论**都会做服务端校验，非会员调用会返回 `code=-1` 与「XX为会员专享版块，开通会员后即可访问」。

#### 5.2 帖子列表

`GET /api/forum/postList` ｜ 免登录

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| page / pageSize | int | 分页 |
| boardId | int64 | 版块筛选 |
| userId | int64 | 作者筛选 |
| keyword | string | 标题关键词 |

> 仅返回 **已通过审核且正常** 的帖子。

列表项：`id`、`boardId`、`boardName`、`userId`、`userNickname`、`userAvatar`、`title`、`summary`、`cover`、`viewCount`、`likeCount`、`commentCount`、`isTop`、`isEssence`、`createdAt`

#### 5.3 帖子详情

`GET /api/forum/postDetail?id=1` ｜ 免登录

新增字段：`content`（正文）、`images`（字符串数组）。调用会使 `viewCount` +1。

#### 5.4 发布帖子

`POST /api/forum/publishPost` ｜ 需登录

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| boardId | int64 | 是 | 版块 ID |
| title | string | 是 | 标题 |
| content | string | 是 | 正文 |
| images | []string | 否 | 图片 URL 数组 |

返回 `{ "id": 9 }`，帖子进入待审核状态，审核通过后才对其他用户可见。

#### 5.5 评论列表

`GET /api/forum/commentList?postId=1&page=1&pageSize=20` ｜ 免登录

列表项：`id`、`postId`、`pid`（父评论 ID，0 为一级评论）、`userId`、`userNickname`、`userAvatar`、`content`、`likeCount`、`createdAt`

#### 5.6 发表评论 / 回复

`POST /api/forum/publishComment` ｜ 需登录

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| postId | int64 | 是 | 帖子 ID |
| content | string | 是 | 评论内容，≤1000 字 |
| pid | int64 | 否 | 回复的父评论 ID，0 或省略表示一级评论 |

返回 `{ "id": 11 }`，评论进入待审核状态。

---

### 6. 举报模块 `/api/report`

#### 6.1 提交举报

`POST /api/report/submit` ｜ 需登录

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| targetType | int | 是 | 1 帖子 / 2 评论 / 3 用户 / 4 应用 |
| targetId | int64 | 是 | 被举报对象 ID |
| reason | string | 是 | 举报原因，如「广告营销」 |
| description | string | 否 | 补充说明 |
| images | []string | 否 | 凭证图片 URL 数组 |

返回 `{ "id": 6 }`。同一用户对同一对象的重复举报（未处理状态下）会被拒绝。

---

### 7. 版主工作台模块 `/api/moderator`

> **前提**：以下接口全部需要登录，且调用者必须是**该版块的版主**并拥有对应权限。
> 权限由后台在「论坛管理 → 版主管理」中授予，采用**权限位**组合：
>
> | 位值 | 权限 | 位值 | 权限 |
> | --- | --- | --- | --- |
> | 1 | 审核帖子 | 16 | 删除帖子 |
> | 2 | 审核评论 | 32 | 删除评论 |
> | 4 | 置顶帖子 | 64 | 封禁本版用户 |
> | 8 | 加精帖子 | | |
>
> 无权限时统一返回 `code = -1` 且提示「你没有「XX」权限」。

#### 7.1 我管理的版块列表

`GET /api/moderator/myBoards` ｜ 需登录

```json
{ "code": 0, "data": { "list": [ { "boardId": 1, "boardName": "综合讨论", "permissions": 17 } ] } }
```

App 可用它判断是否展示「版主工作台」入口。

#### 7.2 查询我在指定版块的权限

`GET /api/moderator/permission?boardId=1` ｜ 需登录

返回 `{ "isModerator": true, "permissions": 17 }`。前端可据此**按位**控制按钮显隐：

```kotlin
fun hasPerm(perms: Int, bit: Int) = (perms and bit) == bit
// hasPerm(17, 16) -> true  （可删帖）
// hasPerm(17, 4)  -> false （不可置顶）
```

#### 7.3 本版待审帖子

`GET /api/moderator/pendingPosts?boardId=1&page=1&perPage=10` ｜ 权限：审核帖子

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| boardId | int64 | 是 | 版块 ID |
| page / perPage | int | 否 | 分页 |

返回列表字段：`id / boardId / userId / userNickname / title / summary / images / createdAt`。

#### 7.4 本版待审评论

`GET /api/moderator/pendingComments?boardId=1&page=1&perPage=10` ｜ 权限：审核评论

返回字段：`id / postId / postTitle / userId / userNickname / content / createdAt`。

#### 7.5 审核帖子

`POST /api/moderator/auditPost` ｜ 权限：审核帖子

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| id | int64 | 是 | 帖子 ID |
| auditStatus | int | 是 | 1 通过 / 2 驳回 |
| auditRemark | string | 驳回时必填 | 审核备注 |

#### 7.6 审核评论

`POST /api/moderator/auditComment` ｜ 权限：审核评论

参数同上（`id` 为评论 ID）。

#### 7.7 置顶 / 取消置顶

`POST /api/moderator/topPost` ｜ 权限：置顶帖子

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| id | int64 | 是 | 帖子 ID |
| isTop | int | 是 | 0 取消 / 1 置顶 |

#### 7.8 加精 / 取消加精

`POST /api/moderator/essencePost` ｜ 权限：加精帖子

参数为 `id` + `isEssence`（0/1）。

#### 7.9 版主删帖

`POST /api/moderator/deletePost` ｜ 权限：删除帖子

参数 `{ "id": 10 }`。删除为**软删除**，帖子内容不会真正从库中消失。

#### 7.10 版主删评论

`POST /api/moderator/deleteComment` ｜ 权限：删除评论

参数 `{ "id": 5 }`。

#### 7.11 版主封禁本版用户

`POST /api/moderator/banUser` ｜ 权限：封禁本版用户

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| boardId | int64 | 是 | 版块 ID（自己管理的版块） |
| userId | int64 | 是 | 被封禁用户 ID |
| type | int | 否 | 1 封禁 / 2 禁言，默认 2 禁言 |
| expireAt | string | 否 | 到期时间 `yyyy-MM-dd HH:mm:ss`，留空为永久 |
| reason | string | 否 | 原因，默认「违反版块规定」 |

> 版主只能授予**本版块范围**的处罚，不能全局封禁用户；也不能封禁自己。

---

### 8. 运营模块 `/api/ops`（全部免登录）

App 启动与运行期所需的运营能力：读取 App 配置、公告、版本更新、广告。

#### 8.1 获取 App 配置

`GET /api/ops/androidConfig` ｜ 免登录

返回 `group=android` 的全部配置键值对（27 项），含：

| 分类 | 主要 key |
| --- | --- |
| 版本与更新 | `androidForceUpdate`、`androidMinVersionCode`、`androidUpdateStrategy`、`androidUpdateTitle`、`androidUpdateTip` |
| 客服与联系 | `androidKfPhone`、`androidKfEmail`、`androidKfUrl`、`androidKfQrcode`、`androidContactQQ`、`androidContactWechat`、`androidFeedbackUrl` |
| 运营开关 | `androidMaintenanceSwitch`、`androidRegisterSwitch`、`androidGuestViewSwitch`、`androidPostSwitch`、`androidCommentSwitch`、`androidDownloadSwitch` |
| 协议合规 | `androidUserAgreement`、`androidPrivacyPolicy`、`androidChildPolicy`、`androidComplianceIntro`（富文本 HTML） |
| 公告 | `androidAnnouncementSwitch`、`androidAnnouncementPopup`、`androidAnnouncementPopupId` |

#### 8.2 公告列表

`GET /api/ops/announcement/list?page=1&pageSize=10&type=1` ｜ 免登录

仅返回**已发布、已到发布时间、未过期**的公告，置顶优先。

列表项：`id`、`title`、`type`(1通知/2公告/3活动)、`summary`、`cover`、`target`(0无/1站内/2外链)、`linkUrl`、`isTop`、`isPopup`、`viewCount`、`publishAt`

#### 8.3 公告详情

`GET /api/ops/announcement/detail?id=1` ｜ 免登录

额外返回 `content`（富文本 HTML）；每次调用 `viewCount` +1。

#### 8.4 检查版本更新

`GET /api/ops/versionCheck?platform=1&versionCode=1&channel=` ｜ 免登录

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| platform | int | 是 | 1 Android / 2 iOS |
| versionCode | int | 是 | 当前 App 版本号 |
| channel | string | 否 | 渠道，先精确匹配再回退通用渠道 |

返回：`hasUpdate`、`forceUpdate`、`versionName`、`versionCode`、`title`、`changelog`、`downloadUrl`、`fileSize`、`fileMd5`、`publishAt`

强制更新判定（任一满足即 `forceUpdate=true`）：版本自身 `forceUpdate=1`、当前版本低于版本记录的 `minSupportCode`、当前版本低于全局配置 `androidMinVersionCode` 且 `androidForceUpdate` 开启。版本记录开启灰度时按比例随机下发。

#### 8.5 按广告位取广告

`GET /api/ops/ad/list?code=home_banner&platform=android` ｜ 免登录

返回该广告位下**启用中、处于投放期**的素材列表（`startAt` 为空视为立即生效，`endAt` 为空视为长期有效），按权重降序轮播。

列表项：`id`、`positionCode`、`title`、`type`(1图片/2视频/3文字/4H5)、`image`、`videoUrl`、`text`、`linkType`(0无/1站内/2外链)、`linkUrl`、`appId`

#### 8.6 广告曝光 / 点击上报

`POST /api/ops/ad/report` ｜ 免登录

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| id | int64 | 是 | 广告 ID |
| event | string | 是 | `view` 曝光 / `click` 点击 |

---

## 四、Android 接入示例（OkHttp 拦截器）

```kotlin
class AuthInterceptor(private val tokenStore: TokenStore) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val req = chain.request().newBuilder()
            .header("Content-Type", "application/json")
            .apply {
                tokenStore.accessToken?.let {
                    // 关键：使用 X-Hotgo-Token，不要用 Authorization
                    header("X-Hotgo-Token", "Bearer $it")
                }
            }
            .build()
        val resp = chain.proceed(req)

        // accessToken 过期 → 刷新一次并重试
        if (isTokenExpired(resp)) {
            synchronized(this) {
                val newToken = RefreshApi.syncRefresh(tokenStore.refreshToken) ?: run {
                    tokenStore.clear(); return@run null
                }
                tokenStore.update(newToken)          // 务必覆盖 refreshToken
                return chain.proceed(
                    chain.request().newBuilder()
                        .header("X-Hotgo-Token", "Bearer ${newToken.accessToken}")
                        .build()
                )
            }
        }
        return resp
    }

    private fun isTokenExpired(resp: Response): Boolean {
        // 读取 body 中的 code == 61（需 peekBody 后重新构造 Response）
        return false
    }
}
```

### 对接注意事项

1. **必须带 `Content-Type: application/json`**，请求体为 JSON 而非表单。
2. **鉴权头用 `X-Hotgo-Token`**，值为 `Bearer <accessToken>`。
3. **刷新令牌要覆盖本地 refreshToken**（令牌轮换，旧值立即失效）。
4. accessToken 过期返回 `code=61`，不要直接跳登录页，先尝试刷新。
5. 图片/图标/截图字段传的是 **URL 字符串**，需先通过后台上传接口拿到 URL 再提交（也可先用第三方图床）。
6. 应用 `downloadUrl` 同样为 URL 字符串，客户端可直接下载。
7. 所有列表接口的 `list` 在没有数据时返回 `[]`，不会返回 `null`。
8. **发帖与评论会经过敏感词过滤**（后台「论坛管理 → 敏感词管理」维护词库），命中后有三种结果：
   - **替换**：内容中的命中词被替换为等长掩码（如 `加微信` → `***`）后正常发布；
   - **拦截**：直接返回 `code=-1`，提示「内容包含违规信息（XX），已被禁止发布」，App 应保留用户输入让其修改；
   - **转待审**：内容照常提交，但会进入待审核状态，需版主或管理员审核通过后才会公开可见。
   > 建议 App 在发帖页对 `code=-1` 且 message 含「违规信息」时，用红色提示条展示，不要清空编辑器。
9. **封禁与禁言会在多个入口拦截**，App 需要分别处理：
   - 登录被拒：`code=-1`，message 形如「你的账号已被封禁：原因，解封时间：xxx」→ 提示用户并**不要**保存 token；
   - 发帖 / 评论 / 举报被拒：`code=-1`，message 形如「你已被禁言：原因」→ 提示用户，可同时调 `/api/user/banStatus` 展示解封时间；
   - 令牌刷新被拒：被封禁的账号 refresh 也会失败，需清空本地登录态。
10. **版主工作台**接口在无权限时返回 `code=-1` 且 message 为「你没有「XX」权限」。App 应通过 `/api/moderator/myBoards` 判断是否展示工作台入口，避免让普通用户进入后到处报错。
11. 版主对内容的操作（审核/置顶/加精/删除）**只对自己管理的版块生效**，跨版块操作会被拒绝。
12. **会员权益有两处**，App 需分别处理：
    - **会员专享版块**（`board.vipOnly=1`）：非会员**浏览/发帖/评论都会被拒**，错误提示含「会员专享版块」；版块列表用 `accessible` 字段区分可访问性，建议保留展示并加「会员」角标引导开通。
    - **会员专属应用**（`app.vipOnly=1`）：非会员**拿不到下载地址**（`downloadUrl` 为空且 `vipRequired=true`），下载按钮应替换为「开通会员下载」。
    > 会员身份以服务端 `vip_expire_at` 实时判定，**到期即失效**；App 可用 `/api/user/info` 的 `isVip` 与 `vipExpireAt` 展示会员状态。
13. **免登录接口也会识别登录态**：`/api/forum/boardList`、`/api/forum/postList`、`/api/app/list`、`/api/app/detail` 等浏览类接口虽免登录，但**携带有效 token 时会识别会员身份**。因此会员用户在这些接口里能看到 `accessible=true` / 拿到下载地址；不带头则按游客处理。App 应在启动后尽早恢复本地 token。
