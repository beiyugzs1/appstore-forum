# 应用商店 + 论坛 后台管理系统 · 说明文档

> 基于 HotGo v2.0（Go + GoFrame + Vue3 + Naive UI）改造而成。
> 后台面向运营/审核人员，`/api` 面向 Android 客户端。

---

## 一、访问地址与账号

| 项 | 值 |
| --- | --- |
| 后台管理地址 | **https://a290f7a8ef50daa69.app.workbuddy.host/admin** |
| Android 接口根地址 | https://a290f7a8ef50daa69.app.workbuddy.host/api |
| 接口文档 | 见 `Android接口文档.md` |
| Swagger | https://a290f7a8ef50daa69.app.workbuddy.host/swagger |

### 后台账号

| 账号 | 密码 | 角色 |
| --- | --- | --- |
| **admin** | **123456** | 超级管理员（全部权限） |
| test | 123456 | 管理员 |
| ameng / abai / asong | 123456 | 租户 / 商家 / 用户 |

### C 端演示账号（Android 登录用）

| 账号 | 密码 | 说明 |
| --- | --- | --- |
| zhangsan | 123456 | 月度会员 |
| lisi | 123456 | 年度会员 |
| sunqi | 123456 | 季度会员 |
| wangwu / zhaoliu / zhouba | 123456 | 普通用户 |
| wujiu | 123456 | 会员已过期（用于测试过期逻辑） |

> 登录验证码已关闭（`hg_sys_config.loginCaptchaSwitch = 0`）。
> 如需恢复：后台「系统设置 → 配置管理 → 登录验证码开关」。

---

## 二、后台功能模块

精简后的菜单（9 个一级菜单，已移除开发工具、插件应用、系统监控、关于、文档中心等无关功能）：

| 菜单 | 子菜单 | 说明 |
| --- | --- | --- |
| 数据看板 | 看板首页 | 用户/应用/帖子/卡密统计 + 4 项待办（可点击直达） |
| 用户管理 | 用户列表 | C 端用户、VIP 状态、重置密码、启用/禁用、**封禁/禁言入口** |
| | 封禁禁言 | 用户**封禁**（禁登录）与**禁言**（可登录禁发言），支持全局/指定版块范围，支持到期时间与自动解除、手动解除 |
| VIP管理 | 套餐管理 | 月/季/年卡套餐（时长、售价、上下架） |
| | 卡密管理 | 按套餐批量生成卡密、复制卡号、禁用/删除 |
| | 激活记录 | 卡密激活流水（激活人、前后到期时间、IP） |
| 应用管理 | 应用分类 | 应用分类维护 |
| | 应用列表 | 应用录入、**审核（通过/驳回）**、**上下架**、来源区分 |
| 论坛管理 | 版块管理 | 论坛版块维护 |
| | 帖子管理 | 帖子审核、置顶/加精、隐藏、删除（连带清理评论） |
| | 评论管理 | 评论审核、隐藏、删除 |
| | 举报管理 | 举报处理（已处理/驳回 + 处理备注） |
| | **版主管理** | **任命版主 + 权限包配置**（审核帖子/审核评论/置顶/加精/删帖/删评论/封禁本版用户），一个版块可设多个版主 |
| | **敏感词管理** | 敏感词库维护，策略分**替换 / 拦截 / 转待审**三种，发帖与评论自动生效 |
| 运营管理 | 公告管理 | App 端公告（通知/公告/活动），支持置顶、弹窗、跳转、定时发布与过期 |
| | 版本更新 | App 版本发布记录（版本号/更新日志/下载地址/强制更新/灰度比例/最低支持版本） |
| | 广告管理 | **广告位**（App 按编码拉取）→ **广告素材**（图片/视频/文字/H5，投放起止时间、权重、曝光/点击统计） |
| 权限管理 | ~~菜单权限 / 角色权限~~ | **已移除**（见下方说明） |
| 系统设置 | 配置管理 / 字典管理 | 系统参数、数据字典 |
| | **Android 配置** | **App 端运营配置**：版本与更新策略、客服联系信息、运营开关、协议合规、公告开关 |
| | **操作日志** | **后台操作审计流水**（操作人/接口/入参/耗时/结果），可一键只看写操作 |
| 后台账号 | 后台账号 | 后台管理员账号 |
| 附件管理 | 附件列表 | 应用图标/截图等素材上传管理 |

**审核交互**：不做独立审核页，直接在列表页内完成——列表带「审核状态」筛选，行内提供「审核」按钮（弹窗选通过/驳回 + 备注），驳回与审核备注为强校验。

**版主体系（市场常见做法）**：版主是**社区用户**（非后台管理员），由后台在「版主管理」里任命并勾选权限；版主在 App 内通过 `/api/moderator/*` 接口管理自己版块的内容。权限采用**权限位图**存储，前端按位控制按钮显隐。

### 关于「权限管理」为何移除

本产品的身份体系只有三类，**不需要后台多角色 RBAC**：

| 身份 | 说明 | 权限载体 |
| --- | --- | --- |
| **管理员** | 后台唯一账号（admin） | 超级管理员，拥有全部后台权限 |
| **版主** | C 端用户，一个版块可有多个版主，一个用户可身兼多个版块 | `hg_forum_moderator` 权限位图（按版块授权） |
| **用户 / 会员** | C 端用户；会员是「用户 + VIP 未过期」 | `hg_user.vip_expire_at`（到期即自动失效） |

由于管理员唯一且为超管（鉴权走 `VerifySuperId` 直接放行），原「权限管理」菜单与页面已删除，同时清理了 6 个演示管理员账号与无关演示角色（仅保留 `超级管理员` / `管理员` 两个基础角色）。
**后端 RBAC 能力（casbin + 角色/菜单接口）保留未动**，将来若需增加运营子账号，随时可恢复配置入口。

### 会员专享能力

会员 = 用户 + 有效 VIP。系统在两处落地会员权益：

| 场景 | 字段 | 行为 |
| --- | --- | --- |
| 会员版块 | `hg_forum_board.vip_only` | 开启后非会员**无法浏览版块帖子、无法发帖评论**，版块列表返回 `accessible=false` 供 App 展示开通引导 |
| 会员应用 | `hg_application.vip_only` | 开启后非会员**拿不到下载地址**（`downloadUrl` 置空 + `vipRequired=true`） |

> 会员判定为运行时实时比对 `vip_expire_at > now()`，**到期自动失效**，无需定时任务。

---

## 三、技术栈与设计系统

| 组件 | 版本 |
| --- | --- |
| 后端 | Go 1.24.4 + GoFrame v2.10.3 |
| 前端 | Vue3 + Vite + TypeScript + Naive UI |
| 数据库 | MySQL 8 |
| 缓存 | Redis 7（`db 2`） |

设计系统（已在主题中落地）：

| 项 | 值 | 生效位置 |
| --- | --- | --- |
| 主色 | `#5046E5` | `web/src/settings/designSetting.ts`、`web/src/styles/var.less`、`web/src/App.vue` |
| 信号色/成功色 | `#10B981` | `web/src/App.vue`（Naive UI `successColor`） |
| 圆角 | `12px` | `web/src/App.vue`（`borderRadius`） |

---

## 四、数据库

新增 10 张业务表（前缀 `hg_`，结构见 `server/storage/data/appstore_forum.sql`）：

| 表 | 用途 |
| --- | --- |
| `hg_user` | C 端用户（含 VIP 套餐与到期时间） |
| `hg_vip_plan` | VIP 套餐 |
| `hg_vip_card` | 卡密 |
| `hg_vip_card_log` | 卡密激活记录 |
| `hg_app_category` | 应用分类 |
| `hg_application` | 应用（审核 + 上下架 + 下载量） |
| `hg_forum_board` | 论坛版块 |
| `hg_forum_post` | 帖子 |
| `hg_forum_comment` | 评论 |
| `hg_report` | 举报 |

演示数据见 `server/storage/data/appstore_forum_demo.sql`；菜单调整见 `server/storage/data/appstore_forum_menu.sql`。

**内容治理能力补充 3 张表**（结构见 `server/storage/data/moderation_v1.sql`，菜单见 `moderation_v1_menu.sql`）：

| 表 | 用途 |
| --- | --- |
| `hg_forum_moderator` | 论坛版主（版块↔用户多对多 + 权限位图 + 任命人/任命时间） |
| `hg_user_ban` | 用户封禁禁言（type 封禁/禁言 × scope 全局/版块，含原因、期限、操作人） |
| `hg_sensitive_word` | 敏感词库（词、分类、处理策略、替换字符） |

> 版主表与敏感词表因存在唯一键约束，删除采用**物理删除**（避免软删后重复添加冲突）；封禁记录采用软删。

**会员专享字段**（脚本 `server/storage/data/simplify_permission.sql` 同批次已建，字段由 `ALTER TABLE` 添加）：

| 表 | 字段 | 说明 |
| --- | --- | --- |
| `hg_forum_board` | `vip_only` | 是否会员专享版块：0 公开 / 1 会员专享 |
| `hg_application` | `vip_only` | 是否会员专属应用：0 免费 / 1 会员专属 |

**迭代废弃代码清理**（脚本 `server/storage/data/cleanup_deprecated.sql`）：删除了框架自带的演示模块（代码生成 CRUD 演示、树表演示、测试分类）、**代码生成器**与**示例插件 hgexample**，共清理 6 张表，并清理了失效的 casbin 策略与孤儿菜单关联。数据库表数由 49 → 46。

连接信息：

```
地址：127.0.0.1:3306    库名：hotgo    用户：hotgo    密码：hg123456.
```

---

## 五、目录结构

```
/workspace/hotgo/
├── server/                                   # Go 服务端
│   ├── hotgo                                 # 编译产物（含内嵌前端资源）
│   ├── start.sh                              # 启动脚本（确保 MySQL/Redis 就绪）
│   ├── api/admin/<module>/                   # 后台接口契约
│   ├── api/api/<module>/v1/                  # C 端(Android)接口契约
│   ├── internal/controller/admin/sys/        # 后台控制器
│   ├── internal/controller/api/              # C 端控制器
│   ├── internal/logic/sys/                   # 业务实现（api_*.go 为 C 端逻辑）
│   ├── internal/model/input/sysin/           # 后台入参出参
│   ├── internal/model/input/apiin/           # C 端入参出参
│   ├── internal/router/genrouter/            # 后台路由（新建文件即自动注册）
│   ├── internal/router/api.go                # C 端路由
│   ├── internal/consts/                      # 字典与常量
│   └── resource/public/admin/                # 前端构建产物
└── web/                                      # Vue3 前端
    └── src/views/                            # 页面（每模块 index.vue + edit.vue + model.ts）
```

---

## 六、接口与鉴权（Android）

**access + refresh 双令牌**：

| 令牌 | 有效期 | 说明 |
| --- | --- | --- |
| accessToken | 2 小时 | JWT，请求头 `X-Hotgo-Token: Bearer <token>` |
| refreshToken | 30 天 | 不透明串，调 `/api/site/refresh` 换取新令牌（**轮换，旧值立即失效**） |

> ⚠️ 前置网关会覆盖 `Authorization` 请求头，因此**必须使用 `X-Hotgo-Token`**。
> 服务端已做过兼容（`GetAuthorization` 优先读该头），后台登录不受影响。

免登录接口（白名单在 `manifest/config/config.yaml` 的 `router.api.exceptLogin`）：
`/site/login`、`/site/register`、`/site/refresh`、`/vip/planList`、`/app/categoryList`、`/app/list`、`/app/detail`、`/forum/boardList`、`/forum/postList`、`/forum/postDetail`、`/forum/commentList`

已实现 **36 个**接口（含**版主工作台 11 个**、用户封禁状态查询 1 个），详见 `Android接口文档.md`。

**关键设计**：accessToken 复用框架 `token.Login`（命名空间 `token:api:*`，与后台 `token:admin:*` 完全隔离，**后台登录零回归**）；签发后用更短的 TTL 覆盖其缓存状态以实现「短 access + 长 refresh」。refreshToken 状态存缓存，仅使用 `Set/Get/Remove`（兼容 file 适配器）。

---

## 七、二次开发必读

### 7.1 新增一个后台业务模块

1. 建表（遵守 `created_at/updated_at/deleted_at/created_by/...` 约定，前缀 `hg_`）
2. `cd server && gf gen dao -t hg_xxx -y`（**必须带 `-t`**，否则会全量重刷所有表）
3. 按 `internal/logic/sys/curd_demo.go` 范式新建 5 个文件：`api/admin/<m>/`、`internal/controller/admin/sys/<m>.go`、`internal/logic/sys/<m>.go`、`internal/model/input/sysin/<m>.go`、`internal/router/genrouter/<m>.go`（**新建即自动注册**）
4. 在 `internal/service/sys.go` **末尾追加** `ISysXxx / SysXxx() / RegisterSysXxx()` 三件套
5. 前端新建 `src/views/<m>/{index.vue,edit.vue,model.ts}` + `src/api/<m>/index.ts`
6. 插入菜单记录（参考 `appstore_forum_menu.sql` 的写法），并重启刷新 casbin

### 7.2 改前端后必须做的三步（**最容易漏**）

```bash
cd /workspace/hotgo/web && pnpm run build
rm -rf ../server/resource/public/admin/* && cp -rf dist/* ../server/resource/public/admin/
cd ../server && go run ./packgen && go build -o hotgo main.go   # 重新打包内嵌资源
```

> `main.go` 引入了 `internal/packed`，内嵌资源**优先级高于磁盘文件**。
> 不重新生成 `internal/packed/packed.go`，前端改动一律不生效。
> 生成方法：`gres.PackToGoFileWithOption("resource", "internal/packed/packed.go", "packed", gres.Option{})`。
> **不要用 `gf build`**（受 git 浅克隆影响，且会连带打包，与手工流程冲突）。

### 7.3 菜单相关

- 菜单完全由数据库 `hg_admin_menu` 驱动，改菜单优先改数据而不是改前端代码。
- 删除菜单时**必须同时清理 `hg_admin_role_menu`**，否则角色仍引用已删菜单。
- 菜单的 `component` 字段 = `src/views` 之后去掉 `.vue` 的路径（如 `/appCategory/index`）。
- 改完菜单需**重启服务**或触发 `casbin.Refresh`，否则权限策略残留旧数据。
- 顶级目录必须用 `component='LAYOUT'`，且其 `redirect` 要指向真实子路由（否则登录后首页 404）。

---

## 八、已知限制

1. **WebSocket 不可用**：发布平台网关不支持 WebSocket 升级（握手返回 200 而非 101），站内信、在线用户等实时推送不可用，其余功能不受影响。
2. **登录偶发不跳转**：仅在自动化脚本快速点击（页面初始化未完成就提交）时出现；真人节奏实测稳定。万一遇到，刷新页面即处于登录态。
3. `hg_admin_member`（后台账号）与 `hg_user`（C 端用户）是**两套独立账号体系**，后台账号不能用于 Android 登录。
4. 卡密 `card_pwd` 为明文存储（卡密需要导出给运营发放），如合规要求提升可改为哈希存储，但会失去导出能力。
5. C 端登录密码为**明文经 HTTPS 传输**（移动端标准做法）；后台登录仍沿用原有的 AES 加密流程。
6. **敏感词过滤开关**：配置项 `sensitiveWord.switch`（`manifest/config/config.yaml`），缺省为开启。出现误伤需要临时排障时，把它设为 `false` 即可全量放行，改完重启服务生效。
7. **版主权限缓存 5 分钟**：版主权限采用短缓存（避免每次操作查库），后台修改版主权限后最多 5 分钟生效；后台的任命/修改/撤销会主动清理该缓存，一般无需等待。

---

## 九、验证结果（含本次迭代）

| 验证项 | 结果 |
| --- | --- |
| 「权限管理」菜单移除（一级菜单 9 → 8）与前端页面删除 | 通过 |
| 演示管理员账号清理（仅保留 admin）、角色精简为 2 个 | 通过 |
| 会员版块：非会员 `accessible=false`、访问被拒并提示开通 | 通过 |
| 会员版块：会员 `accessible=true`、可正常浏览 | 通过 |
| 会员应用：非会员 `downloadUrl` 为空 + `vipRequired=true` | 通过 |
| 会员应用：会员返回完整下载地址 | 通过 |
| 游客（无 token）访问会员专享内容同样受限 | 通过 |
| 版块/应用编辑页「会员专享」开关、列表会员标识列 | 通过 |
| 回归：8 个后台接口 + C 端登录/应用/帖子/版主工作台 | 通过 |
| 废弃代码清理后 `go build ./...` 与 `go test ./...` | 通过 |
| 前端清理后 `pnpm run build` | 通过 |
| 版主任命 + 权限位保存（权限包 17 = 审核帖子 + 删帖） | 通过 |
| 版主越权拦截：非版主删帖 / 版主无该权限操作 → 拒绝 | 通过（提示「你没有「XX」权限」） |
| 版主审核帖子 / 删帖 | 通过 |
| 版主跨版块操作拦截 | 通过 |
| 敏感词-替换：`替换测试词` → 落库为 `*****` | 通过 |
| 敏感词-拦截：发帖被拒并提示命中词 | 通过 |
| 封禁-禁言：可登录、发帖被拒（提示解除时间） | 通过 |
| 封禁-全局封禁：登录被拒、令牌刷新同样被拒 | 通过 |
| 解封后恢复正常 | 通过 |
| 操作日志「仅看写操作」过滤 | 通过（过滤后 89 条写操作） |
| 新增 4 个页面渲染（版主/敏感词/封禁/操作日志） | 通过（6/6 含回归页） |
| 回归：后台登录、C 端登录、应用列表、VIP 卡密激活 | 通过 |
| 后台登录、9 个一级菜单渲染 | 通过 |
| 16 个后台页面全部可正常打开 | 通过（16/16） |
| 数据看板真实统计 + 待办跳转 | 通过 |
| 应用审核 / 上下架 / 论坛审核 / 举报处理 | 通过 |
| Android：注册 / 登录 / 刷新 / 登出 | 通过 |
| Android：令牌轮换、登出后 access 与 refresh 双失效 | 通过 |
| Android：未登录访问受保护接口返回 code=61 | 通过 |
| Android：卡密激活（时长叠加、重复激活拦截） | 通过 |
| Android：应用列表/详情/提交、发帖/评论、举报 | 通过 |
| 后台登录回归（双令牌未影响 admin） | 通过 |
| 顶部多标签页移除、`getCrumbsSetting` bug 修复 | 通过 |
| 多端适配：手机 375px 登录 + 公告/广告/版本页正常渲染 | 通过（无 pageerror） |
| 运营管理菜单 + 3 子菜单（公告/版本/广告）下发 | 通过 |
| 4 个后台运营接口（announcement/appVersion/adPosition/ads） | 通过 |
| Android 配置页 27 项读取与保存 | 通过 |
| 公告列表（含长期有效/置顶）/ 详情（阅读量+1） | 通过 |
| 版本检查：低版本提示更新、最新版本无更新 | 通过 |
| 广告按广告位取素材、曝光/点击上报计数 | 通过 |
| 桌面端广告编辑弹窗（应用下拉）无报错 | 通过 |
| 回归：后台/C 端既有链路 + 运行状态 | 通过 |
