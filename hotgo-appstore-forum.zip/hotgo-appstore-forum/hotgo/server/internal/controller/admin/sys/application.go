// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/api/admin/application"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"
)

var (
	Application = cApplication{}
)

type cApplication struct{}

// List 查看应用列表
func (c *cApplication) List(ctx context.Context, req *application.ListReq) (res *application.ListRes, err error) {
	list, totalCount, err := service.SysApplication().List(ctx, &req.ApplicationListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.ApplicationListModel{}
	}

	res = new(application.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// View 获取指定应用信息
func (c *cApplication) View(ctx context.Context, req *application.ViewReq) (res *application.ViewRes, err error) {
	data, err := service.SysApplication().View(ctx, &req.ApplicationViewInp)
	if err != nil {
		return
	}

	res = new(application.ViewRes)
	res.ApplicationViewModel = data
	return
}

// Edit 修改/新增应用
func (c *cApplication) Edit(ctx context.Context, req *application.EditReq) (res *application.EditRes, err error) {
	err = service.SysApplication().Edit(ctx, &req.ApplicationEditInp)
	return
}

// Delete 删除应用
func (c *cApplication) Delete(ctx context.Context, req *application.DeleteReq) (res *application.DeleteRes, err error) {
	err = service.SysApplication().Delete(ctx, &req.ApplicationDeleteInp)
	return
}

// Status 更新应用状态
func (c *cApplication) Status(ctx context.Context, req *application.StatusReq) (res *application.StatusRes, err error) {
	err = service.SysApplication().Status(ctx, &req.ApplicationStatusInp)
	return
}

// Audit 审核应用
func (c *cApplication) Audit(ctx context.Context, req *application.AuditReq) (res *application.AuditRes, err error) {
	err = service.SysApplication().Audit(ctx, &req.ApplicationAuditInp)
	return
}

// Shelf 应用上下架
func (c *cApplication) Shelf(ctx context.Context, req *application.ShelfReq) (res *application.ShelfRes, err error) {
	err = service.SysApplication().Shelf(ctx, &req.ApplicationShelfInp)
	return
}
