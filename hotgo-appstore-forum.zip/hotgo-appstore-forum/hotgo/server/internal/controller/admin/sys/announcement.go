// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"

	"hotgo/api/admin/announcement"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"
)

var (
	Announcement = cAnnouncement{}
)

type cAnnouncement struct{}

// List 查看App公告列表
func (c *cAnnouncement) List(ctx context.Context, req *announcement.ListReq) (res *announcement.ListRes, err error) {
	list, totalCount, err := service.SysAnnouncement().List(ctx, &req.AnnouncementListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.AnnouncementListModel{}
	}

	res = new(announcement.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// View 获取App公告详情
func (c *cAnnouncement) View(ctx context.Context, req *announcement.ViewReq) (res *announcement.ViewRes, err error) {
	data, err := service.SysAnnouncement().View(ctx, &req.AnnouncementViewInp)
	if err != nil {
		return
	}

	res = new(announcement.ViewRes)
	res.AnnouncementListModel = data
	return
}

// Edit 修改/新增App公告
func (c *cAnnouncement) Edit(ctx context.Context, req *announcement.EditReq) (res *announcement.EditRes, err error) {
	err = service.SysAnnouncement().Edit(ctx, &req.AnnouncementEditInp)
	return
}

// Delete 删除App公告
func (c *cAnnouncement) Delete(ctx context.Context, req *announcement.DeleteReq) (res *announcement.DeleteRes, err error) {
	err = service.SysAnnouncement().Delete(ctx, &req.AnnouncementDeleteInp)
	return
}

// Status 更新App公告状态
func (c *cAnnouncement) Status(ctx context.Context, req *announcement.StatusReq) (res *announcement.StatusRes, err error) {
	err = service.SysAnnouncement().Status(ctx, &req.AnnouncementStatusInp)
	return
}

// Publish 发布/撤回App公告
func (c *cAnnouncement) Publish(ctx context.Context, req *announcement.PublishReq) (res *announcement.PublishRes, err error) {
	err = service.SysAnnouncement().Publish(ctx, &req.AnnouncementPublishInp)
	return
}
