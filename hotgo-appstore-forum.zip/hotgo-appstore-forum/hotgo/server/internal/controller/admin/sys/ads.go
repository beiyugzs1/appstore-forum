// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"

	"hotgo/api/admin/ads"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"
)

var (
	Ads = cAds{}
)

type cAds struct{}

// List 查看广告素材列表
func (c *cAds) List(ctx context.Context, req *ads.ListReq) (res *ads.ListRes, err error) {
	list, totalCount, err := service.SysAds().List(ctx, &req.AdsListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.AdsListModel{}
	}

	res = new(ads.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// View 获取广告素材详情
func (c *cAds) View(ctx context.Context, req *ads.ViewReq) (res *ads.ViewRes, err error) {
	data, err := service.SysAds().View(ctx, &req.AdsViewInp)
	if err != nil {
		return
	}

	res = new(ads.ViewRes)
	res.AdsListModel = data
	return
}

// Edit 修改/新增广告素材
func (c *cAds) Edit(ctx context.Context, req *ads.EditReq) (res *ads.EditRes, err error) {
	err = service.SysAds().Edit(ctx, &req.AdsEditInp)
	return
}

// Delete 删除广告素材
func (c *cAds) Delete(ctx context.Context, req *ads.DeleteReq) (res *ads.DeleteRes, err error) {
	err = service.SysAds().Delete(ctx, &req.AdsDeleteInp)
	return
}

// Status 更新广告素材状态
func (c *cAds) Status(ctx context.Context, req *ads.StatusReq) (res *ads.StatusRes, err error) {
	err = service.SysAds().Status(ctx, &req.AdsStatusInp)
	return
}
