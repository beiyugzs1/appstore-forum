// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/api/admin/vipcard"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"
)

var (
	VipCard = cVipCard{}
)

type cVipCard struct{}

// List 查看卡密列表
func (c *cVipCard) List(ctx context.Context, req *vipcard.ListReq) (res *vipcard.ListRes, err error) {
	list, totalCount, err := service.SysVipCard().List(ctx, &req.VipCardListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.VipCardListModel{}
	}

	res = new(vipcard.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// View 获取指定卡密信息
func (c *cVipCard) View(ctx context.Context, req *vipcard.ViewReq) (res *vipcard.ViewRes, err error) {
	data, err := service.SysVipCard().View(ctx, &req.VipCardViewInp)
	if err != nil {
		return
	}

	res = new(vipcard.ViewRes)
	res.VipCardViewModel = data
	return
}

// Generate 批量生成卡密
func (c *cVipCard) Generate(ctx context.Context, req *vipcard.GenerateReq) (res *vipcard.GenerateRes, err error) {
	data, err := service.SysVipCard().Generate(ctx, &req.VipCardGenerateInp)
	if err != nil {
		return
	}

	res = new(vipcard.GenerateRes)
	res.VipCardGenerateModel = data
	return
}

// Delete 删除卡密
func (c *cVipCard) Delete(ctx context.Context, req *vipcard.DeleteReq) (res *vipcard.DeleteRes, err error) {
	err = service.SysVipCard().Delete(ctx, &req.VipCardDeleteInp)
	return
}

// Status 更新卡密状态
func (c *cVipCard) Status(ctx context.Context, req *vipcard.StatusReq) (res *vipcard.StatusRes, err error) {
	err = service.SysVipCard().Status(ctx, &req.VipCardStatusInp)
	return
}

// LogList 查看卡密激活记录
func (c *cVipCard) LogList(ctx context.Context, req *vipcard.LogListReq) (res *vipcard.LogListRes, err error) {
	list, totalCount, err := service.SysVipCard().LogList(ctx, &req.VipCardLogListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.VipCardLogListModel{}
	}

	res = new(vipcard.LogListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}
