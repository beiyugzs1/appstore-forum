// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/api/admin/user"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"
)

var (
	User = cUser{}
)

type cUser struct{}

// List 查看用户列表
func (c *cUser) List(ctx context.Context, req *user.ListReq) (res *user.ListRes, err error) {
	list, totalCount, err := service.SysUser().List(ctx, &req.UserListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.UserListModel{}
	}

	res = new(user.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// View 获取指定用户信息
func (c *cUser) View(ctx context.Context, req *user.ViewReq) (res *user.ViewRes, err error) {
	data, err := service.SysUser().View(ctx, &req.UserViewInp)
	if err != nil {
		return
	}

	res = new(user.ViewRes)
	res.UserViewModel = data
	return
}

// Edit 修改用户
func (c *cUser) Edit(ctx context.Context, req *user.EditReq) (res *user.EditRes, err error) {
	err = service.SysUser().Edit(ctx, &req.UserEditInp)
	return
}

// Delete 删除用户
func (c *cUser) Delete(ctx context.Context, req *user.DeleteReq) (res *user.DeleteRes, err error) {
	err = service.SysUser().Delete(ctx, &req.UserDeleteInp)
	return
}

// Status 更新用户状态
func (c *cUser) Status(ctx context.Context, req *user.StatusReq) (res *user.StatusRes, err error) {
	err = service.SysUser().Status(ctx, &req.UserStatusInp)
	return
}

// ResetPwd 重置用户密码
func (c *cUser) ResetPwd(ctx context.Context, req *user.ResetPwdReq) (res *user.ResetPwdRes, err error) {
	err = service.SysUser().ResetPwd(ctx, &req.UserResetPwdInp)
	return
}
