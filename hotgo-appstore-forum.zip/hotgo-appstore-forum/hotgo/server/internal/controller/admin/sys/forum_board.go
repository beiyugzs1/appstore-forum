// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/api/admin/forumboard"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"
)

var (
	ForumBoard = cForumBoard{}
)

type cForumBoard struct{}

// List 查看论坛版块列表
func (c *cForumBoard) List(ctx context.Context, req *forumboard.ListReq) (res *forumboard.ListRes, err error) {
	list, totalCount, err := service.SysForumBoard().List(ctx, &req.ForumBoardListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.ForumBoardListModel{}
	}

	res = new(forumboard.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// View 获取指定论坛版块信息
func (c *cForumBoard) View(ctx context.Context, req *forumboard.ViewReq) (res *forumboard.ViewRes, err error) {
	data, err := service.SysForumBoard().View(ctx, &req.ForumBoardViewInp)
	if err != nil {
		return
	}

	res = new(forumboard.ViewRes)
	res.ForumBoardViewModel = data
	return
}

// Edit 修改/新增论坛版块
func (c *cForumBoard) Edit(ctx context.Context, req *forumboard.EditReq) (res *forumboard.EditRes, err error) {
	err = service.SysForumBoard().Edit(ctx, &req.ForumBoardEditInp)
	return
}

// Delete 删除论坛版块
func (c *cForumBoard) Delete(ctx context.Context, req *forumboard.DeleteReq) (res *forumboard.DeleteRes, err error) {
	err = service.SysForumBoard().Delete(ctx, &req.ForumBoardDeleteInp)
	return
}

// Status 更新论坛版块状态
func (c *cForumBoard) Status(ctx context.Context, req *forumboard.StatusReq) (res *forumboard.StatusRes, err error) {
	err = service.SysForumBoard().Status(ctx, &req.ForumBoardStatusInp)
	return
}
