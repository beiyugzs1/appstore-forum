// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"

	"hotgo/api/admin/forummoderator"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"
)

var (
	ForumModerator = cForumModerator{}
)

type cForumModerator struct{}

// List 查看论坛版主列表
func (c *cForumModerator) List(ctx context.Context, req *forummoderator.ListReq) (res *forummoderator.ListRes, err error) {
	list, totalCount, err := service.SysForumModerator().List(ctx, &req.ForumModeratorListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.ForumModeratorListModel{}
	}

	res = new(forummoderator.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// View 获取指定论坛版主信息
func (c *cForumModerator) View(ctx context.Context, req *forummoderator.ViewReq) (res *forummoderator.ViewRes, err error) {
	data, err := service.SysForumModerator().View(ctx, &req.ForumModeratorViewInp)
	if err != nil {
		return
	}

	res = new(forummoderator.ViewRes)
	res.ForumModeratorListModel = data
	return
}

// Edit 修改/新增论坛版主
func (c *cForumModerator) Edit(ctx context.Context, req *forummoderator.EditReq) (res *forummoderator.EditRes, err error) {
	err = service.SysForumModerator().Edit(ctx, &req.ForumModeratorEditInp)
	return
}

// Delete 删除论坛版主
func (c *cForumModerator) Delete(ctx context.Context, req *forummoderator.DeleteReq) (res *forummoderator.DeleteRes, err error) {
	err = service.SysForumModerator().Delete(ctx, &req.ForumModeratorDeleteInp)
	return
}

// Status 更新论坛版主状态
func (c *cForumModerator) Status(ctx context.Context, req *forummoderator.StatusReq) (res *forummoderator.StatusRes, err error) {
	err = service.SysForumModerator().Status(ctx, &req.ForumModeratorStatusInp)
	return
}
