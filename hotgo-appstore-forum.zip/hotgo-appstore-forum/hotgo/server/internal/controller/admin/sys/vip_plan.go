// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/api/admin/vipplan"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"
)

var (
	VipPlan = cVipPlan{}
)

type cVipPlan struct{}

// List 查看VIP套餐列表
func (c *cVipPlan) List(ctx context.Context, req *vipplan.ListReq) (res *vipplan.ListRes, err error) {
	list, totalCount, err := service.SysVipPlan().List(ctx, &req.VipPlanListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.VipPlanListModel{}
	}

	res = new(vipplan.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// View 获取指定VIP套餐信息
func (c *cVipPlan) View(ctx context.Context, req *vipplan.ViewReq) (res *vipplan.ViewRes, err error) {
	data, err := service.SysVipPlan().View(ctx, &req.VipPlanViewInp)
	if err != nil {
		return
	}

	res = new(vipplan.ViewRes)
	res.VipPlanViewModel = data
	return
}

// Edit 修改/新增VIP套餐
func (c *cVipPlan) Edit(ctx context.Context, req *vipplan.EditReq) (res *vipplan.EditRes, err error) {
	err = service.SysVipPlan().Edit(ctx, &req.VipPlanEditInp)
	return
}

// Delete 删除VIP套餐
func (c *cVipPlan) Delete(ctx context.Context, req *vipplan.DeleteReq) (res *vipplan.DeleteRes, err error) {
	err = service.SysVipPlan().Delete(ctx, &req.VipPlanDeleteInp)
	return
}

// Status 更新VIP套餐状态
func (c *cVipPlan) Status(ctx context.Context, req *vipplan.StatusReq) (res *vipplan.StatusRes, err error) {
	err = service.SysVipPlan().Status(ctx, &req.VipPlanStatusInp)
	return
}
