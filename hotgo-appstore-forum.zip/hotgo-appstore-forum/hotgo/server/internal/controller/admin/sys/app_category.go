// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/api/admin/appcategory"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"
)

var (
	AppCategory = cAppCategory{}
)

type cAppCategory struct{}

// List 查看应用分类列表
func (c *cAppCategory) List(ctx context.Context, req *appcategory.ListReq) (res *appcategory.ListRes, err error) {
	list, totalCount, err := service.SysAppCategory().List(ctx, &req.AppCategoryListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.AppCategoryListModel{}
	}

	res = new(appcategory.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// View 获取指定应用分类信息
func (c *cAppCategory) View(ctx context.Context, req *appcategory.ViewReq) (res *appcategory.ViewRes, err error) {
	data, err := service.SysAppCategory().View(ctx, &req.AppCategoryViewInp)
	if err != nil {
		return
	}

	res = new(appcategory.ViewRes)
	res.AppCategoryViewModel = data
	return
}

// Edit 修改/新增应用分类
func (c *cAppCategory) Edit(ctx context.Context, req *appcategory.EditReq) (res *appcategory.EditRes, err error) {
	err = service.SysAppCategory().Edit(ctx, &req.AppCategoryEditInp)
	return
}

// Delete 删除应用分类
func (c *cAppCategory) Delete(ctx context.Context, req *appcategory.DeleteReq) (res *appcategory.DeleteRes, err error) {
	err = service.SysAppCategory().Delete(ctx, &req.AppCategoryDeleteInp)
	return
}

// Status 更新应用分类状态
func (c *cAppCategory) Status(ctx context.Context, req *appcategory.StatusReq) (res *appcategory.StatusRes, err error) {
	err = service.SysAppCategory().Status(ctx, &req.AppCategoryStatusInp)
	return
}
