// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"

	"hotgo/api/admin/adposition"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"
)

var (
	AdPosition = cAdPosition{}
)

type cAdPosition struct{}

// List 查看广告位列表
func (c *cAdPosition) List(ctx context.Context, req *adposition.ListReq) (res *adposition.ListRes, err error) {
	list, totalCount, err := service.SysAdPosition().List(ctx, &req.AdPositionListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.AdPositionListModel{}
	}

	res = new(adposition.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// View 获取广告位详情
func (c *cAdPosition) View(ctx context.Context, req *adposition.ViewReq) (res *adposition.ViewRes, err error) {
	data, err := service.SysAdPosition().View(ctx, &req.AdPositionViewInp)
	if err != nil {
		return
	}

	res = new(adposition.ViewRes)
	res.AdPositionListModel = data
	return
}

// Edit 修改/新增广告位
func (c *cAdPosition) Edit(ctx context.Context, req *adposition.EditReq) (res *adposition.EditRes, err error) {
	err = service.SysAdPosition().Edit(ctx, &req.AdPositionEditInp)
	return
}

// Delete 删除广告位
func (c *cAdPosition) Delete(ctx context.Context, req *adposition.DeleteReq) (res *adposition.DeleteRes, err error) {
	err = service.SysAdPosition().Delete(ctx, &req.AdPositionDeleteInp)
	return
}

// Status 更新广告位状态
func (c *cAdPosition) Status(ctx context.Context, req *adposition.StatusReq) (res *adposition.StatusRes, err error) {
	err = service.SysAdPosition().Status(ctx, &req.AdPositionStatusInp)
	return
}

// Option 获取广告位选项
func (c *cAdPosition) Option(ctx context.Context, req *adposition.OptionReq) (res *adposition.OptionRes, err error) {
	list, err := service.SysAdPosition().Option(ctx)
	if err != nil {
		return
	}

	res = new(adposition.OptionRes)
	res.List = list
	return
}
