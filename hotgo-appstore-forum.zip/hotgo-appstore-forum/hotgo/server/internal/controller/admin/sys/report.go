// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/api/admin/report"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"
)

var (
	Report = cReport{}
)

type cReport struct{}

// List 查看举报列表
func (c *cReport) List(ctx context.Context, req *report.ListReq) (res *report.ListRes, err error) {
	list, totalCount, err := service.SysReport().List(ctx, &req.ReportListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.ReportListModel{}
	}

	res = new(report.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// View 获取指定举报信息
func (c *cReport) View(ctx context.Context, req *report.ViewReq) (res *report.ViewRes, err error) {
	data, err := service.SysReport().View(ctx, &req.ReportViewInp)
	if err != nil {
		return
	}

	res = new(report.ViewRes)
	res.ReportViewModel = data
	return
}

// Handle 处理举报
func (c *cReport) Handle(ctx context.Context, req *report.HandleReq) (res *report.HandleRes, err error) {
	err = service.SysReport().Handle(ctx, &req.ReportHandleInp)
	return
}

// Delete 删除举报
func (c *cReport) Delete(ctx context.Context, req *report.DeleteReq) (res *report.DeleteRes, err error) {
	err = service.SysReport().Delete(ctx, &req.ReportDeleteInp)
	return
}
