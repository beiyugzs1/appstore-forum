// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/api/admin/forumpost"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"
)

var (
	ForumPost = cForumPost{}
)

type cForumPost struct{}

// List 查看帖子列表
func (c *cForumPost) List(ctx context.Context, req *forumpost.ListReq) (res *forumpost.ListRes, err error) {
	list, totalCount, err := service.SysForumPost().List(ctx, &req.ForumPostListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.ForumPostListModel{}
	}

	res = new(forumpost.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// View 获取指定帖子信息
func (c *cForumPost) View(ctx context.Context, req *forumpost.ViewReq) (res *forumpost.ViewRes, err error) {
	data, err := service.SysForumPost().View(ctx, &req.ForumPostViewInp)
	if err != nil {
		return
	}

	res = new(forumpost.ViewRes)
	res.ForumPostViewModel = data
	return
}

// Edit 修改帖子
func (c *cForumPost) Edit(ctx context.Context, req *forumpost.EditReq) (res *forumpost.EditRes, err error) {
	err = service.SysForumPost().Edit(ctx, &req.ForumPostEditInp)
	return
}

// Delete 删除帖子
func (c *cForumPost) Delete(ctx context.Context, req *forumpost.DeleteReq) (res *forumpost.DeleteRes, err error) {
	err = service.SysForumPost().Delete(ctx, &req.ForumPostDeleteInp)
	return
}

// Status 更新帖子状态
func (c *cForumPost) Status(ctx context.Context, req *forumpost.StatusReq) (res *forumpost.StatusRes, err error) {
	err = service.SysForumPost().Status(ctx, &req.ForumPostStatusInp)
	return
}

// Audit 审核帖子
func (c *cForumPost) Audit(ctx context.Context, req *forumpost.AuditReq) (res *forumpost.AuditRes, err error) {
	err = service.SysForumPost().Audit(ctx, &req.ForumPostAuditInp)
	return
}
