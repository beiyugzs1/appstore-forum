// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"

	"hotgo/api/admin/appversion"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"
)

var (
	AppVersion = cAppVersion{}
)

type cAppVersion struct{}

// List 查看App版本列表
func (c *cAppVersion) List(ctx context.Context, req *appversion.ListReq) (res *appversion.ListRes, err error) {
	list, totalCount, err := service.SysAppVersion().List(ctx, &req.AppVersionListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.AppVersionListModel{}
	}

	res = new(appversion.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// View 获取App版本详情
func (c *cAppVersion) View(ctx context.Context, req *appversion.ViewReq) (res *appversion.ViewRes, err error) {
	data, err := service.SysAppVersion().View(ctx, &req.AppVersionViewInp)
	if err != nil {
		return
	}

	res = new(appversion.ViewRes)
	res.AppVersionListModel = data
	return
}

// Edit 修改/新增App版本
func (c *cAppVersion) Edit(ctx context.Context, req *appversion.EditReq) (res *appversion.EditRes, err error) {
	err = service.SysAppVersion().Edit(ctx, &req.AppVersionEditInp)
	return
}

// Delete 删除App版本
func (c *cAppVersion) Delete(ctx context.Context, req *appversion.DeleteReq) (res *appversion.DeleteRes, err error) {
	err = service.SysAppVersion().Delete(ctx, &req.AppVersionDeleteInp)
	return
}

// Status 更新App版本状态
func (c *cAppVersion) Status(ctx context.Context, req *appversion.StatusReq) (res *appversion.StatusRes, err error) {
	err = service.SysAppVersion().Status(ctx, &req.AppVersionStatusInp)
	return
}

// Publish 发布App版本
func (c *cAppVersion) Publish(ctx context.Context, req *appversion.PublishReq) (res *appversion.PublishRes, err error) {
	err = service.SysAppVersion().Publish(ctx, &req.AppVersionPublishInp)
	return
}
