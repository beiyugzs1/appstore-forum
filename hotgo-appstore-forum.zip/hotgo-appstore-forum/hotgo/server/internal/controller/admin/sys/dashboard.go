// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/api/admin/dashboard"
	"hotgo/internal/service"
)

var (
	Dashboard = cDashboard{}
)

type cDashboard struct{}

// Statistics 获取看板统计数据
func (c *cDashboard) Statistics(ctx context.Context, req *dashboard.StatisticsReq) (res *dashboard.StatisticsRes, err error) {
	data, err := service.SysDashboard().Statistics(ctx)
	if err != nil {
		return
	}

	res = new(dashboard.StatisticsRes)
	res.DashboardStatisticsModel = data
	return
}
