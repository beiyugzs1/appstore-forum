// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"

	"hotgo/api/admin/sensitiveword"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"
)

var (
	SensitiveWord = cSensitiveWord{}
)

type cSensitiveWord struct{}

// List 查看敏感词列表
func (c *cSensitiveWord) List(ctx context.Context, req *sensitiveword.ListReq) (res *sensitiveword.ListRes, err error) {
	list, totalCount, err := service.SysSensitiveWord().List(ctx, &req.SensitiveWordListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.SensitiveWordListModel{}
	}

	res = new(sensitiveword.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// View 获取敏感词详情
func (c *cSensitiveWord) View(ctx context.Context, req *sensitiveword.ViewReq) (res *sensitiveword.ViewRes, err error) {
	data, err := service.SysSensitiveWord().View(ctx, &req.SensitiveWordViewInp)
	if err != nil {
		return
	}

	res = new(sensitiveword.ViewRes)
	res.SensitiveWordListModel = data
	return
}

// Edit 修改/新增敏感词
func (c *cSensitiveWord) Edit(ctx context.Context, req *sensitiveword.EditReq) (res *sensitiveword.EditRes, err error) {
	err = service.SysSensitiveWord().Edit(ctx, &req.SensitiveWordEditInp)
	return
}

// Delete 删除敏感词
func (c *cSensitiveWord) Delete(ctx context.Context, req *sensitiveword.DeleteReq) (res *sensitiveword.DeleteRes, err error) {
	err = service.SysSensitiveWord().Delete(ctx, &req.SensitiveWordDeleteInp)
	return
}

// Status 更新敏感词状态
func (c *cSensitiveWord) Status(ctx context.Context, req *sensitiveword.StatusReq) (res *sensitiveword.StatusRes, err error) {
	err = service.SysSensitiveWord().Status(ctx, &req.SensitiveWordStatusInp)
	return
}
