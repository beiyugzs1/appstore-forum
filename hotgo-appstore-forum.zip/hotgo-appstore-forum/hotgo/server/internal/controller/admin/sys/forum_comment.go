// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/api/admin/forumcomment"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"
)

var (
	ForumComment = cForumComment{}
)

type cForumComment struct{}

// List 查看评论列表
func (c *cForumComment) List(ctx context.Context, req *forumcomment.ListReq) (res *forumcomment.ListRes, err error) {
	list, totalCount, err := service.SysForumComment().List(ctx, &req.ForumCommentListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.ForumCommentListModel{}
	}

	res = new(forumcomment.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// View 获取指定评论信息
func (c *cForumComment) View(ctx context.Context, req *forumcomment.ViewReq) (res *forumcomment.ViewRes, err error) {
	data, err := service.SysForumComment().View(ctx, &req.ForumCommentViewInp)
	if err != nil {
		return
	}

	res = new(forumcomment.ViewRes)
	res.ForumCommentViewModel = data
	return
}

// Delete 删除评论
func (c *cForumComment) Delete(ctx context.Context, req *forumcomment.DeleteReq) (res *forumcomment.DeleteRes, err error) {
	err = service.SysForumComment().Delete(ctx, &req.ForumCommentDeleteInp)
	return
}

// Status 更新评论状态
func (c *cForumComment) Status(ctx context.Context, req *forumcomment.StatusReq) (res *forumcomment.StatusRes, err error) {
	err = service.SysForumComment().Status(ctx, &req.ForumCommentStatusInp)
	return
}

// Audit 审核评论
func (c *cForumComment) Audit(ctx context.Context, req *forumcomment.AuditReq) (res *forumcomment.AuditRes, err error) {
	err = service.SysForumComment().Audit(ctx, &req.ForumCommentAuditInp)
	return
}
