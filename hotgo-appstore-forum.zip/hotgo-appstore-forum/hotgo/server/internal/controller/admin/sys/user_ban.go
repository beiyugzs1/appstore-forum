// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"

	"hotgo/api/admin/userban"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"
)

var (
	UserBan = cUserBan{}
)

type cUserBan struct{}

// List 查看封禁记录列表
func (c *cUserBan) List(ctx context.Context, req *userban.ListReq) (res *userban.ListRes, err error) {
	list, totalCount, err := service.SysUserBan().List(ctx, &req.UserBanListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*sysin.UserBanListModel{}
	}

	res = new(userban.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// View 获取封禁记录详情
func (c *cUserBan) View(ctx context.Context, req *userban.ViewReq) (res *userban.ViewRes, err error) {
	data, err := service.SysUserBan().View(ctx, &req.UserBanViewInp)
	if err != nil {
		return
	}

	res = new(userban.ViewRes)
	res.UserBanListModel = data
	return
}

// Edit 封禁/禁言用户
func (c *cUserBan) Edit(ctx context.Context, req *userban.EditReq) (res *userban.EditRes, err error) {
	err = service.SysUserBan().Edit(ctx, &req.UserBanEditInp)
	return
}

// Relieve 解除封禁
func (c *cUserBan) Relieve(ctx context.Context, req *userban.RelieveReq) (res *userban.RelieveRes, err error) {
	err = service.SysUserBan().Relieve(ctx, &req.UserBanRelieveInp)
	return
}

// Delete 删除封禁记录
func (c *cUserBan) Delete(ctx context.Context, req *userban.DeleteReq) (res *userban.DeleteRes, err error) {
	err = service.SysUserBan().Delete(ctx, &req.UserBanDeleteInp)
	return
}
