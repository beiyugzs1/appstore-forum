// Package forum
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package forum

import (
	"context"

	v1 "hotgo/api/api/forum/v1"
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/service"
)

// Controller C端论坛控制器
type Controller struct{}

// NewV1 创建C端论坛控制器
func NewV1() *Controller {
	return &Controller{}
}

// BoardList 版块列表
func (c *Controller) BoardList(ctx context.Context, req *v1.BoardListReq) (res *v1.BoardListRes, err error) {
	data, err := service.SysApiForum().BoardList(ctx)
	if err != nil {
		return
	}

	res = new(v1.BoardListRes)
	res.ApiForumBoardListModel = data
	return
}

// PostList 帖子列表
func (c *Controller) PostList(ctx context.Context, req *v1.PostListReq) (res *v1.PostListRes, err error) {
	list, totalCount, err := service.SysApiForum().PostList(ctx, &req.ApiForumPostListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*apiin.ApiForumPostModel{}
	}

	res = new(v1.PostListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// PostDetail 帖子详情
func (c *Controller) PostDetail(ctx context.Context, req *v1.PostDetailReq) (res *v1.PostDetailRes, err error) {
	data, err := service.SysApiForum().PostDetail(ctx, &req.ApiForumPostDetailInp)
	if err != nil {
		return
	}

	res = new(v1.PostDetailRes)
	res.ApiForumPostDetailModel = data
	return
}

// PublishPost 发布帖子
func (c *Controller) PublishPost(ctx context.Context, req *v1.PublishPostReq) (res *v1.PublishPostRes, err error) {
	data, err := service.SysApiForum().PublishPost(ctx, &req.ApiForumPublishPostInp)
	if err != nil {
		return
	}

	res = new(v1.PublishPostRes)
	res.ApiForumPublishPostModel = data
	return
}

// CommentList 评论列表
func (c *Controller) CommentList(ctx context.Context, req *v1.CommentListReq) (res *v1.CommentListRes, err error) {
	list, totalCount, err := service.SysApiForum().CommentList(ctx, &req.ApiForumCommentListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*apiin.ApiForumCommentModel{}
	}

	res = new(v1.CommentListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// PublishComment 发表评论
func (c *Controller) PublishComment(ctx context.Context, req *v1.PublishCommentReq) (res *v1.PublishCommentRes, err error) {
	data, err := service.SysApiForum().PublishComment(ctx, &req.ApiForumPublishCommentInp)
	if err != nil {
		return
	}

	res = new(v1.PublishCommentRes)
	res.ApiForumPublishCommentModel = data
	return
}
