// Package ops
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package ops

import (
	"context"

	v1 "hotgo/api/api/ops/v1"
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/service"
)

// Controller C端运营控制器
type Controller struct{}

// NewV1 创建C端运营控制器
func NewV1() *Controller {
	return &Controller{}
}

// AndroidConfig 获取App端配置
func (c *Controller) AndroidConfig(ctx context.Context, req *v1.AndroidConfigReq) (res *v1.AndroidConfigRes, err error) {
	data, err := service.SysApiOps().AndroidConfig(ctx)
	if err != nil {
		return
	}

	res = new(v1.AndroidConfigRes)
	res.ApiAndroidConfigModel = data
	return
}

// AnnouncementList App公告列表
func (c *Controller) AnnouncementList(ctx context.Context, req *v1.AnnouncementListReq) (res *v1.AnnouncementListRes, err error) {
	list, totalCount, err := service.SysApiOps().AnnouncementList(ctx, &req.ApiAnnouncementListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*apiin.ApiAnnouncementListModel{}
	}

	res = new(v1.AnnouncementListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// AnnouncementDetail App公告详情
func (c *Controller) AnnouncementDetail(ctx context.Context, req *v1.AnnouncementDetailReq) (res *v1.AnnouncementDetailRes, err error) {
	data, err := service.SysApiOps().AnnouncementDetail(ctx, &req.ApiAnnouncementDetailInp)
	if err != nil {
		return
	}

	res = new(v1.AnnouncementDetailRes)
	res.ApiAnnouncementDetailModel = data
	return
}

// VersionCheck 检查版本更新
func (c *Controller) VersionCheck(ctx context.Context, req *v1.VersionCheckReq) (res *v1.VersionCheckRes, err error) {
	data, err := service.SysApiOps().VersionCheck(ctx, &req.ApiVersionCheckInp)
	if err != nil {
		return
	}

	res = new(v1.VersionCheckRes)
	res.ApiVersionCheckModel = data
	return
}

// AdList 按广告位取广告
func (c *Controller) AdList(ctx context.Context, req *v1.AdListReq) (res *v1.AdListRes, err error) {
	data, err := service.SysApiOps().AdList(ctx, &req.ApiAdListInp)
	if err != nil {
		return
	}

	res = new(v1.AdListRes)
	res.ApiAdListModel = data
	return
}

// AdReport 广告曝光/点击上报
func (c *Controller) AdReport(ctx context.Context, req *v1.AdReportReq) (res *v1.AdReportRes, err error) {
	if err = service.SysApiOps().AdReport(ctx, &req.ApiAdReportInp); err != nil {
		return
	}

	res = new(v1.AdReportRes)
	return
}
