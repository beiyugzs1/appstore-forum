// Package vip
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package vip

import (
	"context"

	v1 "hotgo/api/api/vip/v1"
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/service"
)

// Controller C端VIP控制器
type Controller struct{}

// NewV1 创建C端VIP控制器
func NewV1() *Controller {
	return &Controller{}
}

// PlanList VIP套餐列表
func (c *Controller) PlanList(ctx context.Context, req *v1.PlanListReq) (res *v1.PlanListRes, err error) {
	data, err := service.SysApiVip().PlanList(ctx)
	if err != nil {
		return
	}

	res = new(v1.PlanListRes)
	res.ApiVipPlanListModel = data
	return
}

// Activate 卡密激活VIP
func (c *Controller) Activate(ctx context.Context, req *v1.ActivateReq) (res *v1.ActivateRes, err error) {
	data, err := service.SysApiVip().Activate(ctx, &req.ApiVipActivateInp)
	if err != nil {
		return
	}

	res = new(v1.ActivateRes)
	res.ApiVipActivateModel = data
	return
}

// MyCardLog 我的激活记录
func (c *Controller) MyCardLog(ctx context.Context, req *v1.MyCardLogReq) (res *v1.MyCardLogRes, err error) {
	list, totalCount, err := service.SysApiVip().MyCardLog(ctx, &req.ApiVipCardLogListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*apiin.ApiVipCardLogModel{}
	}

	res = new(v1.MyCardLogRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}
