// Package user
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package user

import (
	"context"

	v1 "hotgo/api/api/user/v1"
	"hotgo/internal/service"
)

// Controller C端用户控制器
type Controller struct{}

// NewV1 创建C端用户控制器
func NewV1() *Controller {
	return &Controller{}
}

// Info 获取个人资料
func (c *Controller) Info(ctx context.Context, req *v1.InfoReq) (res *v1.InfoRes, err error) {
	data, err := service.SysApiUser().Info(ctx)
	if err != nil {
		return
	}

	res = new(v1.InfoRes)
	res.ApiUserInfoModel = data
	return
}

// UpdateProfile 修改个人资料
func (c *Controller) UpdateProfile(ctx context.Context, req *v1.UpdateProfileReq) (res *v1.UpdateProfileRes, err error) {
	if err = service.SysApiUser().UpdateProfile(ctx, &req.ApiUpdateProfileInp); err != nil {
		return
	}

	res = new(v1.UpdateProfileRes)
	return
}

// UpdatePwd 修改密码
func (c *Controller) UpdatePwd(ctx context.Context, req *v1.UpdatePwdReq) (res *v1.UpdatePwdRes, err error) {
	if err = service.SysApiUser().UpdatePwd(ctx, &req.ApiUpdatePwdInp); err != nil {
		return
	}

	res = new(v1.UpdatePwdRes)
	return
}

// BanStatus 我的封禁/禁言状态
func (c *Controller) BanStatus(ctx context.Context, req *v1.BanStatusReq) (res *v1.BanStatusRes, err error) {
	data, err := service.SysApiUser().BanStatus(ctx)
	if err != nil {
		return
	}

	res = new(v1.BanStatusRes)
	res.UserBanStatusModel = data
	return
}
