// Package app
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package app

import (
	"context"

	v1 "hotgo/api/api/app/v1"
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/service"
)

// Controller C端应用控制器
type Controller struct{}

// NewV1 创建C端应用控制器
func NewV1() *Controller {
	return &Controller{}
}

// CategoryList 应用分类列表
func (c *Controller) CategoryList(ctx context.Context, req *v1.CategoryListReq) (res *v1.CategoryListRes, err error) {
	data, err := service.SysApiApp().CategoryList(ctx)
	if err != nil {
		return
	}

	res = new(v1.CategoryListRes)
	res.ApiAppCategoryListModel = data
	return
}

// List 应用列表
func (c *Controller) List(ctx context.Context, req *v1.ListReq) (res *v1.ListRes, err error) {
	list, totalCount, err := service.SysApiApp().List(ctx, &req.ApiAppListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*apiin.ApiAppListModel{}
	}

	res = new(v1.ListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// Detail 应用详情
func (c *Controller) Detail(ctx context.Context, req *v1.DetailReq) (res *v1.DetailRes, err error) {
	data, err := service.SysApiApp().Detail(ctx, &req.ApiAppDetailInp)
	if err != nil {
		return
	}

	res = new(v1.DetailRes)
	res.ApiAppDetailModel = data
	return
}

// Submit 开发者提交应用
func (c *Controller) Submit(ctx context.Context, req *v1.SubmitReq) (res *v1.SubmitRes, err error) {
	data, err := service.SysApiApp().Submit(ctx, &req.ApiAppSubmitInp)
	if err != nil {
		return
	}

	res = new(v1.SubmitRes)
	res.ApiAppSubmitModel = data
	return
}

// MyList 我提交的应用
func (c *Controller) MyList(ctx context.Context, req *v1.MyListReq) (res *v1.MyListRes, err error) {
	list, totalCount, err := service.SysApiApp().MyList(ctx, &req.ApiAppMyListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*apiin.ApiAppMyListModel{}
	}

	res = new(v1.MyListRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}
