// Package report
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package report

import (
	"context"

	v1 "hotgo/api/api/report/v1"
	"hotgo/internal/service"
)

// Controller C端举报控制器
type Controller struct{}

// NewV1 创建C端举报控制器
func NewV1() *Controller {
	return &Controller{}
}

// Submit 提交举报
func (c *Controller) Submit(ctx context.Context, req *v1.SubmitReq) (res *v1.SubmitRes, err error) {
	data, err := service.SysApiReport().Submit(ctx, &req.ApiReportSubmitInp)
	if err != nil {
		return
	}

	res = new(v1.SubmitRes)
	res.ApiReportSubmitModel = data
	return
}
