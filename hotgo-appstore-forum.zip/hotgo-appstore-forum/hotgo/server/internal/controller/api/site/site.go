// Package site
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package site

import (
	"context"

	v1 "hotgo/api/api/site/v1"
	"hotgo/internal/service"
)

// Controller C端认证控制器
type Controller struct{}

// NewV1 创建C端认证控制器
func NewV1() *Controller {
	return &Controller{}
}

// Login 账号登录
func (c *Controller) Login(ctx context.Context, req *v1.LoginReq) (res *v1.LoginRes, err error) {
	data, err := service.SysApiAuth().Login(ctx, &req.ApiLoginInp)
	if err != nil {
		return
	}

	res = new(v1.LoginRes)
	res.ApiLoginModel = data
	return
}

// Register 用户注册
func (c *Controller) Register(ctx context.Context, req *v1.RegisterReq) (res *v1.RegisterRes, err error) {
	data, err := service.SysApiAuth().Register(ctx, &req.ApiRegisterInp)
	if err != nil {
		return
	}

	res = new(v1.RegisterRes)
	res.ApiRegisterModel = data
	return
}

// Refresh 刷新令牌
func (c *Controller) Refresh(ctx context.Context, req *v1.RefreshReq) (res *v1.RefreshRes, err error) {
	data, err := service.SysApiAuth().Refresh(ctx, &req.ApiRefreshInp)
	if err != nil {
		return
	}

	res = new(v1.RefreshRes)
	res.ApiRefreshModel = data
	return
}

// Logout 退出登录
func (c *Controller) Logout(ctx context.Context, req *v1.LogoutReq) (res *v1.LogoutRes, err error) {
	if err = service.SysApiAuth().Logout(ctx, &req.ApiLogoutInp); err != nil {
		return
	}

	res = new(v1.LogoutRes)
	return
}
