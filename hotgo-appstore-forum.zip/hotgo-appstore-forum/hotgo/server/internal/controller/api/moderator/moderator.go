// Package moderator
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package moderator

import (
	"context"

	v1 "hotgo/api/api/moderator/v1"
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/service"
)

// Controller C端版主工作台控制器
type Controller struct{}

// NewV1 创建C端版主工作台控制器
func NewV1() *Controller {
	return &Controller{}
}

// MyBoards 我管理的版块列表
func (c *Controller) MyBoards(ctx context.Context, req *v1.MyBoardsReq) (res *v1.MyBoardsRes, err error) {
	data, err := service.SysApiModerator().MyBoards(ctx)
	if err != nil {
		return
	}

	res = new(v1.MyBoardsRes)
	res.ApiModeratorMyBoardsModel = data
	return
}

// Permission 我在指定版块的权限
func (c *Controller) Permission(ctx context.Context, req *v1.PermissionReq) (res *v1.PermissionRes, err error) {
	data, err := service.SysApiModerator().Permission(ctx, &req.ApiModeratorPermissionInp)
	if err != nil {
		return
	}

	res = new(v1.PermissionRes)
	res.ApiModeratorPermissionModel = data
	return
}

// PendingPosts 本版待审帖子
func (c *Controller) PendingPosts(ctx context.Context, req *v1.PendingPostsReq) (res *v1.PendingPostsRes, err error) {
	list, totalCount, err := service.SysApiModerator().PendingPosts(ctx, &req.ApiModeratorPendingPostListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*apiin.ApiModeratorPendingPostModel{}
	}

	res = new(v1.PendingPostsRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// PendingComments 本版待审评论
func (c *Controller) PendingComments(ctx context.Context, req *v1.PendingCommentsReq) (res *v1.PendingCommentsRes, err error) {
	list, totalCount, err := service.SysApiModerator().PendingComments(ctx, &req.ApiModeratorPendingCommentListInp)
	if err != nil {
		return
	}

	if list == nil {
		list = []*apiin.ApiModeratorPendingCommentModel{}
	}

	res = new(v1.PendingCommentsRes)
	res.List = list
	res.PageRes.Pack(req, totalCount)
	return
}

// AuditPost 版主审核帖子
func (c *Controller) AuditPost(ctx context.Context, req *v1.AuditPostReq) (res *v1.AuditPostRes, err error) {
	if err = service.SysApiModerator().AuditPost(ctx, &req.ApiModeratorAuditPostInp); err != nil {
		return
	}

	res = new(v1.AuditPostRes)
	res.ApiModeratorOperateModel = &apiin.ApiModeratorOperateModel{Result: true}
	return
}

// AuditComment 版主审核评论
func (c *Controller) AuditComment(ctx context.Context, req *v1.AuditCommentReq) (res *v1.AuditCommentRes, err error) {
	if err = service.SysApiModerator().AuditComment(ctx, &req.ApiModeratorAuditCommentInp); err != nil {
		return
	}

	res = new(v1.AuditCommentRes)
	res.ApiModeratorOperateModel = &apiin.ApiModeratorOperateModel{Result: true}
	return
}

// TopPost 版主置顶/取消置顶
func (c *Controller) TopPost(ctx context.Context, req *v1.TopPostReq) (res *v1.TopPostRes, err error) {
	if err = service.SysApiModerator().TopPost(ctx, &req.ApiModeratorTopPostInp); err != nil {
		return
	}

	res = new(v1.TopPostRes)
	res.ApiModeratorOperateModel = &apiin.ApiModeratorOperateModel{Result: true}
	return
}

// EssencePost 版主加精/取消加精
func (c *Controller) EssencePost(ctx context.Context, req *v1.EssencePostReq) (res *v1.EssencePostRes, err error) {
	if err = service.SysApiModerator().EssencePost(ctx, &req.ApiModeratorEssencePostInp); err != nil {
		return
	}

	res = new(v1.EssencePostRes)
	res.ApiModeratorOperateModel = &apiin.ApiModeratorOperateModel{Result: true}
	return
}

// DeletePost 版主删除帖子
func (c *Controller) DeletePost(ctx context.Context, req *v1.DeletePostReq) (res *v1.DeletePostRes, err error) {
	if err = service.SysApiModerator().DeletePost(ctx, &req.ApiModeratorIdInp); err != nil {
		return
	}

	res = new(v1.DeletePostRes)
	res.ApiModeratorOperateModel = &apiin.ApiModeratorOperateModel{Result: true}
	return
}

// DeleteComment 版主删除评论
func (c *Controller) DeleteComment(ctx context.Context, req *v1.DeleteCommentReq) (res *v1.DeleteCommentRes, err error) {
	if err = service.SysApiModerator().DeleteComment(ctx, &req.ApiModeratorIdInp); err != nil {
		return
	}

	res = new(v1.DeleteCommentRes)
	res.ApiModeratorOperateModel = &apiin.ApiModeratorOperateModel{Result: true}
	return
}

// BanUser 版主封禁/禁言本版用户
func (c *Controller) BanUser(ctx context.Context, req *v1.BanUserReq) (res *v1.BanUserRes, err error) {
	if err = service.SysApiModerator().BanUser(ctx, &req.ApiModeratorBanUserInp); err != nil {
		return
	}

	res = new(v1.BanUserRes)
	res.ApiModeratorOperateModel = &apiin.ApiModeratorOperateModel{Result: true}
	return
}
