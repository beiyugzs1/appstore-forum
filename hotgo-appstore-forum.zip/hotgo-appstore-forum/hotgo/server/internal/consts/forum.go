// Package consts
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package consts

import (
	"hotgo/internal/library/dict"
	"hotgo/internal/model"
)

func init() {
	dict.RegisterEnums("reportTargetType", "举报对象类型", ReportTargetTypeOptions)
	dict.RegisterEnums("reportHandleStatus", "举报处理状态", ReportHandleStatusOptions)
}

// 举报对象类型
const (
	ReportTargetTypePost    int = 1 // 帖子
	ReportTargetTypeComment int = 2 // 评论
	ReportTargetTypeUser    int = 3 // 用户
	ReportTargetTypeApp     int = 4 // 应用
)

var ReportTargetTypeSlice = []int{
	ReportTargetTypePost,
	ReportTargetTypeComment,
	ReportTargetTypeUser,
	ReportTargetTypeApp,
}

// ReportTargetTypeOptions 举报对象类型选项
var ReportTargetTypeOptions = []*model.Option{
	dict.GenPrimaryOption(ReportTargetTypePost, "帖子"),
	dict.GenInfoOption(ReportTargetTypeComment, "评论"),
	dict.GenWarningOption(ReportTargetTypeUser, "用户"),
	dict.GenSuccessOption(ReportTargetTypeApp, "应用"),
}

// 举报处理状态
const (
	ReportHandleStatusPending int = 0 // 待处理
	ReportHandleStatusDone    int = 1 // 已处理
	ReportHandleStatusReject  int = 2 // 已驳回
)

var ReportHandleStatusSlice = []int{
	ReportHandleStatusPending,
	ReportHandleStatusDone,
	ReportHandleStatusReject,
}

// ReportHandleStatusOptions 举报处理状态选项
var ReportHandleStatusOptions = []*model.Option{
	dict.GenWarningOption(ReportHandleStatusPending, "待处理"),
	dict.GenSuccessOption(ReportHandleStatusDone, "已处理"),
	dict.GenErrorOption(ReportHandleStatusReject, "已驳回"),
}
