// Package consts
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package consts

import (
	"hotgo/internal/library/dict"
	"hotgo/internal/model"
)

func init() {
	dict.RegisterEnums("sensitiveStrategy", "敏感词处理策略", SensitiveStrategyOptions)
}

// 敏感词处理策略
const (
	SensitiveStrategyReplace int = 1 // 替换：命中词替换为指定字符
	SensitiveStrategyBlock   int = 2 // 拦截：直接拒绝发布
	SensitiveStrategyReview  int = 3 // 转待审：内容强制进入待审核
)

var SensitiveStrategySlice = []int{SensitiveStrategyReplace, SensitiveStrategyBlock, SensitiveStrategyReview}

// SensitiveStrategyOptions 敏感词处理策略选项
var SensitiveStrategyOptions = []*model.Option{
	dict.GenPrimaryOption(SensitiveStrategyReplace, "替换"),
	dict.GenErrorOption(SensitiveStrategyBlock, "拦截"),
	dict.GenWarningOption(SensitiveStrategyReview, "转待审"),
}

// SensitiveStrategyPriority 策略优先级（数值越大越优先）
func SensitiveStrategyPriority(strategy int) int {
	switch strategy {
	case SensitiveStrategyBlock:
		return 3
	case SensitiveStrategyReview:
		return 2
	case SensitiveStrategyReplace:
		return 1
	}
	return 0
}
