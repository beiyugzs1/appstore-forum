// Package consts
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package consts

import (
	"hotgo/internal/library/dict"
	"hotgo/internal/model"
)

func init() {
	dict.RegisterEnums("moderatorPermission", "版主权限", ModeratorPermissionOptions)
}

// 版主权限位（位图，可组合叠加）
const (
	ModeratorPermAuditPost     = 1 << 0 // 1  审核帖子
	ModeratorPermAuditComment  = 1 << 1 // 2  审核评论
	ModeratorPermTop           = 1 << 2 // 4  置顶帖子
	ModeratorPermEssence       = 1 << 3 // 8  加精帖子
	ModeratorPermDeletePost    = 1 << 4 // 16 删除帖子
	ModeratorPermDeleteComment = 1 << 5 // 32 删除评论
	ModeratorPermBanUser       = 1 << 6 // 64 封禁本版用户
)

// ModeratorPermAll 全部版主权限
const ModeratorPermAll = ModeratorPermAuditPost | ModeratorPermAuditComment |
	ModeratorPermTop | ModeratorPermEssence |
	ModeratorPermDeletePost | ModeratorPermDeleteComment | ModeratorPermBanUser

// ModeratorPermissionOptions 版主权限选项
var ModeratorPermissionOptions = []*model.Option{
	dict.GenPrimaryOption(ModeratorPermAuditPost, "审核帖子"),
	dict.GenPrimaryOption(ModeratorPermAuditComment, "审核评论"),
	dict.GenWarningOption(ModeratorPermTop, "置顶帖子"),
	dict.GenWarningOption(ModeratorPermEssence, "加精帖子"),
	dict.GenErrorOption(ModeratorPermDeletePost, "删除帖子"),
	dict.GenErrorOption(ModeratorPermDeleteComment, "删除评论"),
	dict.GenErrorOption(ModeratorPermBanUser, "封禁本版用户"),
}

// HasModeratorPerm 判断权限位图中是否包含指定权限
func HasModeratorPerm(permissions, perm int) bool {
	return permissions&perm == perm
}
