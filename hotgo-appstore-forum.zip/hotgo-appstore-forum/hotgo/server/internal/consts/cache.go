// Package consts
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2023 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package consts

// cache
const (
	CacheToken           = "token"            // 登录token
	CacheTokenBind       = "token_bind"       // 登录用户身份绑定
	CacheMultipartUpload = "multipart_upload" // 分片上传
	CacheApiRefresh      = "token_api_refresh" // C端刷新令牌(access/refresh双令牌)
	CacheApiCaptcha      = "api_captcha"       // C端图形验证码
	CacheModeratorPerm   = "moderator_perm"    // 版主权限位缓存
	CacheSensitiveWords  = "sensitive_words"   // 敏感词库缓存
)
