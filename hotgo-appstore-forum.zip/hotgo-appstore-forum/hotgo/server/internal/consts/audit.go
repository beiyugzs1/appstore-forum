// Package consts
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package consts

import (
	"hotgo/internal/library/dict"
	"hotgo/internal/model"
)

func init() {
	dict.RegisterEnums("auditStatus", "审核状态", AuditStatusOptions)
	dict.RegisterEnums("shelfStatus", "上架状态", ShelfStatusOptions)
	dict.RegisterEnums("submitType", "提交来源", SubmitTypeOptions)
}

// 审核状态
const (
	AuditStatusPending int = 0 // 待审核
	AuditStatusPass    int = 1 // 已通过
	AuditStatusReject  int = 2 // 已驳回
)

var AuditStatusSlice = []int{AuditStatusPending, AuditStatusPass, AuditStatusReject}

// AuditStatusOptions 审核状态选项
var AuditStatusOptions = []*model.Option{
	dict.GenWarningOption(AuditStatusPending, "待审核"),
	dict.GenSuccessOption(AuditStatusPass, "已通过"),
	dict.GenErrorOption(AuditStatusReject, "已驳回"),
}

// 上架状态
const (
	ShelfStatusOn  int = 1 // 已上架
	ShelfStatusOff int = 2 // 已下架
)

var ShelfStatusSlice = []int{ShelfStatusOn, ShelfStatusOff}

// ShelfStatusOptions 上架状态选项
var ShelfStatusOptions = []*model.Option{
	dict.GenSuccessOption(ShelfStatusOn, "已上架"),
	dict.GenDefaultOption(ShelfStatusOff, "已下架"),
}

// 应用提交来源
const (
	SubmitTypeAdmin     int = 1 // 后台录入
	SubmitTypeDeveloper int = 2 // 开发者提交
)

// SubmitTypeOptions 提交来源选项
var SubmitTypeOptions = []*model.Option{
	dict.GenInfoOption(SubmitTypeAdmin, "后台录入"),
	dict.GenPrimaryOption(SubmitTypeDeveloper, "开发者提交"),
}
