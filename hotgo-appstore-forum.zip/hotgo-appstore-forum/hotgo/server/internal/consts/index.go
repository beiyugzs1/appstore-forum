// Package consts
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2023 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package consts

// 数据库索引类型，供通用查询处理器（hgorm/handler/sorter）识别排序字段
const (
	DBIndexPK  = "PRI" // 主键索引
	DBIndexUNI = "UNI" // 唯一索引
)
