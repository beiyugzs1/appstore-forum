// Package consts
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package consts

import (
	"hotgo/internal/library/dict"
	"hotgo/internal/model"
)

func init() {
	dict.RegisterEnums("banType", "封禁类型", BanTypeOptions)
	dict.RegisterEnums("banScope", "封禁范围", BanScopeOptions)
	dict.RegisterEnums("banStatus", "封禁状态", BanStatusOptions)
}

// 封禁类型：决定拦截路径（能否登录 / 能否发言）
const (
	BanTypeBan  int = 1 // 封禁：禁止登录
	BanTypeMute int = 2 // 禁言：可登录，但禁止发帖/评论/举报
)

var BanTypeSlice = []int{BanTypeBan, BanTypeMute}

// BanTypeOptions 封禁类型选项
var BanTypeOptions = []*model.Option{
	dict.GenErrorOption(BanTypeBan, "封禁"),
	dict.GenWarningOption(BanTypeMute, "禁言"),
}

// 封禁范围：决定拦截作用域
const (
	BanScopeGlobal int = 1 // 全局
	BanScopeBoard  int = 2 // 指定版块
)

var BanScopeSlice = []int{BanScopeGlobal, BanScopeBoard}

// BanScopeOptions 封禁范围选项
var BanScopeOptions = []*model.Option{
	dict.GenErrorOption(BanScopeGlobal, "全局"),
	dict.GenPrimaryOption(BanScopeBoard, "指定版块"),
}

// 封禁状态
const (
	BanStatusActive   int = 1 // 生效中
	BanStatusRelieved int = 2 // 已解除
)

var BanStatusSlice = []int{BanStatusActive, BanStatusRelieved}

// BanStatusOptions 封禁状态选项
var BanStatusOptions = []*model.Option{
	dict.GenErrorOption(BanStatusActive, "生效中"),
	dict.GenDefaultOption(BanStatusRelieved, "已解除"),
}

// 操作人类型
const (
	BanOperatorAdmin     int = 1 // 后台管理员
	BanOperatorModerator int = 2 // 版主
)

// 封禁校验动作
const (
	BanActionLogin   = "login"   // 登录
	BanActionPost    = "post"    // 发帖
	BanActionComment = "comment" // 评论
	BanActionReport  = "report"  // 举报
)
