// Package consts
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package consts

import (
	"hotgo/internal/library/dict"
	"hotgo/internal/model"
)

func init() {
	dict.RegisterEnums("vipPlanType", "VIP套餐类型", VipPlanTypeOptions)
	dict.RegisterEnums("vipCardStatus", "卡密状态", VipCardStatusOptions)
}

// VIP套餐类型
const (
	VipPlanTypeMonth   int = 1 // 月卡
	VipPlanTypeQuarter int = 2 // 季卡
	VipPlanTypeYear    int = 3 // 年卡
)

var VipPlanTypeSlice = []int{VipPlanTypeMonth, VipPlanTypeQuarter, VipPlanTypeYear}

// VipPlanTypeOptions VIP套餐类型选项
var VipPlanTypeOptions = []*model.Option{
	dict.GenPrimaryOption(VipPlanTypeMonth, "月卡"),
	dict.GenInfoOption(VipPlanTypeQuarter, "季卡"),
	dict.GenWarningOption(VipPlanTypeYear, "年卡"),
}

// 卡密状态
const (
	VipCardStatusUnused   int = 1 // 未使用
	VipCardStatusUsed     int = 2 // 已使用
	VipCardStatusDisabled int = 3 // 已禁用
)

var VipCardStatusSlice = []int{VipCardStatusUnused, VipCardStatusUsed, VipCardStatusDisabled}

// VipCardStatusOptions 卡密状态选项
var VipCardStatusOptions = []*model.Option{
	dict.GenWarningOption(VipCardStatusUnused, "未使用"),
	dict.GenSuccessOption(VipCardStatusUsed, "已使用"),
	dict.GenErrorOption(VipCardStatusDisabled, "已禁用"),
}
