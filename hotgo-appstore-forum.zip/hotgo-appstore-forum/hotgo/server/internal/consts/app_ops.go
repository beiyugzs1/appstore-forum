// Package consts
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package consts

import (
	"hotgo/internal/library/dict"
	"hotgo/internal/model"
)

func init() {
	dict.RegisterEnums("announcementType", "公告类型", AnnouncementTypeOptions)
	dict.RegisterEnums("announcementTarget", "公告跳转类型", AnnouncementTargetOptions)
	dict.RegisterEnums("announcementPopupFrequency", "公告弹窗频率", AnnouncementPopupFrequencyOptions)
	dict.RegisterEnums("versionPlatform", "客户端平台", VersionPlatformOptions)
	dict.RegisterEnums("androidUpdateStrategy", "客户端更新策略", AndroidUpdateStrategyOptions)
	dict.RegisterEnums("adType", "广告类型", AdTypeOptions)
	dict.RegisterEnums("adLinkType", "广告跳转类型", AdLinkTypeOptions)
	dict.RegisterEnums("adPlatform", "投放平台", AdPlatformOptions)
}

// =========================== 公告 ===========================

// 公告类型
const (
	AnnouncementTypeNotify   int = 1 // 通知
	AnnouncementTypeNotice   int = 2 // 公告
	AnnouncementTypeActivity int = 3 // 活动
)

var AnnouncementTypeSlice = []int{AnnouncementTypeNotify, AnnouncementTypeNotice, AnnouncementTypeActivity}

// AnnouncementTypeOptions 公告类型选项
var AnnouncementTypeOptions = []*model.Option{
	dict.GenPrimaryOption(AnnouncementTypeNotify, "通知"),
	dict.GenInfoOption(AnnouncementTypeNotice, "公告"),
	dict.GenSuccessOption(AnnouncementTypeActivity, "活动"),
}

// 公告发布状态
const (
	AnnouncementDraft     int = 0 // 草稿
	AnnouncementPublished int = 1 // 已发布
)

var AnnouncementPublishedSlice = []int{AnnouncementDraft, AnnouncementPublished}

// 跳转类型（公告与广告共用语义）
const (
	LinkTargetNone   int = 0 // 无跳转
	LinkTargetInner  int = 1 // 站内
	LinkTargetOuter  int = 2 // 外链
)

var LinkTargetSlice = []int{LinkTargetNone, LinkTargetInner, LinkTargetOuter}

// AnnouncementTargetOptions 公告跳转类型选项
var AnnouncementTargetOptions = []*model.Option{
	dict.GenDefaultOption(LinkTargetNone, "无跳转"),
	dict.GenPrimaryOption(LinkTargetInner, "站内跳转"),
	dict.GenInfoOption(LinkTargetOuter, "外部链接"),
}

// 公告弹窗频率
const (
	PopupFrequencyEvery int = 0 // 每次启动都弹
	PopupFrequencyDaily int = 1 // 每日一次
	PopupFrequencyOnce  int = 2 // 仅一次
)

var PopupFrequencySlice = []int{PopupFrequencyEvery, PopupFrequencyDaily, PopupFrequencyOnce}

// AnnouncementPopupFrequencyOptions 公告弹窗频率选项
var AnnouncementPopupFrequencyOptions = []*model.Option{
	dict.GenDefaultOption(PopupFrequencyEvery, "每次启动"),
	dict.GenPrimaryOption(PopupFrequencyDaily, "每日一次"),
	dict.GenInfoOption(PopupFrequencyOnce, "仅弹一次"),
}

// =========================== 版本更新 ===========================

// 客户端平台
const (
	VersionPlatformAndroid int = 1 // Android
	VersionPlatformIOS     int = 2 // iOS
)

var VersionPlatformSlice = []int{VersionPlatformAndroid, VersionPlatformIOS}

// VersionPlatformOptions 客户端平台选项
var VersionPlatformOptions = []*model.Option{
	dict.GenSuccessOption(VersionPlatformAndroid, "Android"),
	dict.GenDefaultOption(VersionPlatformIOS, "iOS"),
}

// 更新策略
const (
	UpdateStrategyTip       int = 1 // 仅提示
	UpdateStrategyRecommend int = 2 // 推荐更新
	UpdateStrategyForce     int = 3 // 强制更新
)

var UpdateStrategySlice = []int{UpdateStrategyTip, UpdateStrategyRecommend, UpdateStrategyForce}

// AndroidUpdateStrategyOptions 更新策略选项
var AndroidUpdateStrategyOptions = []*model.Option{
	dict.GenDefaultOption(UpdateStrategyTip, "仅提示"),
	dict.GenWarningOption(UpdateStrategyRecommend, "推荐更新"),
	dict.GenErrorOption(UpdateStrategyForce, "强制更新"),
}

// =========================== 广告 ===========================

// 广告素材类型
const (
	AdTypeImage int = 1 // 图片
	AdTypeVideo int = 2 // 视频
	AdTypeText  int = 3 // 文字
	AdTypeH5    int = 4 // H5
)

var AdTypeSlice = []int{AdTypeImage, AdTypeVideo, AdTypeText, AdTypeH5}

// AdTypeOptions 广告类型选项
var AdTypeOptions = []*model.Option{
	dict.GenPrimaryOption(AdTypeImage, "图片"),
	dict.GenInfoOption(AdTypeVideo, "视频"),
	dict.GenDefaultOption(AdTypeText, "文字"),
	dict.GenWarningOption(AdTypeH5, "H5"),
}

// AdLinkTypeOptions 广告跳转类型选项
var AdLinkTypeOptions = []*model.Option{
	dict.GenDefaultOption(LinkTargetNone, "无跳转"),
	dict.GenPrimaryOption(LinkTargetInner, "站内应用"),
	dict.GenInfoOption(LinkTargetOuter, "外部链接"),
}

// 投放平台
const (
	AdPlatformAll     string = "all"     // 全平台
	AdPlatformAndroid string = "android" // Android
	AdPlatformIOS     string = "ios"     // iOS
)

var AdPlatformSlice = []string{AdPlatformAll, AdPlatformAndroid, AdPlatformIOS}

// AdPlatformOptions 投放平台选项
var AdPlatformOptions = []*model.Option{
	dict.GenDefaultOption(AdPlatformAll, "全平台"),
	dict.GenSuccessOption(AdPlatformAndroid, "Android"),
	dict.GenInfoOption(AdPlatformIOS, "iOS"),
}

// 曝光/点击上报事件
const (
	AdEventView  string = "view"  // 曝光
	AdEventClick string = "click" // 点击
)
