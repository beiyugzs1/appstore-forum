// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/internal/consts"
	"hotgo/internal/dao"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/os/gtime"
)

type sSysDashboard struct{}

func NewSysDashboard() *sSysDashboard {
	return &sSysDashboard{}
}

func init() {
	service.RegisterSysDashboard(NewSysDashboard())
}

// Statistics 获取看板统计数据
func (s *sSysDashboard) Statistics(ctx context.Context) (res *sysin.DashboardStatisticsModel, err error) {
	res = new(sysin.DashboardStatisticsModel)
	now := gtime.Now()
	todayStart := gtime.NewFromTime(now.Time).StartOfDay()

	// 用户
	if res.UserCount, err = dao.User.Ctx(ctx).Count(); err != nil {
		err = gerror.Wrap(err, "统计用户总数失败")
		return
	}
	if res.VipUserCount, err = dao.User.Ctx(ctx).
		Where(dao.User.Columns().VipExpireAt+" > ?", now).Count(); err != nil {
		err = gerror.Wrap(err, "统计VIP用户数失败")
		return
	}
	if res.TodayUserCount, err = dao.User.Ctx(ctx).
		WhereGTE(dao.User.Columns().CreatedAt, todayStart).Count(); err != nil {
		err = gerror.Wrap(err, "统计今日新增用户失败")
		return
	}

	// 应用
	if res.AppCount, err = dao.Application.Ctx(ctx).Count(); err != nil {
		err = gerror.Wrap(err, "统计应用总数失败")
		return
	}
	if res.AppOnlineCount, err = dao.Application.Ctx(ctx).
		Where(dao.Application.Columns().ShelfStatus, consts.ShelfStatusOn).Count(); err != nil {
		err = gerror.Wrap(err, "统计已上架应用数失败")
		return
	}
	if res.AppPendingAudit, err = dao.Application.Ctx(ctx).
		Where(dao.Application.Columns().AuditStatus, consts.AuditStatusPending).Count(); err != nil {
		err = gerror.Wrap(err, "统计待审应用数失败")
		return
	}
	if res.TodayAppCount, err = dao.Application.Ctx(ctx).
		WhereGTE(dao.Application.Columns().CreatedAt, todayStart).Count(); err != nil {
		err = gerror.Wrap(err, "统计今日新增应用失败")
		return
	}

	// 论坛
	if res.PostCount, err = dao.ForumPost.Ctx(ctx).Count(); err != nil {
		err = gerror.Wrap(err, "统计帖子总数失败")
		return
	}
	if res.PostPendingAudit, err = dao.ForumPost.Ctx(ctx).
		Where(dao.ForumPost.Columns().AuditStatus, consts.AuditStatusPending).Count(); err != nil {
		err = gerror.Wrap(err, "统计待审帖子数失败")
		return
	}
	if res.CommentPendingAudit, err = dao.ForumComment.Ctx(ctx).
		Where(dao.ForumComment.Columns().AuditStatus, consts.AuditStatusPending).Count(); err != nil {
		err = gerror.Wrap(err, "统计待审评论数失败")
		return
	}
	if res.TodayPostCount, err = dao.ForumPost.Ctx(ctx).
		WhereGTE(dao.ForumPost.Columns().CreatedAt, todayStart).Count(); err != nil {
		err = gerror.Wrap(err, "统计今日新增帖子失败")
		return
	}
	if res.BoardCount, err = dao.ForumBoard.Ctx(ctx).Count(); err != nil {
		err = gerror.Wrap(err, "统计版块数失败")
		return
	}

	// 举报
	if res.ReportPendingHandle, err = dao.Report.Ctx(ctx).
		Where(dao.Report.Columns().HandleStatus, consts.ReportHandleStatusPending).Count(); err != nil {
		err = gerror.Wrap(err, "统计待处理举报数失败")
		return
	}

	// 卡密
	if res.CardUnusedCount, err = dao.VipCard.Ctx(ctx).
		Where(dao.VipCard.Columns().Status, consts.VipCardStatusUnused).Count(); err != nil {
		err = gerror.Wrap(err, "统计可用卡密数失败")
		return
	}
	if res.CardUsedCount, err = dao.VipCard.Ctx(ctx).
		Where(dao.VipCard.Columns().Status, consts.VipCardStatusUsed).Count(); err != nil {
		err = gerror.Wrap(err, "统计已激活卡密数失败")
		return
	}
	if res.PlanCount, err = dao.VipPlan.Ctx(ctx).Count(); err != nil {
		err = gerror.Wrap(err, "统计VIP套餐数失败")
		return
	}

	return
}
