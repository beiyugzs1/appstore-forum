// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"

	"hotgo/internal/consts"
	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/encoding/gjson"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
)

type sSysApiReport struct{}

func NewSysApiReport() *sSysApiReport {
	return &sSysApiReport{}
}

func init() {
	service.RegisterSysApiReport(NewSysApiReport())
}

// Submit 提交举报
func (s *sSysApiReport) Submit(ctx context.Context, in *apiin.ApiReportSubmitInp) (res *apiin.ApiReportSubmitModel, err error) {
	userId := contexts.GetUserId(ctx)
	if userId <= 0 {
		err = gerror.New("登录身份已失效，请重新登录")
		return
	}

	// 封禁/禁言校验（举报为全局动作，不受版块范围影响）
	if banned, msg, banErr := service.SysUserBan().Check(ctx, userId, 0, consts.BanActionReport); banErr != nil {
		err = banErr
		return
	} else if banned {
		err = gerror.New(msg)
		return
	}

	// 同一用户对同一对象的重复举报限制
	count, err := dao.Report.Ctx(ctx).
		Where(dao.Report.Columns().UserId, userId).
		Where(dao.Report.Columns().TargetType, in.TargetType).
		Where(dao.Report.Columns().TargetId, in.TargetId).
		Where(dao.Report.Columns().HandleStatus, consts.ReportHandleStatusPending).Count()
	if err != nil {
		err = gerror.Wrap(err, "校验举报失败，请稍后重试！")
		return
	}
	if count > 0 {
		err = gerror.New("你已提交过举报，请等待处理")
		return
	}

	id, err := dao.Report.Ctx(ctx).Data(g.Map{
		dao.Report.Columns().UserId:        userId,
		dao.Report.Columns().TargetType:    in.TargetType,
		dao.Report.Columns().TargetId:      in.TargetId,
		dao.Report.Columns().Reason:        in.Reason,
		dao.Report.Columns().Description:   in.Description,
		dao.Report.Columns().Images:        gjson.MustEncodeString(in.Images),
		dao.Report.Columns().HandleStatus:  consts.ReportHandleStatusPending,
		dao.Report.Columns().Status:        consts.StatusEnabled,
		dao.Report.Columns().CreatedAt:     gtime.Now(),
		dao.Report.Columns().UpdatedAt:     gtime.Now(),
	}).InsertAndGetId()
	if err != nil {
		err = gerror.Wrap(err, "提交举报失败，请稍后重试！")
		return
	}

	res = &apiin.ApiReportSubmitModel{Id: id}
	return
}
