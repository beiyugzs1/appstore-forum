// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"

	"hotgo/internal/consts"
	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/model/entity"
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/encoding/gjson"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
	"github.com/gogf/gf/v2/util/gconv"
)

type sSysApiApp struct{}

func NewSysApiApp() *sSysApiApp {
	return &sSysApiApp{}
}

func init() {
	service.RegisterSysApiApp(NewSysApiApp())
}

// jsonToStrings JSON 数组转字符串切片
func jsonToStrings(j *gjson.Json) []string {
	out := make([]string, 0)
	if j == nil {
		return out
	}
	for _, v := range j.Array() {
		out = append(out, gconv.String(v))
	}
	return out
}

// CategoryList 获取应用分类列表
func (s *sSysApiApp) CategoryList(ctx context.Context) (res *apiin.ApiAppCategoryListModel, err error) {
	res = &apiin.ApiAppCategoryListModel{List: make([]*apiin.ApiAppCategoryModel, 0)}

	if err = dao.AppCategory.Ctx(ctx).
		Where(dao.AppCategory.Columns().Status, consts.StatusEnabled).
		Fields(
			dao.AppCategory.Columns().Id,
			dao.AppCategory.Columns().Name,
			dao.AppCategory.Columns().Icon,
		).
		OrderAsc(dao.AppCategory.Columns().Sort).
		OrderAsc(dao.AppCategory.Columns().Id).
		Scan(&res.List); err != nil {
		err = gerror.Wrap(err, "获取应用分类失败，请稍后重试！")
		return
	}
	if res.List == nil {
		res.List = make([]*apiin.ApiAppCategoryModel, 0)
	}
	return
}

// List 获取应用列表（仅审核通过且已上架）
func (s *sSysApiApp) List(ctx context.Context, in *apiin.ApiAppListInp) (list []*apiin.ApiAppListModel, totalCount int, err error) {
	mod := dao.Application.Ctx(ctx).As("a").
		LeftJoin(dao.AppCategory.Table(), dao.AppCategory.Table()+"."+dao.AppCategory.Columns().Id+" = a."+dao.Application.Columns().CategoryId).
		Fields("a." + dao.Application.Columns().Id + " as id, " +
			"a." + dao.Application.Columns().CategoryId + " as categoryId, " +
			"a." + dao.Application.Columns().Name + " as name, " +
			"a." + dao.Application.Columns().Logo + " as logo, " +
			"a." + dao.Application.Columns().PackageName + " as packageName, " +
			"a." + dao.Application.Columns().VersionName + " as versionName, " +
			"a." + dao.Application.Columns().VersionCode + " as versionCode, " +
			"a." + dao.Application.Columns().FileSize + " as fileSize, " +
			"a." + dao.Application.Columns().Description + " as description, " +
			"a." + dao.Application.Columns().DeveloperName + " as developerName, " +
			"a." + dao.Application.Columns().DownloadCount + " as downloadCount, " +
			"a." + dao.Application.Columns().VipOnly + " as vipOnly, " +
			dao.AppCategory.Table() + "." + dao.AppCategory.Columns().Name + " as categoryName").
		Where("a."+dao.Application.Columns().AuditStatus, consts.AuditStatusPass).
		Where("a."+dao.Application.Columns().ShelfStatus, consts.ShelfStatusOn).
		Where("a."+dao.Application.Columns().Status, consts.StatusEnabled)

	if in.CategoryId > 0 {
		mod = mod.Where("a."+dao.Application.Columns().CategoryId, in.CategoryId)
	}
	if in.Keyword != "" {
		mod = mod.Where("(a."+dao.Application.Columns().Name+" like ? OR a."+dao.Application.Columns().PackageName+" like ?)", "%"+in.Keyword+"%", "%"+in.Keyword+"%")
	}

	mod = mod.Page(in.Page, in.PerPage).
		OrderAsc("a."+dao.Application.Columns().Sort).
		OrderDesc("a."+dao.Application.Columns().Id)

	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取应用列表失败，请稍后重试！")
		return
	}
	return
}

// apiAppDetailRow 应用详情查询行
type apiAppDetailRow struct {
	Id            int64       `json:"id"`
	CategoryId    int64       `json:"categoryId"`
	CategoryName  string      `json:"categoryName"`
	Name          string      `json:"name"`
	Logo          string      `json:"logo"`
	PackageName   string      `json:"packageName"`
	VersionName   string      `json:"versionName"`
	VersionCode   int         `json:"versionCode"`
	FileSize      int64       `json:"fileSize"`
	FileMd5       string      `json:"fileMd5"`
	Description   string      `json:"description"`
	Screenshots   *gjson.Json `json:"screenshots"`
	DownloadUrl   string      `json:"downloadUrl"`
	DeveloperId   int64       `json:"developerId"`
	DeveloperName string      `json:"developerName"`
	DownloadCount int         `json:"downloadCount"`
	ViewCount     int         `json:"viewCount"`
	VipOnly       int         `json:"vipOnly"`
	UpdatedAt     *gtime.Time `json:"updatedAt"`
}

// Detail 获取应用详情
func (s *sSysApiApp) Detail(ctx context.Context, in *apiin.ApiAppDetailInp) (res *apiin.ApiAppDetailModel, err error) {
	var row *apiAppDetailRow

	if err = dao.Application.Ctx(ctx).As("a").
		LeftJoin(dao.AppCategory.Table(), dao.AppCategory.Table()+"."+dao.AppCategory.Columns().Id+" = a."+dao.Application.Columns().CategoryId).
		Fields("a.*, " + dao.AppCategory.Table() + "." + dao.AppCategory.Columns().Name + " as categoryName").
		Where("a."+dao.Application.Columns().Id, in.Id).
		Where("a."+dao.Application.Columns().AuditStatus, consts.AuditStatusPass).
		Where("a."+dao.Application.Columns().ShelfStatus, consts.ShelfStatusOn).
		Where("a."+dao.Application.Columns().Status, consts.StatusEnabled).
		Scan(&row); err != nil {
		err = gerror.Wrap(err, "获取应用详情失败，请稍后重试！")
		return
	}
	if row == nil {
		err = gerror.New("应用不存在或已下架")
		return
	}

	// 浏览量自增
	if _, err = dao.Application.Ctx(ctx).WherePri(in.Id).
		Increment(dao.Application.Columns().ViewCount, 1); err != nil {
		err = nil // 统计失败不影响主流程
	}

	res = &apiin.ApiAppDetailModel{
		Id:            row.Id,
		CategoryId:    row.CategoryId,
		CategoryName:  row.CategoryName,
		Name:          row.Name,
		Logo:          row.Logo,
		PackageName:   row.PackageName,
		VersionName:   row.VersionName,
		VersionCode:   row.VersionCode,
		FileSize:      row.FileSize,
		FileMd5:       row.FileMd5,
		Description:   row.Description,
		Screenshots:   jsonToStrings(row.Screenshots),
		DownloadUrl:   row.DownloadUrl,
		DeveloperId:   row.DeveloperId,
		DeveloperName: row.DeveloperName,
		DownloadCount: row.DownloadCount,
		ViewCount:     row.ViewCount,
		VipOnly:       row.VipOnly,
		UpdatedAt:     row.UpdatedAt,
	}

	// 会员专属应用：非会员不返回下载地址，App 据此展示开通引导
	if row.VipOnly == 1 {
		isVip, _, _ := currentUserIsVip(ctx)
		if !isVip {
			res.DownloadUrl = ""
			res.VipRequired = true
		}
	}
	return
}

// Submit 开发者提交应用（待审核）
func (s *sSysApiApp) Submit(ctx context.Context, in *apiin.ApiAppSubmitInp) (res *apiin.ApiAppSubmitModel, err error) {
	userId := contexts.GetUserId(ctx)
	if userId <= 0 {
		err = gerror.New("登录身份已失效，请重新登录")
		return
	}

	// 分类校验
	categoryCount, err := dao.AppCategory.Ctx(ctx).WherePri(in.CategoryId).
		Where(dao.AppCategory.Columns().Status, consts.StatusEnabled).Count()
	if err != nil {
		err = gerror.Wrap(err, "校验应用分类失败，请稍后重试！")
		return
	}
	if categoryCount == 0 {
		err = gerror.New("应用分类不存在或已禁用")
		return
	}

	// 同一开发者同一包名只允许存在一条待审记录
	count, err := dao.Application.Ctx(ctx).
		Where(dao.Application.Columns().DeveloperId, userId).
		Where(dao.Application.Columns().PackageName, in.PackageName).
		Where(dao.Application.Columns().AuditStatus, consts.AuditStatusPending).Count()
	if err != nil {
		err = gerror.Wrap(err, "校验应用失败，请稍后重试！")
		return
	}
	if count > 0 {
		err = gerror.New("该包名已有待审核的应用，请勿重复提交")
		return
	}

	var user *entity.User
	if err = dao.User.Ctx(ctx).WherePri(userId).Scan(&user); err != nil {
		err = gerror.Wrap(err, "获取用户信息失败，请稍后重试！")
		return
	}

	developerName := ""
	if user != nil {
		developerName = user.Nickname
		if developerName == "" {
			developerName = user.Username
		}
	}

	id, err := dao.Application.Ctx(ctx).Data(g.Map{
		dao.Application.Columns().CategoryId:    in.CategoryId,
		dao.Application.Columns().Name:          in.Name,
		dao.Application.Columns().Logo:          in.Logo,
		dao.Application.Columns().PackageName:   in.PackageName,
		dao.Application.Columns().VersionName:   in.VersionName,
		dao.Application.Columns().VersionCode:   in.VersionCode,
		dao.Application.Columns().FileSize:      in.FileSize,
		dao.Application.Columns().FileMd5:       in.FileMd5,
		dao.Application.Columns().Description:   in.Description,
		dao.Application.Columns().Screenshots:   gjson.MustEncodeString(in.Screenshots),
		dao.Application.Columns().DownloadUrl:   in.DownloadUrl,
		dao.Application.Columns().DeveloperId:   userId,
		dao.Application.Columns().DeveloperName: developerName,
		dao.Application.Columns().SubmitType:    consts.SubmitTypeDeveloper,
		dao.Application.Columns().AuditStatus:   consts.AuditStatusPending,
		dao.Application.Columns().ShelfStatus:   consts.ShelfStatusOff,
		dao.Application.Columns().Status:        consts.StatusEnabled,
	}).InsertAndGetId()
	if err != nil {
		err = gerror.Wrap(err, "提交应用失败，请稍后重试！")
		return
	}

	res = &apiin.ApiAppSubmitModel{Id: id}
	return
}

// MyList 我提交的应用
func (s *sSysApiApp) MyList(ctx context.Context, in *apiin.ApiAppMyListInp) (list []*apiin.ApiAppMyListModel, totalCount int, err error) {
	userId := contexts.GetUserId(ctx)
	if userId <= 0 {
		err = gerror.New("登录身份已失效，请重新登录")
		return
	}

	mod := dao.Application.Ctx(ctx).
		Fields(
			dao.Application.Columns().Id,
			dao.Application.Columns().Name,
			dao.Application.Columns().Logo,
			dao.Application.Columns().PackageName,
			dao.Application.Columns().VersionName,
			dao.Application.Columns().AuditStatus,
			dao.Application.Columns().AuditRemark,
			dao.Application.Columns().ShelfStatus,
			dao.Application.Columns().DownloadCount,
			dao.Application.Columns().CreatedAt,
		).
		Where(dao.Application.Columns().DeveloperId, userId).
		Page(in.Page, in.PerPage).
		OrderDesc(dao.Application.Columns().Id)

	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取我的应用失败，请稍后重试！")
		return
	}
	return
}
