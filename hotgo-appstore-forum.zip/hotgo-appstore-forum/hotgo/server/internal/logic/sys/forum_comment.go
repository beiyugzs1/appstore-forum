// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/internal/consts"
	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
)

type sSysForumComment struct{}

func NewSysForumComment() *sSysForumComment {
	return &sSysForumComment{}
}

func init() {
	service.RegisterSysForumComment(NewSysForumComment())
}

// List 获取评论列表
func (s *sSysForumComment) List(ctx context.Context, in *sysin.ForumCommentListInp) (list []*sysin.ForumCommentListModel, totalCount int, err error) {
	mod := dao.ForumComment.Ctx(ctx).As("c").
		LeftJoin(dao.ForumPost.Table(), dao.ForumPost.Table()+"."+dao.ForumPost.Columns().Id+" = c."+dao.ForumComment.Columns().PostId).
		LeftJoin(dao.User.Table(), dao.User.Table()+"."+dao.User.Columns().Id+" = c."+dao.ForumComment.Columns().UserId).
		Fields("c.*, " + dao.ForumPost.Table() + "." + dao.ForumPost.Columns().Title + " as postTitle, " +
			dao.User.Table() + "." + dao.User.Columns().Nickname + " as userNickname, " +
			dao.User.Table() + "." + dao.User.Columns().Username + " as userAccount")

	if in.Id > 0 {
		mod = mod.Where("c."+dao.ForumComment.Columns().Id, in.Id)
	}
	if in.PostId > 0 {
		mod = mod.Where("c."+dao.ForumComment.Columns().PostId, in.PostId)
	}
	if in.UserId > 0 {
		mod = mod.Where("c."+dao.ForumComment.Columns().UserId, in.UserId)
	}
	if in.Content != "" {
		mod = mod.WhereLike("c."+dao.ForumComment.Columns().Content, "%"+in.Content+"%")
	}
	if in.AuditStatus >= 0 && in.AuditStatus <= 2 {
		mod = mod.Where("c."+dao.ForumComment.Columns().AuditStatus, in.AuditStatus)
	}
	if in.Status > 0 {
		mod = mod.Where("c."+dao.ForumComment.Columns().Status, in.Status)
	}
	if len(in.CreatedAt) == 2 {
		mod = mod.WhereBetween("c."+dao.ForumComment.Columns().CreatedAt, in.CreatedAt[0], in.CreatedAt[1])
	}

	mod = mod.Page(in.Page, in.PerPage).OrderDesc("c."+dao.ForumComment.Columns().Id)

	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取评论列表失败，请稍后重试！")
		return
	}
	return
}

// View 获取评论指定信息
func (s *sSysForumComment) View(ctx context.Context, in *sysin.ForumCommentViewInp) (res *sysin.ForumCommentViewModel, err error) {
	if err = dao.ForumComment.Ctx(ctx).WherePri(in.Id).Scan(&res); err != nil {
		err = gerror.Wrap(err, "获取评论信息失败，请稍后重试！")
		return
	}
	return
}

// Delete 删除评论
func (s *sSysForumComment) Delete(ctx context.Context, in *sysin.ForumCommentDeleteInp) (err error) {
	comment, err := dao.ForumComment.Ctx(ctx).WherePri(in.Id).One()
	if err != nil {
		err = gerror.Wrap(err, "获取评论失败，请稍后重试！")
		return
	}
	if comment.IsEmpty() {
		err = gerror.New("评论不存在")
		return
	}

	if _, err = dao.ForumComment.Ctx(ctx).WherePri(in.Id).Data(g.Map{
		dao.ForumComment.Columns().DeletedBy: contexts.GetUserId(ctx),
		dao.ForumComment.Columns().DeletedAt: gtime.Now(),
	}).Unscoped().Update(); err != nil {
		err = gerror.Wrap(err, "删除评论失败，请稍后重试！")
		return
	}

	_ = serviceRefreshCommentCount(ctx, comment[dao.ForumComment.Columns().PostId].Int64())
	return
}

// Status 更新评论状态
func (s *sSysForumComment) Status(ctx context.Context, in *sysin.ForumCommentStatusInp) (err error) {
	if _, err = dao.ForumComment.Ctx(ctx).WherePri(in.Id).Data(g.Map{
		dao.ForumComment.Columns().Status:    in.Status,
		dao.ForumComment.Columns().UpdatedBy: contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "更新评论状态失败，请稍后重试！")
		return
	}
	return
}

// Audit 审核评论
func (s *sSysForumComment) Audit(ctx context.Context, in *sysin.ForumCommentAuditInp) (err error) {
	comment, err := dao.ForumComment.Ctx(ctx).WherePri(in.Id).One()
	if err != nil {
		err = gerror.Wrap(err, "获取评论失败，请稍后重试！")
		return
	}
	if comment.IsEmpty() {
		err = gerror.New("评论不存在")
		return
	}

	if _, err = dao.ForumComment.Ctx(ctx).WherePri(in.Id).Data(g.Map{
		dao.ForumComment.Columns().AuditStatus: in.AuditStatus,
		dao.ForumComment.Columns().AuditRemark: in.AuditRemark,
		dao.ForumComment.Columns().AuditBy:     contexts.GetUserId(ctx),
		dao.ForumComment.Columns().AuditAt:     gtime.Now(),
		dao.ForumComment.Columns().UpdatedBy:   contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "审核评论失败，请稍后重试！")
		return
	}

	_ = serviceRefreshCommentCount(ctx, comment[dao.ForumComment.Columns().PostId].Int64())
	return
}

// serviceRefreshCommentCount 刷新帖子评论数
func serviceRefreshCommentCount(ctx context.Context, postId int64) (err error) {
	if postId <= 0 {
		return
	}

	count, err := dao.ForumComment.Ctx(ctx).
		Where(dao.ForumComment.Columns().PostId, postId).
		Where(dao.ForumComment.Columns().AuditStatus, consts.AuditStatusPass).Count()
	if err != nil {
		return
	}

	_, err = dao.ForumPost.Ctx(ctx).WherePri(postId).Data(g.Map{
		dao.ForumPost.Columns().CommentCount: count,
	}).Update()
	return
}
