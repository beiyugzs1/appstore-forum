// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/internal/consts"
	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/library/hgorm/handler"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
)

type sSysApplication struct{}

func NewSysApplication() *sSysApplication {
	return &sSysApplication{}
}

func init() {
	service.RegisterSysApplication(NewSysApplication())
}

// Model 应用ORM模型
func (s *sSysApplication) Model(ctx context.Context, option ...*handler.Option) *gdb.Model {
	return handler.Model(dao.Application.Ctx(ctx), option...)
}

// List 获取应用列表
func (s *sSysApplication) List(ctx context.Context, in *sysin.ApplicationListInp) (list []*sysin.ApplicationListModel, totalCount int, err error) {
	mod := s.Model(ctx).As("a").
		LeftJoin(dao.AppCategory.Table(), dao.AppCategory.Table()+"."+dao.AppCategory.Columns().Id+" = a."+dao.Application.Columns().CategoryId).
		Fields("a.*, " + dao.AppCategory.Table() + "." + dao.AppCategory.Columns().Name + " as categoryName")

	if in.Id > 0 {
		mod = mod.Where("a."+dao.Application.Columns().Id, in.Id)
	}
	if in.Name != "" {
		mod = mod.WhereLike("a."+dao.Application.Columns().Name, "%"+in.Name+"%")
	}
	if in.PackageName != "" {
		mod = mod.WhereLike("a."+dao.Application.Columns().PackageName, "%"+in.PackageName+"%")
	}
	if in.CategoryId > 0 {
		mod = mod.Where("a."+dao.Application.Columns().CategoryId, in.CategoryId)
	}
	if in.DeveloperName != "" {
		mod = mod.WhereLike("a."+dao.Application.Columns().DeveloperName, "%"+in.DeveloperName+"%")
	}
	if in.SubmitType > 0 {
		mod = mod.Where("a."+dao.Application.Columns().SubmitType, in.SubmitType)
	}
	if in.AuditStatus >= 0 && in.AuditStatus <= 2 {
		mod = mod.Where("a."+dao.Application.Columns().AuditStatus, in.AuditStatus)
	}
	if in.ShelfStatus > 0 {
		mod = mod.Where("a."+dao.Application.Columns().ShelfStatus, in.ShelfStatus)
	}
	if in.Status > 0 {
		mod = mod.Where("a."+dao.Application.Columns().Status, in.Status)
	}
	if in.VipOnly >= 0 {
		mod = mod.Where("a."+dao.Application.Columns().VipOnly, in.VipOnly)
	}
	if len(in.CreatedAt) == 2 {
		mod = mod.WhereBetween("a."+dao.Application.Columns().CreatedAt, in.CreatedAt[0], in.CreatedAt[1])
	}

	mod = mod.Page(in.Page, in.PerPage).
		OrderAsc("a."+dao.Application.Columns().Sort).
		OrderDesc("a."+dao.Application.Columns().Id)

	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取应用列表失败，请稍后重试！")
		return
	}
	return
}

// View 获取应用指定信息
func (s *sSysApplication) View(ctx context.Context, in *sysin.ApplicationViewInp) (res *sysin.ApplicationViewModel, err error) {
	if err = s.Model(ctx).WherePri(in.Id).Scan(&res); err != nil {
		err = gerror.Wrap(err, "获取应用信息失败，请稍后重试！")
		return
	}
	return
}

// Edit 修改/新增应用
func (s *sSysApplication) Edit(ctx context.Context, in *sysin.ApplicationEditInp) (err error) {
	return g.DB().Transaction(ctx, func(ctx context.Context, tx gdb.TX) (err error) {
		categoryCount, err := dao.AppCategory.Ctx(ctx).WherePri(in.CategoryId).Count()
		if err != nil {
			err = gerror.Wrap(err, "校验应用分类失败，请稍后重试！")
			return
		}
		if categoryCount == 0 {
			err = gerror.New("应用分类不存在")
			return
		}

		// 修改
		if in.Id > 0 {
			in.UpdatedBy = contexts.GetUserId(ctx)
			if _, err = s.Model(ctx).
				Fields(sysin.ApplicationUpdateFields{}).
				WherePri(in.Id).Data(in).Update(); err != nil {
				err = gerror.Wrap(err, "修改应用失败，请稍后重试！")
			}
			return
		}

		// 新增：后台录入默认审核通过，需人工上架
		in.CreatedBy = contexts.GetUserId(ctx)
		in.SubmitType = consts.SubmitTypeAdmin
		in.AuditStatus = consts.AuditStatusPass
		in.ShelfStatus = consts.ShelfStatusOff
		if in.AuditBy == 0 {
			in.AuditBy = contexts.GetUserId(ctx)
			in.AuditAt = gtime.Now()
		}

		if _, err = s.Model(ctx, &handler.Option{FilterAuth: false}).
			Fields(sysin.ApplicationInsertFields{}).
			Data(in).OmitEmptyData().Insert(); err != nil {
			err = gerror.Wrap(err, "新增应用失败，请稍后重试！")
		}
		return
	})
}

// Delete 删除应用
func (s *sSysApplication) Delete(ctx context.Context, in *sysin.ApplicationDeleteInp) (err error) {
	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.Application.Columns().DeletedBy: contexts.GetUserId(ctx),
		dao.Application.Columns().DeletedAt: gtime.Now(),
	}).Unscoped().Update(); err != nil {
		err = gerror.Wrap(err, "删除应用失败，请稍后重试！")
		return
	}
	return
}

// Status 更新应用状态
func (s *sSysApplication) Status(ctx context.Context, in *sysin.ApplicationStatusInp) (err error) {
	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.Application.Columns().Status:    in.Status,
		dao.Application.Columns().UpdatedBy: contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "更新应用状态失败，请稍后重试！")
		return
	}
	return
}

// Audit 审核应用
func (s *sSysApplication) Audit(ctx context.Context, in *sysin.ApplicationAuditInp) (err error) {
	app, err := s.Model(ctx).WherePri(in.Id).One()
	if err != nil {
		err = gerror.Wrap(err, "获取应用失败，请稍后重试！")
		return
	}
	if app.IsEmpty() {
		err = gerror.New("应用不存在")
		return
	}

	data := g.Map{
		dao.Application.Columns().AuditStatus: in.AuditStatus,
		dao.Application.Columns().AuditRemark: in.AuditRemark,
		dao.Application.Columns().AuditBy:     contexts.GetUserId(ctx),
		dao.Application.Columns().AuditAt:     gtime.Now(),
		dao.Application.Columns().UpdatedBy:   contexts.GetUserId(ctx),
	}

	// 审核不通过时自动下架
	if in.AuditStatus == consts.AuditStatusReject {
		data[dao.Application.Columns().ShelfStatus] = consts.ShelfStatusOff
	}

	if _, err = s.Model(ctx).WherePri(in.Id).Data(data).Update(); err != nil {
		err = gerror.Wrap(err, "审核应用失败，请稍后重试！")
		return
	}
	return
}

// Shelf 应用上下架
func (s *sSysApplication) Shelf(ctx context.Context, in *sysin.ApplicationShelfInp) (err error) {
	app, err := s.Model(ctx).WherePri(in.Id).One()
	if err != nil {
		err = gerror.Wrap(err, "获取应用失败，请稍后重试！")
		return
	}
	if app.IsEmpty() {
		err = gerror.New("应用不存在")
		return
	}

	// 上架前必须审核通过且下载地址完整
	if in.ShelfStatus == consts.ShelfStatusOn {
		if app[dao.Application.Columns().AuditStatus].Int() != consts.AuditStatusPass {
			err = gerror.New("应用未审核通过，不允许上架")
			return
		}
		if app[dao.Application.Columns().DownloadUrl].String() == "" {
			err = gerror.New("应用下载地址为空，不允许上架")
			return
		}
	}

	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.Application.Columns().ShelfStatus: in.ShelfStatus,
		dao.Application.Columns().UpdatedBy:   contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "更新应用上下架状态失败，请稍后重试！")
		return
	}
	return
}
