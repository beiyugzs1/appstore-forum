// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/library/hgorm/handler"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
)

type sSysVipPlan struct{}

func NewSysVipPlan() *sSysVipPlan {
	return &sSysVipPlan{}
}

func init() {
	service.RegisterSysVipPlan(NewSysVipPlan())
}

// Model VIP套餐ORM模型
func (s *sSysVipPlan) Model(ctx context.Context, option ...*handler.Option) *gdb.Model {
	return handler.Model(dao.VipPlan.Ctx(ctx), option...)
}

// List 获取VIP套餐列表
func (s *sSysVipPlan) List(ctx context.Context, in *sysin.VipPlanListInp) (list []*sysin.VipPlanListModel, totalCount int, err error) {
	mod := s.Model(ctx)

	if in.Id > 0 {
		mod = mod.Where(dao.VipPlan.Columns().Id, in.Id)
	}

	if in.Name != "" {
		mod = mod.WhereLike(dao.VipPlan.Columns().Name, "%"+in.Name+"%")
	}

	if in.Type > 0 {
		mod = mod.Where(dao.VipPlan.Columns().Type, in.Type)
	}

	if in.Status > 0 {
		mod = mod.Where(dao.VipPlan.Columns().Status, in.Status)
	}

	mod = mod.Page(in.Page, in.PerPage).
		OrderAsc(dao.VipPlan.Columns().Sort).
		OrderDesc(dao.VipPlan.Columns().Id)

	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取VIP套餐列表失败，请稍后重试！")
		return
	}
	return
}

// View 获取VIP套餐指定信息
func (s *sSysVipPlan) View(ctx context.Context, in *sysin.VipPlanViewInp) (res *sysin.VipPlanViewModel, err error) {
	if err = s.Model(ctx).WherePri(in.Id).Scan(&res); err != nil {
		err = gerror.Wrap(err, "获取VIP套餐信息失败，请稍后重试！")
		return
	}
	return
}

// Edit 修改/新增VIP套餐
func (s *sSysVipPlan) Edit(ctx context.Context, in *sysin.VipPlanEditInp) (err error) {
	return g.DB().Transaction(ctx, func(ctx context.Context, tx gdb.TX) (err error) {
		exist, err := s.Model(ctx).Where(dao.VipPlan.Columns().Name, in.Name).
			WhereNot(dao.VipPlan.Columns().Id, in.Id).Count()
		if err != nil {
			err = gerror.Wrap(err, "校验套餐名称失败，请稍后重试！")
			return
		}
		if exist > 0 {
			err = gerror.New("套餐名称已存在")
			return
		}

		// 修改
		if in.Id > 0 {
			in.UpdatedBy = contexts.GetUserId(ctx)
			if _, err = s.Model(ctx).
				Fields(sysin.VipPlanUpdateFields{}).
				WherePri(in.Id).Data(in).Update(); err != nil {
				err = gerror.Wrap(err, "修改VIP套餐失败，请稍后重试！")
			}
			return
		}

		// 新增
		in.CreatedBy = contexts.GetUserId(ctx)
		if _, err = s.Model(ctx, &handler.Option{FilterAuth: false}).
			Fields(sysin.VipPlanInsertFields{}).
			Data(in).OmitEmptyData().Insert(); err != nil {
			err = gerror.Wrap(err, "新增VIP套餐失败，请稍后重试！")
		}
		return
	})
}

// Delete 删除VIP套餐
func (s *sSysVipPlan) Delete(ctx context.Context, in *sysin.VipPlanDeleteInp) (err error) {
	count, err := dao.VipCard.Ctx(ctx).Where(dao.VipCard.Columns().PlanId, in.Id).Count()
	if err != nil {
		err = gerror.Wrap(err, "校验VIP套餐失败，请稍后重试！")
		return
	}
	if count > 0 {
		err = gerror.New("该套餐已生成卡密，请先移除卡密后再删除")
		return
	}

	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.VipPlan.Columns().DeletedBy: contexts.GetUserId(ctx),
		dao.VipPlan.Columns().DeletedAt: gtime.Now(),
	}).Unscoped().Update(); err != nil {
		err = gerror.Wrap(err, "删除VIP套餐失败，请稍后重试！")
		return
	}
	return
}

// Status 更新VIP套餐状态
func (s *sSysVipPlan) Status(ctx context.Context, in *sysin.VipPlanStatusInp) (err error) {
	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.VipPlan.Columns().Status:    in.Status,
		dao.VipPlan.Columns().UpdatedBy: contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "更新VIP套餐状态失败，请稍后重试！")
		return
	}
	return
}
