// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/internal/consts"
	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/model/entity"
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/net/ghttp"
	"github.com/gogf/gf/v2/os/gtime"
)

type sSysApiVip struct{}

func NewSysApiVip() *sSysApiVip {
	return &sSysApiVip{}
}

func init() {
	service.RegisterSysApiVip(NewSysApiVip())
}

// PlanList 获取VIP套餐列表
func (s *sSysApiVip) PlanList(ctx context.Context) (res *apiin.ApiVipPlanListModel, err error) {
	res = &apiin.ApiVipPlanListModel{List: make([]*apiin.ApiVipPlanModel, 0)}

	if err = dao.VipPlan.Ctx(ctx).
		Where(dao.VipPlan.Columns().Status, consts.StatusEnabled).
		Fields(
			dao.VipPlan.Columns().Id,
			dao.VipPlan.Columns().Name,
			dao.VipPlan.Columns().Type,
			dao.VipPlan.Columns().DurationDays,
			dao.VipPlan.Columns().Price,
			dao.VipPlan.Columns().OriginalPrice,
			dao.VipPlan.Columns().Description,
		).
		OrderAsc(dao.VipPlan.Columns().Sort).
		OrderAsc(dao.VipPlan.Columns().Id).
		Scan(&res.List); err != nil {
		err = gerror.Wrap(err, "获取VIP套餐列表失败，请稍后重试！")
		return
	}

	if res.List == nil {
		res.List = make([]*apiin.ApiVipPlanModel, 0)
	}
	return
}

// Activate 使用卡密激活VIP
func (s *sSysApiVip) Activate(ctx context.Context, in *apiin.ApiVipActivateInp) (res *apiin.ApiVipActivateModel, err error) {
	userId := contexts.GetUserId(ctx)
	if userId <= 0 {
		err = gerror.New("登录身份已失效，请重新登录")
		return
	}

	clientIp := ""
	if r := ghttp.RequestFromCtx(ctx); r != nil {
		clientIp = r.GetClientIp()
	}

	err = g.DB().Transaction(ctx, func(ctx context.Context, tx gdb.TX) (err error) {
		// 行级锁，避免并发重复激活
		var card *entity.VipCard
		if err = dao.VipCard.Ctx(ctx).
			Where(dao.VipCard.Columns().CardNo, in.CardNo).
			Where(dao.VipCard.Columns().CardPwd, in.CardPwd).
			LockUpdate().
			Scan(&card); err != nil {
			err = gerror.Wrap(err, "查询卡密失败，请稍后重试！")
			return
		}
		if card == nil {
			err = gerror.New("卡号或卡密不正确")
			return
		}
		if card.Status == consts.VipCardStatusUsed {
			err = gerror.New("该卡密已被使用")
			return
		}
		if card.Status == consts.VipCardStatusDisabled {
			err = gerror.New("该卡密已被禁用")
			return
		}

		// 套餐信息
		planName := ""
		plan, err := dao.VipPlan.Ctx(ctx).WherePri(card.PlanId).One()
		if err != nil {
			err = gerror.Wrap(err, "获取VIP套餐失败，请稍后重试！")
			return
		}
		if !plan.IsEmpty() {
			planName = plan[dao.VipPlan.Columns().Name].String()
		}

		// 当前用户
		var user *entity.User
		if err = dao.User.Ctx(ctx).WherePri(userId).Scan(&user); err != nil {
			err = gerror.Wrap(err, "获取用户信息失败，请稍后重试！")
			return
		}
		if user == nil {
			err = gerror.New("用户不存在")
			return
		}
		if user.Status != consts.StatusEnabled {
			err = gerror.New("账号已被禁用，请联系客服")
			return
		}

		// 叠加时长：从「当前到期时间」与「当前时间」中取较晚者开始计算
		now := gtime.Now()
		before := user.VipExpireAt
		base := now
		if before != nil && before.After(now) {
			base = before
		}
		after := base.AddDate(0, 0, card.DurationDays)

		// 更新用户 VIP
		if _, err = dao.User.Ctx(ctx).WherePri(userId).Data(g.Map{
			dao.User.Columns().VipPlanId:   card.PlanId,
			dao.User.Columns().VipExpireAt: after,
		}).Update(); err != nil {
			err = gerror.Wrap(err, "更新会员信息失败，请稍后重试！")
			return
		}

		// 标记卡密已使用
		if _, err = dao.VipCard.Ctx(ctx).WherePri(card.Id).Data(g.Map{
			dao.VipCard.Columns().Status:         consts.VipCardStatusUsed,
			dao.VipCard.Columns().ActivateUserId: userId,
			dao.VipCard.Columns().ActivatedAt:    now,
		}).Update(); err != nil {
			err = gerror.Wrap(err, "更新卡密状态失败，请稍后重试！")
			return
		}

		// 写入激活记录
		if _, err = dao.VipCardLog.Ctx(ctx).Data(g.Map{
			dao.VipCardLog.Columns().CardId:         card.Id,
			dao.VipCardLog.Columns().CardNo:         card.CardNo,
			dao.VipCardLog.Columns().UserId:         userId,
			dao.VipCardLog.Columns().PlanId:         card.PlanId,
			dao.VipCardLog.Columns().DurationDays:   card.DurationDays,
			dao.VipCardLog.Columns().BeforeExpireAt: before,
			dao.VipCardLog.Columns().AfterExpireAt:  after,
			dao.VipCardLog.Columns().ActivateIp:     clientIp,
			dao.VipCardLog.Columns().CreatedAt:      now,
			dao.VipCardLog.Columns().UpdatedAt:      now,
		}).Insert(); err != nil {
			err = gerror.Wrap(err, "写入激活记录失败，请稍后重试！")
			return
		}

		res = &apiin.ApiVipActivateModel{
			PlanName:       planName,
			DurationDays:   card.DurationDays,
			BeforeExpireAt: before,
			AfterExpireAt:  after,
		}
		return
	})

	return
}

// MyCardLog 我的卡密激活记录
func (s *sSysApiVip) MyCardLog(ctx context.Context, in *apiin.ApiVipCardLogListInp) (list []*apiin.ApiVipCardLogModel, totalCount int, err error) {
	userId := contexts.GetUserId(ctx)
	if userId <= 0 {
		err = gerror.New("登录身份已失效，请重新登录")
		return
	}

	mod := dao.VipCardLog.Ctx(ctx).As("l").
		LeftJoin(dao.VipPlan.Table(), dao.VipPlan.Table()+"."+dao.VipPlan.Columns().Id+" = l."+dao.VipCardLog.Columns().PlanId).
		Fields("l."+dao.VipCardLog.Columns().Id+" as id, "+
			"l."+dao.VipCardLog.Columns().CardNo+" as cardNo, "+
			"l."+dao.VipCardLog.Columns().DurationDays+" as durationDays, "+
			"l."+dao.VipCardLog.Columns().AfterExpireAt+" as afterExpireAt, "+
			"l."+dao.VipCardLog.Columns().CreatedAt+" as createdAt, "+
			dao.VipPlan.Table()+"."+dao.VipPlan.Columns().Name+" as planName").
		Where("l."+dao.VipCardLog.Columns().UserId, userId).
		Page(in.Page, in.PerPage).
		OrderDesc("l."+dao.VipCardLog.Columns().Id)

	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取激活记录失败，请稍后重试！")
		return
	}
	return
}

// currentUserIsVip 判断当前登录用户是否为有效会员（VIP 未过期）
//
// 未登录（userId <= 0）时返回 false，用于会员专享内容的访问控制：
// 会员专享版块、会员专属应用均依赖此判定。
func currentUserIsVip(ctx context.Context) (isVip bool, userId int64, err error) {
	userId = contexts.GetUserId(ctx)
	if userId <= 0 {
		return
	}

	var user *struct {
		VipExpireAt *gtime.Time `json:"vipExpireAt"`
	}
	if err = dao.User.Ctx(ctx).
		Fields(dao.User.Columns().VipExpireAt).
		WherePri(userId).Scan(&user); err != nil {
		err = gerror.Wrap(err, "获取会员状态失败，请稍后重试！")
		return
	}

	isVip = user != nil && user.VipExpireAt != nil && user.VipExpireAt.After(gtime.Now())
	return
}
