// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/library/hgorm/handler"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
)

type sSysAppCategory struct{}

func NewSysAppCategory() *sSysAppCategory {
	return &sSysAppCategory{}
}

func init() {
	service.RegisterSysAppCategory(NewSysAppCategory())
}

// Model 应用分类ORM模型
func (s *sSysAppCategory) Model(ctx context.Context, option ...*handler.Option) *gdb.Model {
	return handler.Model(dao.AppCategory.Ctx(ctx), option...)
}

// List 获取应用分类列表
func (s *sSysAppCategory) List(ctx context.Context, in *sysin.AppCategoryListInp) (list []*sysin.AppCategoryListModel, totalCount int, err error) {
	mod := s.Model(ctx)

	if in.Id > 0 {
		mod = mod.Where(dao.AppCategory.Columns().Id, in.Id)
	}

	if in.Name != "" {
		mod = mod.WhereLike(dao.AppCategory.Columns().Name, "%"+in.Name+"%")
	}

	if in.Status > 0 {
		mod = mod.Where(dao.AppCategory.Columns().Status, in.Status)
	}

	mod = mod.Page(in.Page, in.PerPage).
		OrderAsc(dao.AppCategory.Columns().Sort).
		OrderDesc(dao.AppCategory.Columns().Id)

	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取应用分类列表失败，请稍后重试！")
		return
	}
	return
}

// View 获取应用分类指定信息
func (s *sSysAppCategory) View(ctx context.Context, in *sysin.AppCategoryViewInp) (res *sysin.AppCategoryViewModel, err error) {
	if err = s.Model(ctx).WherePri(in.Id).Scan(&res); err != nil {
		err = gerror.Wrap(err, "获取应用分类信息失败，请稍后重试！")
		return
	}
	return
}

// Edit 修改/新增应用分类
func (s *sSysAppCategory) Edit(ctx context.Context, in *sysin.AppCategoryEditInp) (err error) {
	return g.DB().Transaction(ctx, func(ctx context.Context, tx gdb.TX) (err error) {
		// 名称唯一性校验
		exist, err := s.Model(ctx).Where(dao.AppCategory.Columns().Name, in.Name).
			WhereNot(dao.AppCategory.Columns().Id, in.Id).Count()
		if err != nil {
			err = gerror.Wrap(err, "校验分类名称失败，请稍后重试！")
			return
		}
		if exist > 0 {
			err = gerror.New("分类名称已存在")
			return
		}

		// 修改
		if in.Id > 0 {
			in.UpdatedBy = contexts.GetUserId(ctx)
			if _, err = s.Model(ctx).
				Fields(sysin.AppCategoryUpdateFields{}).
				WherePri(in.Id).Data(in).Update(); err != nil {
				err = gerror.Wrap(err, "修改应用分类失败，请稍后重试！")
			}
			return
		}

		// 新增
		in.CreatedBy = contexts.GetUserId(ctx)
		if _, err = s.Model(ctx, &handler.Option{FilterAuth: false}).
			Fields(sysin.AppCategoryInsertFields{}).
			Data(in).OmitEmptyData().Insert(); err != nil {
			err = gerror.Wrap(err, "新增应用分类失败，请稍后重试！")
		}
		return
	})
}

// Delete 删除应用分类
func (s *sSysAppCategory) Delete(ctx context.Context, in *sysin.AppCategoryDeleteInp) (err error) {
	count, err := dao.Application.Ctx(ctx).Where(dao.Application.Columns().CategoryId, in.Id).Count()
	if err != nil {
		err = gerror.Wrap(err, "校验应用分类失败，请稍后重试！")
		return
	}
	if count > 0 {
		err = gerror.New("该分类下存在应用，请先移除或转移后再删除")
		return
	}

	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.AppCategory.Columns().DeletedBy: contexts.GetUserId(ctx),
		dao.AppCategory.Columns().DeletedAt: gtime.Now(),
	}).Unscoped().Update(); err != nil {
		err = gerror.Wrap(err, "删除应用分类失败，请稍后重试！")
		return
	}
	return
}

// Status 更新应用分类状态
func (s *sSysAppCategory) Status(ctx context.Context, in *sysin.AppCategoryStatusInp) (err error) {
	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.AppCategory.Columns().Status:    in.Status,
		dao.AppCategory.Columns().UpdatedBy: contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "更新应用分类状态失败，请稍后重试！")
		return
	}
	return
}
