// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"

	"hotgo/internal/consts"
	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/library/hgorm/handler"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
)

type sSysAnnouncement struct{}

func NewSysAnnouncement() *sSysAnnouncement {
	return &sSysAnnouncement{}
}

func init() {
	service.RegisterSysAnnouncement(NewSysAnnouncement())
}

// Model App公告ORM模型
func (s *sSysAnnouncement) Model(ctx context.Context, option ...*handler.Option) *gdb.Model {
	return handler.Model(dao.AppAnnouncement.Ctx(ctx), option...)
}

// List 获取App公告列表
func (s *sSysAnnouncement) List(ctx context.Context, in *sysin.AnnouncementListInp) (list []*sysin.AnnouncementListModel, totalCount int, err error) {
	columns := dao.AppAnnouncement.Columns()
	mod := s.Model(ctx)

	if in.Id > 0 {
		mod = mod.Where(columns.Id, in.Id)
	}
	if in.Title != "" {
		mod = mod.WhereLike(columns.Title, "%"+in.Title+"%")
	}
	if in.Type > 0 {
		mod = mod.Where(columns.Type, in.Type)
	}
	if in.Published >= 0 && in.Published <= 1 {
		mod = mod.Where(columns.Published, in.Published)
	}
	if in.Status > 0 {
		mod = mod.Where(columns.Status, in.Status)
	}
	if len(in.CreatedAt) == 2 {
		mod = mod.WhereBetween(columns.CreatedAt, in.CreatedAt[0], in.CreatedAt[1])
	}

	mod = mod.Page(in.Page, in.PerPage).
		OrderDesc(columns.IsTop).
		OrderDesc(columns.Sort).
		OrderDesc(columns.Id)
	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取App公告列表失败，请稍后重试！")
		return
	}
	return
}

// View 获取指定App公告
func (s *sSysAnnouncement) View(ctx context.Context, in *sysin.AnnouncementViewInp) (res *sysin.AnnouncementListModel, err error) {
	if err = s.Model(ctx).WherePri(in.Id).Scan(&res); err != nil {
		err = gerror.Wrap(err, "获取App公告失败，请稍后重试！")
		return
	}
	if res == nil {
		err = gerror.New("公告不存在")
	}
	return
}

// Edit 修改/新增App公告
func (s *sSysAnnouncement) Edit(ctx context.Context, in *sysin.AnnouncementEditInp) (err error) {
	columns := dao.AppAnnouncement.Columns()

	data := g.Map{
		columns.Title:          in.Title,
		columns.Type:           in.Type,
		columns.Summary:        in.Summary,
		columns.Content:        in.Content,
		columns.Cover:          in.Cover,
		columns.Target:         in.Target,
		columns.LinkUrl:        in.LinkUrl,
		columns.IsTop:          in.IsTop,
		columns.IsPopup:        in.IsPopup,
		columns.PopupFrequency: in.PopupFrequency,
		columns.Platform:       in.Platform,
		columns.PublishAt:      in.PublishAt,
		columns.ExpireAt:       in.ExpireAt,
		columns.Sort:           in.Sort,
	}

	if in.Id > 0 {
		data[columns.UpdatedBy] = contexts.GetUserId(ctx)
		if _, err = s.Model(ctx).Fields(sysin.AnnouncementUpdateFields{}).
			WherePri(in.Id).Data(data).Update(); err != nil {
			err = gerror.Wrap(err, "修改公告失败，请稍后重试！")
			return
		}
		return
	}

	data[columns.CreatedBy] = contexts.GetUserId(ctx)
	data[columns.Status] = consts.StatusEnabled
	data[columns.Published] = consts.AnnouncementDraft
	if _, err = s.Model(ctx, &handler.Option{FilterAuth: false}).
		Fields(sysin.AnnouncementInsertFields{}).
		Data(data).OmitEmptyData().Insert(); err != nil {
		err = gerror.Wrap(err, "新增公告失败，请稍后重试！")
		return
	}
	return
}

// Delete 删除App公告
func (s *sSysAnnouncement) Delete(ctx context.Context, in *sysin.AnnouncementDeleteInp) (err error) {
	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.AppAnnouncement.Columns().DeletedBy: contexts.GetUserId(ctx),
	}).Delete(); err != nil {
		err = gerror.Wrap(err, "删除公告失败，请稍后重试！")
		return
	}
	return
}

// Status 更新App公告状态
func (s *sSysAnnouncement) Status(ctx context.Context, in *sysin.AnnouncementStatusInp) (err error) {
	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.AppAnnouncement.Columns().Status:    in.Status,
		dao.AppAnnouncement.Columns().UpdatedBy: contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "更新公告状态失败，请稍后重试！")
		return
	}
	return
}

// Publish 发布/撤回App公告
//
// 发布时若未设置发布时间，则自动补当前时间；撤回则保留原发布时间便于再次发布。
func (s *sSysAnnouncement) Publish(ctx context.Context, in *sysin.AnnouncementPublishInp) (err error) {
	columns := dao.AppAnnouncement.Columns()

	row, err := dao.AppAnnouncement.Ctx(ctx).WherePri(in.Id).One()
	if err != nil {
		err = gerror.Wrap(err, "获取公告失败，请稍后重试！")
		return
	}
	if row.IsEmpty() {
		err = gerror.New("公告不存在")
		return
	}

	data := g.Map{
		columns.Published: in.Published,
		columns.UpdatedBy: contexts.GetUserId(ctx),
	}
	if in.Published == consts.AnnouncementPublished && row[columns.PublishAt].IsNil() {
		data[columns.PublishAt] = gtime.Now()
	}

	if _, err = s.Model(ctx).WherePri(in.Id).Data(data).Update(); err != nil {
		err = gerror.Wrap(err, "更新发布状态失败，请稍后重试！")
		return
	}
	return
}
