// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/internal/consts"
	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/library/hgorm/handler"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
	"github.com/gogf/gf/v2/util/grand"
)

type sSysVipCard struct{}

func NewSysVipCard() *sSysVipCard {
	return &sSysVipCard{}
}

func init() {
	service.RegisterSysVipCard(NewSysVipCard())
}

// Model 卡密ORM模型
func (s *sSysVipCard) Model(ctx context.Context, option ...*handler.Option) *gdb.Model {
	return handler.Model(dao.VipCard.Ctx(ctx), option...)
}

// List 获取卡密列表
func (s *sSysVipCard) List(ctx context.Context, in *sysin.VipCardListInp) (list []*sysin.VipCardListModel, totalCount int, err error) {
	mod := s.Model(ctx).As("c").
		LeftJoin(dao.VipPlan.Table(), dao.VipPlan.Table()+"."+dao.VipPlan.Columns().Id+" = c."+dao.VipCard.Columns().PlanId).
		LeftJoin(dao.User.Table(), dao.User.Table()+"."+dao.User.Columns().Id+" = c."+dao.VipCard.Columns().ActivateUserId).
		Fields("c.*, "+dao.VipPlan.Table()+"."+dao.VipPlan.Columns().Name+" as planName, "+
			dao.User.Table()+"."+dao.User.Columns().Nickname+" as userName, "+
			dao.User.Table()+"."+dao.User.Columns().Username+" as userAccount")

	if in.Id > 0 {
		mod = mod.Where("c."+dao.VipCard.Columns().Id, in.Id)
	}
	if in.CardNo != "" {
		mod = mod.WhereLike("c."+dao.VipCard.Columns().CardNo, "%"+in.CardNo+"%")
	}
	if in.PlanId > 0 {
		mod = mod.Where("c."+dao.VipCard.Columns().PlanId, in.PlanId)
	}
	if in.BatchNo != "" {
		mod = mod.Where("c."+dao.VipCard.Columns().BatchNo, in.BatchNo)
	}
	if in.Channel != "" {
		mod = mod.Where("c."+dao.VipCard.Columns().Channel, in.Channel)
	}
	if in.Status > 0 {
		mod = mod.Where("c."+dao.VipCard.Columns().Status, in.Status)
	}

	mod = mod.Page(in.Page, in.PerPage).OrderDesc("c."+dao.VipCard.Columns().Id)

	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取卡密列表失败，请稍后重试！")
		return
	}
	return
}

// View 获取卡密指定信息
func (s *sSysVipCard) View(ctx context.Context, in *sysin.VipCardViewInp) (res *sysin.VipCardViewModel, err error) {
	if err = s.Model(ctx).WherePri(in.Id).Scan(&res); err != nil {
		err = gerror.Wrap(err, "获取卡密信息失败，请稍后重试！")
		return
	}
	return
}

// Generate 批量生成卡密
func (s *sSysVipCard) Generate(ctx context.Context, in *sysin.VipCardGenerateInp) (res *sysin.VipCardGenerateModel, err error) {
	plan, err := dao.VipPlan.Ctx(ctx).WherePri(in.PlanId).
		Where(dao.VipPlan.Columns().Status, consts.StatusEnabled).One()
	if err != nil {
		err = gerror.Wrap(err, "获取VIP套餐失败，请稍后重试！")
		return
	}
	if plan.IsEmpty() {
		err = gerror.New("VIP套餐不存在或已下架")
		return
	}

	var (
		userId  = contexts.GetUserId(ctx)
		batchNo = "B" + gtime.Now().Format("YmdHis")
		list    []g.Map
		cards   []string
	)

	for i := 0; i < in.Count; i++ {
		cardNo := grand.Str("0123456789", 16)
		cardPwd := grand.Str("0123456789", 8)
		cards = append(cards, cardNo)
		list = append(list, g.Map{
			dao.VipCard.Columns().CardNo:       cardNo,
			dao.VipCard.Columns().CardPwd:      cardPwd,
			dao.VipCard.Columns().PlanId:       in.PlanId,
			dao.VipCard.Columns().DurationDays: plan[dao.VipPlan.Columns().DurationDays].Int(),
			dao.VipCard.Columns().BatchNo:      batchNo,
			dao.VipCard.Columns().Channel:      in.Channel,
			dao.VipCard.Columns().Remark:       in.Remark,
			dao.VipCard.Columns().Status:       consts.VipCardStatusUnused,
			dao.VipCard.Columns().CreatedBy:    userId,
		})
	}

	if len(list) == 0 {
		err = gerror.New("生成数量必须大于0")
		return
	}

	if _, err = dao.VipCard.Ctx(ctx).Data(list).Insert(); err != nil {
		err = gerror.Wrap(err, "生成卡密失败，请稍后重试！")
		return
	}

	res = &sysin.VipCardGenerateModel{
		BatchNo: batchNo,
		Count:   len(list),
		Cards:   cards,
	}
	return
}

// Delete 删除卡密
func (s *sSysVipCard) Delete(ctx context.Context, in *sysin.VipCardDeleteInp) (err error) {
	card, err := s.Model(ctx).WherePri(in.Id).One()
	if err != nil {
		err = gerror.Wrap(err, "获取卡密失败，请稍后重试！")
		return
	}
	if card.IsEmpty() {
		err = gerror.New("卡密不存在")
		return
	}
	if card[dao.VipCard.Columns().Status].Int() == consts.VipCardStatusUsed {
		err = gerror.New("已使用的卡密不允许删除")
		return
	}

	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.VipCard.Columns().DeletedBy: contexts.GetUserId(ctx),
		dao.VipCard.Columns().DeletedAt: gtime.Now(),
	}).Unscoped().Update(); err != nil {
		err = gerror.Wrap(err, "删除卡密失败，请稍后重试！")
		return
	}
	return
}

// Status 更新卡密状态（仅允许在未使用/已禁用之间切换）
func (s *sSysVipCard) Status(ctx context.Context, in *sysin.VipCardStatusInp) (err error) {
	if in.Status == consts.VipCardStatusUsed {
		err = gerror.New("不能手动将卡密置为已使用")
		return
	}

	card, err := s.Model(ctx).WherePri(in.Id).One()
	if err != nil {
		err = gerror.Wrap(err, "获取卡密失败，请稍后重试！")
		return
	}
	if card.IsEmpty() {
		err = gerror.New("卡密不存在")
		return
	}
	if card[dao.VipCard.Columns().Status].Int() == consts.VipCardStatusUsed {
		err = gerror.New("已使用的卡密不允许修改状态")
		return
	}

	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.VipCard.Columns().Status:    in.Status,
		dao.VipCard.Columns().UpdatedBy: contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "更新卡密状态失败，请稍后重试！")
		return
	}
	return
}

// LogList 获取卡密激活记录
func (s *sSysVipCard) LogList(ctx context.Context, in *sysin.VipCardLogListInp) (list []*sysin.VipCardLogListModel, totalCount int, err error) {
	mod := dao.VipCardLog.Ctx(ctx).As("l").
		LeftJoin(dao.VipPlan.Table(), dao.VipPlan.Table()+"."+dao.VipPlan.Columns().Id+" = l."+dao.VipCardLog.Columns().PlanId).
		LeftJoin(dao.User.Table(), dao.User.Table()+"."+dao.User.Columns().Id+" = l."+dao.VipCardLog.Columns().UserId).
		Fields("l.*, "+dao.VipPlan.Table()+"."+dao.VipPlan.Columns().Name+" as planName, "+
			dao.User.Table()+"."+dao.User.Columns().Nickname+" as userName, "+
			dao.User.Table()+"."+dao.User.Columns().Username+" as userAccount")

	if in.CardNo != "" {
		mod = mod.WhereLike("l."+dao.VipCardLog.Columns().CardNo, "%"+in.CardNo+"%")
	}
	if in.UserId > 0 {
		mod = mod.Where("l."+dao.VipCardLog.Columns().UserId, in.UserId)
	}

	mod = mod.Page(in.Page, in.PerPage).OrderDesc("l."+dao.VipCardLog.Columns().Id)

	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取卡密激活记录失败，请稍后重试！")
		return
	}
	return
}
