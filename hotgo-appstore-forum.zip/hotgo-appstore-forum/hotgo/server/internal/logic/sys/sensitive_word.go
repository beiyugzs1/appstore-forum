// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"sort"
	"strings"
	"time"
	"unicode/utf8"

	"hotgo/internal/consts"
	"hotgo/internal/dao"
	"hotgo/internal/library/cache"
	"hotgo/internal/library/contexts"
	"hotgo/internal/library/hgorm/handler"
	"hotgo/internal/model/entity"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
)

// sensitiveWordsCacheTTL 敏感词库缓存时长
const sensitiveWordsCacheTTL = 5 * time.Minute

type sSysSensitiveWord struct{}

func NewSysSensitiveWord() *sSysSensitiveWord {
	return &sSysSensitiveWord{}
}

func init() {
	service.RegisterSysSensitiveWord(NewSysSensitiveWord())
}

// Model 敏感词ORM模型
func (s *sSysSensitiveWord) Model(ctx context.Context, option ...*handler.Option) *gdb.Model {
	return handler.Model(dao.SensitiveWord.Ctx(ctx), option...)
}

// List 获取敏感词列表
func (s *sSysSensitiveWord) List(ctx context.Context, in *sysin.SensitiveWordListInp) (list []*sysin.SensitiveWordListModel, totalCount int, err error) {
	columns := dao.SensitiveWord.Columns()
	mod := s.Model(ctx)

	if in.Id > 0 {
		mod = mod.Where(columns.Id, in.Id)
	}
	if in.Word != "" {
		mod = mod.WhereLike(columns.Word, "%"+in.Word+"%")
	}
	if in.Category != "" {
		mod = mod.Where(columns.Category, in.Category)
	}
	if in.Strategy > 0 {
		mod = mod.Where(columns.Strategy, in.Strategy)
	}
	if in.Status > 0 {
		mod = mod.Where(columns.Status, in.Status)
	}

	mod = mod.Page(in.Page, in.PerPage).OrderDesc(columns.Id)
	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取敏感词列表失败，请稍后重试！")
		return
	}
	return
}

// View 获取指定敏感词
func (s *sSysSensitiveWord) View(ctx context.Context, in *sysin.SensitiveWordViewInp) (res *sysin.SensitiveWordListModel, err error) {
	if err = s.Model(ctx).WherePri(in.Id).Scan(&res); err != nil {
		err = gerror.Wrap(err, "获取敏感词失败，请稍后重试！")
		return
	}
	if res == nil {
		err = gerror.New("敏感词不存在")
	}
	return
}

// Edit 修改/新增敏感词
func (s *sSysSensitiveWord) Edit(ctx context.Context, in *sysin.SensitiveWordEditInp) (err error) {
	columns := dao.SensitiveWord.Columns()

	exist, err := s.Model(ctx).Where(columns.Word, in.Word).WhereNot(columns.Id, in.Id).Count()
	if err != nil {
		err = gerror.Wrap(err, "校验敏感词失败，请稍后重试！")
		return
	}
	if exist > 0 {
		err = gerror.New("该敏感词已存在")
		return
	}

	data := g.Map{
		columns.Word:        in.Word,
		columns.Category:    in.Category,
		columns.Strategy:    in.Strategy,
		columns.Replacement: in.Replacement,
		columns.Remark:      in.Remark,
	}

	if in.Id > 0 {
		data[columns.UpdatedBy] = contexts.GetUserId(ctx)
		if _, err = s.Model(ctx).Fields(sysin.SensitiveWordUpdateFields{}).
			WherePri(in.Id).Data(data).Update(); err != nil {
			err = gerror.Wrap(err, "修改敏感词失败，请稍后重试！")
			return
		}
	} else {
		data[columns.CreatedBy] = contexts.GetUserId(ctx)
		data[columns.Status] = consts.StatusEnabled
		if _, err = s.Model(ctx, &handler.Option{FilterAuth: false}).
			Fields(sysin.SensitiveWordInsertFields{}).
			Data(data).OmitEmptyData().Insert(); err != nil {
			err = gerror.Wrap(err, "新增敏感词失败，请稍后重试！")
			return
		}
	}

	s.ClearCache(ctx)
	return
}

// Delete 删除敏感词（物理删除，避免与唯一键冲突）
func (s *sSysSensitiveWord) Delete(ctx context.Context, in *sysin.SensitiveWordDeleteInp) (err error) {
	if _, err = dao.SensitiveWord.Ctx(ctx).WherePri(in.Id).Unscoped().Delete(); err != nil {
		err = gerror.Wrap(err, "删除敏感词失败，请稍后重试！")
		return
	}

	s.ClearCache(ctx)
	return
}

// Status 更新敏感词状态
func (s *sSysSensitiveWord) Status(ctx context.Context, in *sysin.SensitiveWordStatusInp) (err error) {
	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.SensitiveWord.Columns().Status:    in.Status,
		dao.SensitiveWord.Columns().UpdatedBy: contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "更新敏感词状态失败，请稍后重试！")
		return
	}

	s.ClearCache(ctx)
	return
}

// LoadWords 加载启用的敏感词库（带缓存）
func (s *sSysSensitiveWord) LoadWords(ctx context.Context) (words []*entity.SensitiveWord, err error) {
	cacheKey := consts.CacheSensitiveWords
	cacheVar, cacheErr := cache.Instance().Get(ctx, cacheKey)
	if cacheErr == nil && cacheVar != nil && !cacheVar.IsNil() {
		if scanErr := cacheVar.Structs(&words); scanErr == nil && words != nil {
			return
		}
	}

	if err = dao.SensitiveWord.Ctx(ctx).
		Where(dao.SensitiveWord.Columns().Status, consts.StatusEnabled).
		Scan(&words); err != nil {
		err = gerror.Wrap(err, "加载敏感词库失败，请稍后重试！")
		return
	}

	_ = cache.Instance().Set(ctx, cacheKey, words, sensitiveWordsCacheTTL)
	return
}

// ClearCache 清理敏感词库缓存
func (s *sSysSensitiveWord) ClearCache(ctx context.Context) {
	_, _ = cache.Instance().Remove(ctx, consts.CacheSensitiveWords)
}

// Filter 内容过滤
// 返回：处理后的文本、命中的最高优先级策略、命中词列表。
// 策略优先级：拦截 > 转待审 > 替换；策略为 0 表示未命中任何敏感词。
func (s *sSysSensitiveWord) Filter(ctx context.Context, text string) (result string, strategy int, hitWords []string, err error) {
	result = text
	if strings.TrimSpace(text) == "" || !s.switchOn(ctx) {
		return
	}

	words, err := s.LoadWords(ctx)
	if err != nil {
		return
	}
	if len(words) == 0 {
		return
	}

	// 按词长降序，优先匹配更长的词，避免短词干扰长词
	sort.SliceStable(words, func(i, j int) bool {
		return utf8.RuneCountInString(words[i].Word) > utf8.RuneCountInString(words[j].Word)
	})

	// 第一轮：在原始文本上扫描全部命中词，确定最高优先级策略
	var replaceHits []*entity.SensitiveWord
	bestPriority := 0
	for _, w := range words {
		if w.Word == "" || !strings.Contains(text, w.Word) {
			continue
		}
		hitWords = append(hitWords, w.Word)
		if p := consts.SensitiveStrategyPriority(w.Strategy); p > bestPriority {
			bestPriority = p
			strategy = w.Strategy
		}
		if w.Strategy == consts.SensitiveStrategyReplace {
			replaceHits = append(replaceHits, w)
		}
	}

	// 第二轮：对需要替换的命中词做等长掩码替换
	if len(replaceHits) > 0 {
		masked := text
		for _, w := range replaceHits {
			masked = strings.ReplaceAll(masked, w.Word, maskWord(w.Word, w.Replacement))
		}
		result = masked
	}
	return
}

// switchOn 敏感词过滤开关（配置项 sensitiveWord.switch，缺省为开启）
func (s *sSysSensitiveWord) switchOn(ctx context.Context) bool {
	v := g.Cfg().MustGet(ctx, "sensitiveWord.switch")
	if v == nil || v.IsNil() {
		return true
	}
	return v.Bool()
}

// maskWord 生成等长掩码：替换字符为单字符时按命中词长度重复
func maskWord(word, replacement string) string {
	if replacement == "" {
		replacement = "*"
	}
	n := utf8.RuneCountInString(word)
	if utf8.RuneCountInString(replacement) == 1 {
		return strings.Repeat(replacement, n)
	}
	return replacement
}
