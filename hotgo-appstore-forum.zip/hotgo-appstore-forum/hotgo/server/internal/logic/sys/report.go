// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/library/hgorm/handler"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
)

type sSysReport struct{}

func NewSysReport() *sSysReport {
	return &sSysReport{}
}

func init() {
	service.RegisterSysReport(NewSysReport())
}

// Model 举报ORM模型
func (s *sSysReport) Model(ctx context.Context, option ...*handler.Option) *gdb.Model {
	return handler.Model(dao.Report.Ctx(ctx), option...)
}

// List 获取举报列表
func (s *sSysReport) List(ctx context.Context, in *sysin.ReportListInp) (list []*sysin.ReportListModel, totalCount int, err error) {
	mod := s.Model(ctx).As("r").
		LeftJoin(dao.User.Table(), dao.User.Table()+"."+dao.User.Columns().Id+" = r."+dao.Report.Columns().UserId).
		Fields("r.*, " + dao.User.Table() + "." + dao.User.Columns().Nickname + " as userName, " +
			dao.User.Table() + "." + dao.User.Columns().Username + " as userAccount")

	if in.Id > 0 {
		mod = mod.Where("r."+dao.Report.Columns().Id, in.Id)
	}
	if in.UserId > 0 {
		mod = mod.Where("r."+dao.Report.Columns().UserId, in.UserId)
	}
	if in.TargetType > 0 {
		mod = mod.Where("r."+dao.Report.Columns().TargetType, in.TargetType)
	}
	if in.TargetId > 0 {
		mod = mod.Where("r."+dao.Report.Columns().TargetId, in.TargetId)
	}
	if in.HandleStatus >= 0 && in.HandleStatus <= 2 {
		mod = mod.Where("r."+dao.Report.Columns().HandleStatus, in.HandleStatus)
	}
	if len(in.CreatedAt) == 2 {
		mod = mod.WhereBetween("r."+dao.Report.Columns().CreatedAt, in.CreatedAt[0], in.CreatedAt[1])
	}

	mod = mod.Page(in.Page, in.PerPage).OrderDesc("r."+dao.Report.Columns().Id)

	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取举报列表失败，请稍后重试！")
		return
	}
	return
}

// View 获取举报指定信息
func (s *sSysReport) View(ctx context.Context, in *sysin.ReportViewInp) (res *sysin.ReportViewModel, err error) {
	if err = s.Model(ctx).WherePri(in.Id).Scan(&res); err != nil {
		err = gerror.Wrap(err, "获取举报信息失败，请稍后重试！")
		return
	}
	return
}

// Handle 处理举报
func (s *sSysReport) Handle(ctx context.Context, in *sysin.ReportHandleInp) (err error) {
	report, err := s.Model(ctx).WherePri(in.Id).One()
	if err != nil {
		err = gerror.Wrap(err, "获取举报失败，请稍后重试！")
		return
	}
	if report.IsEmpty() {
		err = gerror.New("举报记录不存在")
		return
	}

	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.Report.Columns().HandleStatus: in.HandleStatus,
		dao.Report.Columns().HandleRemark: in.HandleRemark,
		dao.Report.Columns().HandleBy:     contexts.GetUserId(ctx),
		dao.Report.Columns().HandleAt:     gtime.Now(),
		dao.Report.Columns().UpdatedBy:    contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "处理举报失败，请稍后重试！")
		return
	}
	return
}

// Delete 删除举报
func (s *sSysReport) Delete(ctx context.Context, in *sysin.ReportDeleteInp) (err error) {
	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.Report.Columns().DeletedBy: contexts.GetUserId(ctx),
		dao.Report.Columns().DeletedAt: gtime.Now(),
	}).Unscoped().Update(); err != nil {
		err = gerror.Wrap(err, "删除举报失败，请稍后重试！")
		return
	}
	return
}
