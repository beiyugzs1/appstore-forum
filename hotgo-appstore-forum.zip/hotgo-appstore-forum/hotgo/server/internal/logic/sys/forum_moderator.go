// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"time"

	"hotgo/internal/consts"
	"hotgo/internal/dao"
	"hotgo/internal/library/cache"
	"hotgo/internal/library/contexts"
	"hotgo/internal/library/hgorm/handler"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
	"github.com/gogf/gf/v2/util/gconv"
)

// moderatorPermCacheTTL 版主权限缓存时长。
// 版主权限为运行时高频判定（每个 C 端版主操作都要校验），加短缓存避免重复查库；
// 后台任命/修改/删除版主时主动清理对应缓存。
const moderatorPermCacheTTL = 5 * time.Minute

type sSysForumModerator struct{}

func NewSysForumModerator() *sSysForumModerator {
	return &sSysForumModerator{}
}

func init() {
	service.RegisterSysForumModerator(NewSysForumModerator())
}

// Model 论坛版主ORM模型
func (s *sSysForumModerator) Model(ctx context.Context, option ...*handler.Option) *gdb.Model {
	return handler.Model(dao.ForumModerator.Ctx(ctx), option...)
}

// List 获取论坛版主列表
func (s *sSysForumModerator) List(ctx context.Context, in *sysin.ForumModeratorListInp) (list []*sysin.ForumModeratorListModel, totalCount int, err error) {
	mod := s.Model(ctx)

	if in.Id > 0 {
		mod = mod.Where(dao.ForumModerator.Columns().Id, in.Id)
	}
	if in.BoardId > 0 {
		mod = mod.Where(dao.ForumModerator.Columns().BoardId, in.BoardId)
	}
	if in.UserId > 0 {
		mod = mod.Where(dao.ForumModerator.Columns().UserId, in.UserId)
	}
	if in.Status > 0 {
		mod = mod.Where(dao.ForumModerator.Columns().Status, in.Status)
	}
	if in.Keyword != "" {
		userIds, err := s.searchUserIds(ctx, in.Keyword)
		if err != nil {
			err = gerror.Wrap(err, "检索版主用户失败，请稍后重试！")
			return nil, 0, err
		}
		if len(userIds) == 0 {
			return []*sysin.ForumModeratorListModel{}, 0, nil
		}
		mod = mod.WhereIn(dao.ForumModerator.Columns().UserId, userIds)
	}

	mod = mod.Page(in.Page, in.PerPage).OrderDesc(dao.ForumModerator.Columns().Id)
	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取论坛版主列表失败，请稍后重试！")
		return
	}

	if err = s.fillNames(ctx, list); err != nil {
		return
	}
	return
}

// View 获取论坛版主指定信息
func (s *sSysForumModerator) View(ctx context.Context, in *sysin.ForumModeratorViewInp) (res *sysin.ForumModeratorListModel, err error) {
	if err = s.Model(ctx).WherePri(in.Id).Scan(&res); err != nil {
		err = gerror.Wrap(err, "获取论坛版主信息失败，请稍后重试！")
		return
	}
	if res == nil {
		err = gerror.New("版主记录不存在")
		return
	}

	if err = s.fillNames(ctx, []*sysin.ForumModeratorListModel{res}); err != nil {
		return
	}
	return
}

// Edit 修改/新增论坛版主（按 版块+用户 维度 upsert）
func (s *sSysForumModerator) Edit(ctx context.Context, in *sysin.ForumModeratorEditInp) (err error) {
	if err = s.checkBoardAndUser(ctx, in.BoardId, in.UserId); err != nil {
		return
	}

	operatorId := contexts.GetUserId(ctx)

	return g.DB().Transaction(ctx, func(ctx context.Context, tx gdb.TX) (err error) {
		// 指定ID：直接更新
		if in.Id > 0 {
			if _, err = s.Model(ctx).Fields(sysin.ForumModeratorUpdateFields{}).
				WherePri(in.Id).Data(g.Map{
				dao.ForumModerator.Columns().Permissions: in.Permissions,
				dao.ForumModerator.Columns().Remark:      in.Remark,
				dao.ForumModerator.Columns().Status:      in.Status,
				dao.ForumModerator.Columns().UpdatedBy:   operatorId,
			}).Update(); err != nil {
				err = gerror.Wrap(err, "修改版主失败，请稍后重试！")
			}
			return
		}

		// 未指定ID：按 版块+用户 查重，已存在则更新权限并复活
		exist, err := dao.ForumModerator.Ctx(ctx).
			Where(dao.ForumModerator.Columns().BoardId, in.BoardId).
			Where(dao.ForumModerator.Columns().UserId, in.UserId).
			One()
		if err != nil {
			err = gerror.Wrap(err, "校验版主失败，请稍后重试！")
			return
		}

		if !exist.IsEmpty() {
			if _, err = s.Model(ctx).WherePri(exist[dao.ForumModerator.Columns().Id].Int64()).
				Data(g.Map{
					dao.ForumModerator.Columns().Permissions: in.Permissions,
					dao.ForumModerator.Columns().Remark:      in.Remark,
					dao.ForumModerator.Columns().Status:      in.Status,
					dao.ForumModerator.Columns().AppointedBy: operatorId,
					dao.ForumModerator.Columns().AppointedAt: gtime.Now(),
					dao.ForumModerator.Columns().UpdatedBy:   operatorId,
				}).Update(); err != nil {
				err = gerror.Wrap(err, "修改版主失败，请稍后重试！")
			}
			return
		}

		if _, err = s.Model(ctx, &handler.Option{FilterAuth: false}).
			Fields(sysin.ForumModeratorInsertFields{}).
			Data(g.Map{
				dao.ForumModerator.Columns().BoardId:     in.BoardId,
				dao.ForumModerator.Columns().UserId:      in.UserId,
				dao.ForumModerator.Columns().Permissions: in.Permissions,
				dao.ForumModerator.Columns().Remark:      in.Remark,
				dao.ForumModerator.Columns().Status:      in.Status,
				dao.ForumModerator.Columns().AppointedBy: operatorId,
				dao.ForumModerator.Columns().AppointedAt: gtime.Now(),
				dao.ForumModerator.Columns().CreatedBy:   operatorId,
			}).OmitEmptyData().Insert(); err != nil {
			err = gerror.Wrap(err, "任命版主失败，请稍后重试！")
		}
		return
	})
}

// Delete 删除论坛版主（物理删除，纯关联表无历史价值）
func (s *sSysForumModerator) Delete(ctx context.Context, in *sysin.ForumModeratorDeleteInp) (err error) {
	ids := gconv.Int64s(in.Id)
	if len(ids) == 0 {
		err = gerror.New("ID不能为空")
		return
	}

	// 先取出待删记录，用于清理权限缓存
	var rows []*sysin.ForumModeratorListModel
	if err = dao.ForumModerator.Ctx(ctx).WhereIn(dao.ForumModerator.Columns().Id, ids).Scan(&rows); err != nil {
		err = gerror.Wrap(err, "获取版主信息失败，请稍后重试！")
		return
	}

	if _, err = dao.ForumModerator.Ctx(ctx).WhereIn(dao.ForumModerator.Columns().Id, ids).Unscoped().Delete(); err != nil {
		err = gerror.Wrap(err, "删除版主失败，请稍后重试！")
		return
	}

	for _, row := range rows {
		s.ClearPermCache(ctx, row.UserId, row.BoardId)
	}
	return
}

// Status 更新论坛版主状态
func (s *sSysForumModerator) Status(ctx context.Context, in *sysin.ForumModeratorStatusInp) (err error) {
	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.ForumModerator.Columns().Status:    in.Status,
		dao.ForumModerator.Columns().UpdatedBy: contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "更新版主状态失败，请稍后重试！")
		return
	}

	// 状态变更后清理权限缓存
	var row *sysin.ForumModeratorListModel
	if err = dao.ForumModerator.Ctx(ctx).WherePri(in.Id).Scan(&row); err != nil {
		return
	}
	if row != nil {
		s.ClearPermCache(ctx, row.UserId, row.BoardId)
	}
	return
}

// GetPermissions 获取指定用户在指定版块的权限位图
// 返回 ok 表示该用户是否为本版块的有效版主；perms 为权限位图。
func (s *sSysForumModerator) GetPermissions(ctx context.Context, userId, boardId int64) (perms int, ok bool, err error) {
	if userId <= 0 || boardId <= 0 {
		return
	}

	cacheKey := s.permCacheKey(userId, boardId)
	cacheVar, err := cache.Instance().Get(ctx, cacheKey)
	if err == nil && cacheVar != nil && !cacheVar.IsNil() && cacheVar.String() != "" {
		perms = cacheVar.Int()
		ok = perms >= 0
		return
	}

	var row *struct {
		Permissions uint `json:"permissions"`
	}
	if err = dao.ForumModerator.Ctx(ctx).
		Fields(dao.ForumModerator.Columns().Permissions).
		Where(dao.ForumModerator.Columns().UserId, userId).
		Where(dao.ForumModerator.Columns().BoardId, boardId).
		Where(dao.ForumModerator.Columns().Status, consts.StatusEnabled).
		Scan(&row); err != nil {
		err = gerror.Wrap(err, "查询版主权限失败，请稍后重试！")
		return
	}

	if row == nil {
		perms = -1 // 缓存 -1 表示非版主，避免每次请求都查库
		ok = false
		_ = cache.Instance().Set(ctx, cacheKey, perms, moderatorPermCacheTTL)
		return
	}

	perms = int(row.Permissions)
	ok = true
	_ = cache.Instance().Set(ctx, cacheKey, perms, moderatorPermCacheTTL)
	return
}

// HasPermission 判断指定用户在指定版块是否拥有某权限位
func (s *sSysForumModerator) HasPermission(ctx context.Context, userId, boardId int64, perm int) (bool, error) {
	perms, ok, err := s.GetPermissions(ctx, userId, boardId)
	if err != nil {
		return false, err
	}
	if !ok {
		return false, nil
	}
	return consts.HasModeratorPerm(perms, perm), nil
}

// GetMyBoards 获取指定用户担任版主的版块列表（含权限位图）
func (s *sSysForumModerator) GetMyBoards(ctx context.Context, userId int64) (list []*sysin.ForumModeratorListModel, err error) {
	if userId <= 0 {
		return
	}

	if err = dao.ForumModerator.Ctx(ctx).
		Where(dao.ForumModerator.Columns().UserId, userId).
		Where(dao.ForumModerator.Columns().Status, consts.StatusEnabled).
		OrderAsc(dao.ForumModerator.Columns().BoardId).
		Scan(&list); err != nil {
		err = gerror.Wrap(err, "获取我管理的版块失败，请稍后重试！")
		return
	}

	if err = s.fillNames(ctx, list); err != nil {
		return
	}
	return
}

// ClearPermCache 清理指定用户在某版块的权限缓存
func (s *sSysForumModerator) ClearPermCache(ctx context.Context, userId, boardId int64) {
	if userId <= 0 || boardId <= 0 {
		return
	}
	_, _ = cache.Instance().Remove(ctx, s.permCacheKey(userId, boardId))
}

// ClearUserPermCache 清理指定用户在所有版块的权限缓存（用户维度变更时使用）
func (s *sSysForumModerator) ClearUserPermCache(ctx context.Context, userId int64) {
	if userId <= 0 {
		return
	}
	var rows []*sysin.ForumModeratorListModel
	if err := dao.ForumModerator.Ctx(ctx).
		Fields(dao.ForumModerator.Columns().BoardId).
		Where(dao.ForumModerator.Columns().UserId, userId).
		Scan(&rows); err != nil {
		return
	}
	for _, row := range rows {
		s.ClearPermCache(ctx, userId, row.BoardId)
	}
}

// permCacheKey 版主权限缓存 key
func (s *sSysForumModerator) permCacheKey(userId, boardId int64) string {
	return consts.CacheModeratorPerm + ":" + gconv.String(userId) + ":" + gconv.String(boardId)
}

// searchUserIds 按账号/昵称模糊检索用户ID
func (s *sSysForumModerator) searchUserIds(ctx context.Context, keyword string) (ids []int64, err error) {
	var rows []*struct {
		Id int64 `json:"id"`
	}
	err = dao.User.Ctx(ctx).
		Fields(dao.User.Columns().Id).
		WhereLike(dao.User.Columns().Username, "%"+keyword+"%").
		WhereOrLike(dao.User.Columns().Nickname, "%"+keyword+"%").
		Limit(200).
		Scan(&rows)
	if err != nil {
		return
	}
	for _, row := range rows {
		ids = append(ids, row.Id)
	}
	return
}

// fillNames 填充版块名称、版主昵称、任命人名称
func (s *sSysForumModerator) fillNames(ctx context.Context, list []*sysin.ForumModeratorListModel) (err error) {
	if len(list) == 0 {
		return
	}

	var boardIds, userIds, adminIds []int64
	for _, row := range list {
		boardIds = append(boardIds, row.BoardId)
		userIds = append(userIds, row.UserId)
		if row.AppointedBy > 0 {
			adminIds = append(adminIds, row.AppointedBy)
		}
	}

	// 版块名称
	boardNames := map[int64]string{}
	if len(boardIds) > 0 {
		var rows []*struct {
			Id   int64  `json:"id"`
			Name string `json:"name"`
		}
		if err = dao.ForumBoard.Ctx(ctx).Fields(dao.ForumBoard.Columns().Id, dao.ForumBoard.Columns().Name).
			WhereIn(dao.ForumBoard.Columns().Id, boardIds).Scan(&rows); err != nil {
			err = gerror.Wrap(err, "获取版块信息失败，请稍后重试！")
			return
		}
		for _, row := range rows {
			boardNames[row.Id] = row.Name
		}
	}

	// 用户账号/昵称
	userAccounts := map[int64]string{}
	userNicknames := map[int64]string{}
	if len(userIds) > 0 {
		var rows []*struct {
			Id       int64  `json:"id"`
			Username string `json:"username"`
			Nickname string `json:"nickname"`
		}
		if err = dao.User.Ctx(ctx).
			Fields(dao.User.Columns().Id, dao.User.Columns().Username, dao.User.Columns().Nickname).
			WhereIn(dao.User.Columns().Id, userIds).Scan(&rows); err != nil {
			err = gerror.Wrap(err, "获取用户信息失败，请稍后重试！")
			return
		}
		for _, row := range rows {
			userAccounts[row.Id] = row.Username
			userNicknames[row.Id] = row.Nickname
		}
	}

	// 任命人名称
	adminNames := map[int64]string{}
	if len(adminIds) > 0 {
		var rows []*struct {
			Id       int64  `json:"id"`
			Username string `json:"username"`
			RealName string `json:"realName"`
		}
		if err = dao.AdminMember.Ctx(ctx).
			Fields(dao.AdminMember.Columns().Id, dao.AdminMember.Columns().Username, dao.AdminMember.Columns().RealName).
			WhereIn(dao.AdminMember.Columns().Id, adminIds).Scan(&rows); err != nil {
			err = gerror.Wrap(err, "获取任命人信息失败，请稍后重试！")
			return
		}
		for _, row := range rows {
			name := row.RealName
			if name == "" {
				name = row.Username
			}
			adminNames[row.Id] = name
		}
	}

	for _, row := range list {
		row.BoardName = boardNames[row.BoardId]
		row.UserAccount = userAccounts[row.UserId]
		row.UserNickname = userNicknames[row.UserId]
		row.AppointerName = adminNames[row.AppointedBy]
	}
	return
}

// checkBoardAndUser 校验版块与用户是否有效
func (s *sSysForumModerator) checkBoardAndUser(ctx context.Context, boardId, userId int64) (err error) {
	boardCount, err := dao.ForumBoard.Ctx(ctx).WherePri(boardId).Count()
	if err != nil {
		err = gerror.Wrap(err, "校验版块失败，请稍后重试！")
		return
	}
	if boardCount == 0 {
		err = gerror.New("版块不存在")
		return
	}

	userCount, err := dao.User.Ctx(ctx).WherePri(userId).Count()
	if err != nil {
		err = gerror.Wrap(err, "校验用户失败，请稍后重试！")
		return
	}
	if userCount == 0 {
		err = gerror.New("用户不存在")
		return
	}
	return
}
