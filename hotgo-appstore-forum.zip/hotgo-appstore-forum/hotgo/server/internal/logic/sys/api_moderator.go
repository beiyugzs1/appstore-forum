// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"

	"hotgo/internal/consts"
	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/encoding/gjson"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
	"github.com/gogf/gf/v2/text/gstr"
)

type sSysApiModerator struct{}

func NewSysApiModerator() *sSysApiModerator {
	return &sSysApiModerator{}
}

func init() {
	service.RegisterSysApiModerator(NewSysApiModerator())
}

// MyBoards 获取我担任版主的版块列表
func (s *sSysApiModerator) MyBoards(ctx context.Context) (res *apiin.ApiModeratorMyBoardsModel, err error) {
	userId := contexts.GetUserId(ctx)
	if userId <= 0 {
		err = gerror.New("登录身份已失效，请重新登录")
		return
	}

	rows, err := service.SysForumModerator().GetMyBoards(ctx, userId)
	if err != nil {
		return
	}

	res = &apiin.ApiModeratorMyBoardsModel{List: []*apiin.ApiModeratorBoardModel{}}
	for _, row := range rows {
		res.List = append(res.List, &apiin.ApiModeratorBoardModel{
			BoardId:     row.BoardId,
			BoardName:   row.BoardName,
			Permissions: int(row.Permissions),
		})
	}
	return
}

// Permission 获取我在指定版块的版主权限
func (s *sSysApiModerator) Permission(ctx context.Context, in *apiin.ApiModeratorPermissionInp) (res *apiin.ApiModeratorPermissionModel, err error) {
	userId := contexts.GetUserId(ctx)
	if userId <= 0 {
		err = gerror.New("登录身份已失效，请重新登录")
		return
	}

	perms, ok, err := service.SysForumModerator().GetPermissions(ctx, userId, in.BoardId)
	if err != nil {
		return
	}

	res = &apiin.ApiModeratorPermissionModel{IsModerator: ok}
	if ok {
		res.Permissions = perms
	}
	return
}

// PendingPosts 获取本版待审帖子列表
func (s *sSysApiModerator) PendingPosts(ctx context.Context, in *apiin.ApiModeratorPendingPostListInp) (list []*apiin.ApiModeratorPendingPostModel, totalCount int, err error) {
	if err = s.requirePerm(ctx, in.BoardId, consts.ModeratorPermAuditPost, "审核帖子"); err != nil {
		return
	}

	var rows []*struct {
		Id        int64       `json:"id"`
		BoardId   int64       `json:"boardId"`
		UserId    int64       `json:"userId"`
		Title     string      `json:"title"`
		Content   string      `json:"content"`
		Images    *gjson.Json `json:"images"`
		CreatedAt *gtime.Time `json:"createdAt"`
	}

	columns := dao.ForumPost.Columns()
	mod := dao.ForumPost.Ctx(ctx).
		Where(columns.BoardId, in.BoardId).
		Where(columns.AuditStatus, consts.AuditStatusPending).
		Where(columns.Status, consts.StatusEnabled)

	mod = mod.Page(in.Page, in.PerPage).OrderDesc(columns.Id)
	if err = mod.ScanAndCount(&rows, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取待审帖子失败，请稍后重试！")
		return
	}

	list = []*apiin.ApiModeratorPendingPostModel{}
	if len(rows) == 0 {
		return
	}

	userIds := make([]int64, 0, len(rows))
	for _, row := range rows {
		userIds = append(userIds, row.UserId)
	}
	nicknames, err := s.loadNicknames(ctx, userIds)
	if err != nil {
		return
	}

	for _, row := range rows {
		item := &apiin.ApiModeratorPendingPostModel{
			Id:           row.Id,
			BoardId:      row.BoardId,
			UserId:       row.UserId,
			UserNickname: nicknames[row.UserId],
			Title:        row.Title,
			Summary:      gstr.SubStr(gstr.Trim(row.Content), 0, 100),
			CreatedAt:    row.CreatedAt,
		}
		if row.Images != nil {
			item.Images = row.Images.Var().Strings()
		}
		list = append(list, item)
	}
	return
}

// PendingComments 获取本版待审评论列表
func (s *sSysApiModerator) PendingComments(ctx context.Context, in *apiin.ApiModeratorPendingCommentListInp) (list []*apiin.ApiModeratorPendingCommentModel, totalCount int, err error) {
	if err = s.requirePerm(ctx, in.BoardId, consts.ModeratorPermAuditComment, "审核评论"); err != nil {
		return
	}

	c := dao.ForumComment.Columns()
	p := dao.ForumPost.Columns()
	u := dao.User.Columns()

	fields := "c.*, p." + p.Title + " as postTitle, u." + u.Nickname + " as userNickname"
	mod := dao.ForumComment.Ctx(ctx).As("c").
		LeftJoin(dao.ForumPost.Table()+" p", "p."+p.Id+" = c."+c.PostId).
		LeftJoin(dao.User.Table()+" u", "u."+u.Id+" = c."+c.UserId).
		Fields(fields).
		Where("p."+p.BoardId, in.BoardId).
		Where("c."+c.AuditStatus, consts.AuditStatusPending).
		Where("c."+c.Status, consts.StatusEnabled)

	mod = mod.Page(in.Page, in.PerPage).OrderDesc("c." + c.Id)
	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取待审评论失败，请稍后重试！")
		return
	}

	if list == nil {
		list = []*apiin.ApiModeratorPendingCommentModel{}
	}
	return
}

// AuditPost 版主审核帖子
//
// 说明：此处不走后台的 service.SysForumPost().Audit，因为其内部使用
// handler.Model 的数据权限过滤（依赖后台角色），而 C 端登录用户没有角色信息，
// 会触发 "roleModel == nil"。版主场景下权限已由 requirePerm 校验，直接操作 dao 更安全。
func (s *sSysApiModerator) AuditPost(ctx context.Context, in *apiin.ApiModeratorAuditPostInp) (err error) {
	boardId, err := s.postBoardId(ctx, in.Id)
	if err != nil {
		return
	}
	if err = s.requirePerm(ctx, boardId, consts.ModeratorPermAuditPost, "审核帖子"); err != nil {
		return
	}

	userId := contexts.GetUserId(ctx)
	if _, err = dao.ForumPost.Ctx(ctx).WherePri(in.Id).Data(g.Map{
		dao.ForumPost.Columns().AuditStatus: in.AuditStatus,
		dao.ForumPost.Columns().AuditRemark: in.AuditRemark,
		dao.ForumPost.Columns().AuditBy:     userId,
		dao.ForumPost.Columns().AuditAt:     gtime.Now(),
		dao.ForumPost.Columns().UpdatedBy:   userId,
	}).Update(); err != nil {
		err = gerror.Wrap(err, "审核帖子失败，请稍后重试！")
		return
	}

	// 审核通过后刷新版块帖子数
	if in.AuditStatus == consts.AuditStatusPass {
		_ = s.refreshBoardPostCount(ctx, boardId)
	}
	return
}

// AuditComment 版主审核评论
func (s *sSysApiModerator) AuditComment(ctx context.Context, in *apiin.ApiModeratorAuditCommentInp) (err error) {
	boardId, err := s.commentBoardId(ctx, in.Id)
	if err != nil {
		return
	}
	if err = s.requirePerm(ctx, boardId, consts.ModeratorPermAuditComment, "审核评论"); err != nil {
		return
	}

	userId := contexts.GetUserId(ctx)
	if _, err = dao.ForumComment.Ctx(ctx).WherePri(in.Id).Data(g.Map{
		dao.ForumComment.Columns().AuditStatus: in.AuditStatus,
		dao.ForumComment.Columns().AuditRemark: in.AuditRemark,
		dao.ForumComment.Columns().AuditBy:     userId,
		dao.ForumComment.Columns().AuditAt:     gtime.Now(),
		dao.ForumComment.Columns().UpdatedBy:   userId,
	}).Update(); err != nil {
		err = gerror.Wrap(err, "审核评论失败，请稍后重试！")
		return
	}

	// 刷新帖子的评论数（复用论坛模块内的辅助函数）
	var comment *struct {
		PostId int64 `json:"postId"`
	}
	if e := dao.ForumComment.Ctx(ctx).Fields(dao.ForumComment.Columns().PostId).
		WherePri(in.Id).Scan(&comment); e == nil && comment != nil {
		_ = serviceRefreshCommentCount(ctx, comment.PostId)
	}
	return
}

// TopPost 版主置顶/取消置顶帖子
func (s *sSysApiModerator) TopPost(ctx context.Context, in *apiin.ApiModeratorTopPostInp) (err error) {
	boardId, err := s.postBoardId(ctx, in.Id)
	if err != nil {
		return
	}
	if err = s.requirePerm(ctx, boardId, consts.ModeratorPermTop, "置顶帖子"); err != nil {
		return
	}

	if _, err = dao.ForumPost.Ctx(ctx).WherePri(in.Id).Data(g.Map{
		dao.ForumPost.Columns().IsTop:     in.IsTop,
		dao.ForumPost.Columns().UpdatedBy: contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "操作失败，请稍后重试！")
	}
	return
}

// EssencePost 版主加精/取消加精帖子
func (s *sSysApiModerator) EssencePost(ctx context.Context, in *apiin.ApiModeratorEssencePostInp) (err error) {
	boardId, err := s.postBoardId(ctx, in.Id)
	if err != nil {
		return
	}
	if err = s.requirePerm(ctx, boardId, consts.ModeratorPermEssence, "加精帖子"); err != nil {
		return
	}

	if _, err = dao.ForumPost.Ctx(ctx).WherePri(in.Id).Data(g.Map{
		dao.ForumPost.Columns().IsEssence: in.IsEssence,
		dao.ForumPost.Columns().UpdatedBy: contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "操作失败，请稍后重试！")
	}
	return
}

// DeletePost 版主删除帖子（软删除）
func (s *sSysApiModerator) DeletePost(ctx context.Context, in *apiin.ApiModeratorIdInp) (err error) {
	boardId, err := s.postBoardId(ctx, in.Id)
	if err != nil {
		return
	}
	if err = s.requirePerm(ctx, boardId, consts.ModeratorPermDeletePost, "删除帖子"); err != nil {
		return
	}

	if _, err = dao.ForumPost.Ctx(ctx).WherePri(in.Id).Data(g.Map{
		dao.ForumPost.Columns().DeletedBy: contexts.GetUserId(ctx),
		dao.ForumPost.Columns().DeletedAt: gtime.Now(),
	}).Unscoped().Update(); err != nil {
		err = gerror.Wrap(err, "删除失败，请稍后重试！")
		return
	}

	_ = s.refreshBoardPostCount(ctx, boardId)
	return
}

// DeleteComment 版主删除评论（软删除）
func (s *sSysApiModerator) DeleteComment(ctx context.Context, in *apiin.ApiModeratorIdInp) (err error) {
	boardId, err := s.commentBoardId(ctx, in.Id)
	if err != nil {
		return
	}
	if err = s.requirePerm(ctx, boardId, consts.ModeratorPermDeleteComment, "删除评论"); err != nil {
		return
	}

	if _, err = dao.ForumComment.Ctx(ctx).WherePri(in.Id).Data(g.Map{
		dao.ForumComment.Columns().DeletedBy: contexts.GetUserId(ctx),
		dao.ForumComment.Columns().DeletedAt: gtime.Now(),
	}).Unscoped().Update(); err != nil {
		err = gerror.Wrap(err, "删除失败，请稍后重试！")
	}
	return
}

// BanUser 版主封禁/禁言本版用户
func (s *sSysApiModerator) BanUser(ctx context.Context, in *apiin.ApiModeratorBanUserInp) (err error) {
	moderatorId := contexts.GetUserId(ctx)
	if moderatorId <= 0 {
		err = gerror.New("登录身份已失效，请重新登录")
		return
	}
	if moderatorId == in.UserId {
		err = gerror.New("不能封禁自己")
		return
	}

	if err = s.requirePerm(ctx, in.BoardId, consts.ModeratorPermBanUser, "封禁本版用户"); err != nil {
		return
	}

	return service.SysUserBan().BanByModerator(ctx, &sysin.UserBanModeratorBanInp{
		BoardId:    in.BoardId,
		UserId:     in.UserId,
		Type:       in.Type,
		ExpireAt:   in.ExpireAt,
		Reason:     in.Reason,
		OperatorId: moderatorId,
	})
}

// requirePerm 校验当前登录用户对指定版块是否拥有指定权限位
func (s *sSysApiModerator) requirePerm(ctx context.Context, boardId int64, perm int, permName string) (err error) {
	userId := contexts.GetUserId(ctx)
	if userId <= 0 {
		err = gerror.New("登录身份已失效，请重新登录")
		return
	}
	if boardId <= 0 {
		err = gerror.New("版块ID不能为空")
		return
	}

	ok, err := service.SysForumModerator().HasPermission(ctx, userId, boardId, perm)
	if err != nil {
		return
	}
	if !ok {
		err = gerror.Newf("你没有「%s」权限", permName)
		return
	}
	return
}

// postBoardId 获取帖子所属版块ID（同时校验帖子存在）
func (s *sSysApiModerator) postBoardId(ctx context.Context, postId int64) (boardId int64, err error) {
	var row *struct {
		BoardId int64 `json:"boardId"`
	}
	if err = dao.ForumPost.Ctx(ctx).
		Fields(dao.ForumPost.Columns().BoardId).
		WherePri(postId).Scan(&row); err != nil {
		err = gerror.Wrap(err, "查询帖子失败，请稍后重试！")
		return
	}
	if row == nil {
		err = gerror.New("帖子不存在")
		return
	}
	boardId = row.BoardId
	return
}

// commentBoardId 获取评论所属帖子所在版块ID（同时校验评论存在）
func (s *sSysApiModerator) commentBoardId(ctx context.Context, commentId int64) (boardId int64, err error) {
	var comment *struct {
		PostId int64 `json:"postId"`
	}
	if err = dao.ForumComment.Ctx(ctx).
		Fields(dao.ForumComment.Columns().PostId).
		WherePri(commentId).Scan(&comment); err != nil {
		err = gerror.Wrap(err, "查询评论失败，请稍后重试！")
		return
	}
	if comment == nil {
		err = gerror.New("评论不存在")
		return
	}

	return s.postBoardId(ctx, comment.PostId)
}

// refreshBoardPostCount 刷新版块帖子数（直接操作 dao，规避后台数据权限过滤）
func (s *sSysApiModerator) refreshBoardPostCount(ctx context.Context, boardId int64) (err error) {
	if boardId <= 0 {
		return
	}

	count, err := dao.ForumPost.Ctx(ctx).
		Where(dao.ForumPost.Columns().BoardId, boardId).
		Where(dao.ForumPost.Columns().AuditStatus, consts.AuditStatusPass).Count()
	if err != nil {
		return
	}

	_, err = dao.ForumBoard.Ctx(ctx).WherePri(boardId).Data(g.Map{
		dao.ForumBoard.Columns().PostCount: count,
	}).Update()
	return
}

// loadNicknames 批量加载用户昵称
func (s *sSysApiModerator) loadNicknames(ctx context.Context, userIds []int64) (names map[int64]string, err error) {
	names = map[int64]string{}
	if len(userIds) == 0 {
		return
	}

	var rows []*struct {
		Id       int64  `json:"id"`
		Nickname string `json:"nickname"`
	}
	if err = dao.User.Ctx(ctx).
		Fields(dao.User.Columns().Id, dao.User.Columns().Nickname).
		WhereIn(dao.User.Columns().Id, userIds).Scan(&rows); err != nil {
		err = gerror.Wrap(err, "获取用户信息失败，请稍后重试！")
		return
	}
	for _, row := range rows {
		names[row.Id] = row.Nickname
	}
	return
}
