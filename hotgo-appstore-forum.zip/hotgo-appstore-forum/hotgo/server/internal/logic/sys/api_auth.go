// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"time"

	"hotgo/internal/consts"
	"hotgo/internal/dao"
	"hotgo/internal/library/cache"
	"hotgo/internal/library/token"
	"hotgo/internal/model"
	"hotgo/internal/model/entity"
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/crypto/gmd5"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/net/ghttp"
	"github.com/gogf/gf/v2/os/gtime"
	"github.com/gogf/gf/v2/util/gconv"
	"github.com/gogf/gf/v2/util/grand"
)

// 双令牌默认有效期（可在 config.yaml 的 token.apiAccessExpires / token.apiRefreshExpires 覆盖）
const (
	defaultApiAccessExpires  int64 = 7200    // access token：2 小时
	defaultApiRefreshExpires int64 = 2592000 // refresh token：30 天
)

type sSysApiAuth struct{}

func NewSysApiAuth() *sSysApiAuth {
	return &sSysApiAuth{}
}

func init() {
	service.RegisterSysApiAuth(NewSysApiAuth())
}

// apiTokenTTL 获取 C 端双令牌有效期配置
func apiTokenTTL() (accessExpires, refreshExpires int64) {
	accessExpires = defaultApiAccessExpires
	refreshExpires = defaultApiRefreshExpires

	cfg := token.GetConfig()
	if cfg == nil {
		return
	}
	if cfg.ApiAccessExpires > 0 {
		accessExpires = cfg.ApiAccessExpires
	}
	if cfg.ApiRefreshExpires > 0 {
		refreshExpires = cfg.ApiRefreshExpires
	}
	return
}

// apiRefreshCacheKey refresh token 缓存键
func apiRefreshCacheKey(refreshToken string) string {
	return consts.CacheApiRefresh + ":" + token.GetAuthKey(refreshToken)
}

// apiIssueTokens 为 C 端用户签发 access + refresh 双令牌
//
// access token 复用框架的 token.Login（签名与校验逻辑一致，缓存命名空间为 api，
// 与 admin 的 token 完全隔离）；签发后立即用更短的有效期覆盖其缓存状态，
// 从而实现「短 access + 长 refresh」的双令牌模型。
func apiIssueTokens(ctx context.Context, user *entity.User) (accessToken, refreshToken string, expires int64, err error) {
	accessExpires, refreshExpires := apiTokenTTL()
	now := gtime.Now()

	identity := &model.Identity{
		Id:       user.Id,
		Username: user.Username,
		RealName: user.Nickname,
		Avatar:   user.Avatar,
		Email:    user.Email,
		Mobile:   user.Mobile,
		App:      consts.AppApi,
		LoginAt:  now,
	}

	accessToken, _, err = token.Login(ctx, identity)
	if err != nil {
		err = gerror.Wrap(err, "签发访问令牌失败，请稍后重试！")
		return
	}

	// 用较短的 TTL 覆盖 access token 的缓存状态
	if err = cache.Instance().Set(
		ctx,
		token.GetTokenKey(consts.AppApi, token.GetAuthKey(accessToken)),
		token.Token{
			ExpireAt:     now.Unix() + accessExpires,
			RefreshAt:    now.Unix(),
			RefreshCount: 0,
		},
		time.Duration(accessExpires)*time.Second,
	); err != nil {
		err = gerror.Wrap(err, "签发访问令牌失败，请稍后重试！")
		return
	}

	// 签发 refresh token（不透明串，状态存缓存）
	refreshToken = grand.S(64)
	if err = cache.Instance().Set(
		ctx,
		apiRefreshCacheKey(refreshToken),
		g.Map{
			"userId":   user.Id,
			"expireAt": now.Unix() + refreshExpires,
		},
		time.Duration(refreshExpires)*time.Second,
	); err != nil {
		err = gerror.Wrap(err, "签发刷新令牌失败，请稍后重试！")
		return
	}

	expires = accessExpires
	return
}

// apiRevokeRefresh 吊销一个 refresh token
func apiRevokeRefresh(ctx context.Context, refreshToken string) {
	if refreshToken == "" {
		return
	}
	_, _ = cache.Instance().Remove(ctx, apiRefreshCacheKey(refreshToken))
}

// apiFetchUserByRefresh 通过 refresh token 换取用户ID
func apiFetchUserByRefresh(ctx context.Context, refreshToken string) (userId int64, err error) {
	if refreshToken == "" {
		err = gerror.New("refreshToken不能为空")
		return
	}

	val, err := cache.Instance().Get(ctx, apiRefreshCacheKey(refreshToken))
	if err != nil {
		err = gerror.Wrap(err, "校验刷新令牌失败，请稍后重试！")
		return
	}
	if val == nil || val.IsEmpty() {
		err = gerror.New("登录状态已过期，请重新登录")
		return
	}

	// 缓存经 JSON 序列化后数字可能变为 float64，统一用 gconv 转换
	if v, ok := val.Map()["userId"]; ok {
		userId = gconv.Int64(v)
	}
	if userId <= 0 {
		err = gerror.New("登录状态已过期，请重新登录")
		return
	}
	return
}

// Login 账号密码登录
func (s *sSysApiAuth) Login(ctx context.Context, in *apiin.ApiLoginInp) (res *apiin.ApiLoginModel, err error) {
	var user *entity.User
	if err = dao.User.Ctx(ctx).
		Where(dao.User.Columns().Username, in.Account).
		WhereOr(dao.User.Columns().Mobile, in.Account).
		Scan(&user); err != nil {
		err = gerror.Wrap(err, "获取用户信息失败，请稍后重试！")
		return
	}

	if user == nil {
		err = gerror.New("账号或密码错误")
		return
	}
	if user.Salt == "" {
		err = gerror.New("用户信息异常")
		return
	}
	if gmd5.MustEncryptString(in.Password+user.Salt) != user.PasswordHash {
		err = gerror.New("账号或密码错误")
		return
	}
	if user.Status != consts.StatusEnabled {
		err = gerror.New("账号已被禁用，请联系客服")
		return
	}

	// 校验是否处于封禁状态（禁止登录）
	if banned, msg, banErr := service.SysUserBan().Check(ctx, user.Id, 0, consts.BanActionLogin); banErr != nil {
		err = banErr
		return
	} else if banned {
		err = gerror.New(msg)
		return
	}

	var (
		accessToken  string
		refreshToken string
		expires      int64
	)
	if accessToken, refreshToken, expires, err = apiIssueTokens(ctx, user); err != nil {
		return
	}

	// 记录登录信息
	clientIp := ""
	if r := ghttp.RequestFromCtx(ctx); r != nil {
		clientIp = r.GetClientIp()
	}
	if _, err = dao.User.Ctx(ctx).WherePri(user.Id).Data(g.Map{
		dao.User.Columns().LastLoginAt: gtime.Now(),
		dao.User.Columns().LastLoginIp: clientIp,
	}).Update(); err != nil {
		err = gerror.Wrap(err, "更新登录信息失败，请稍后重试！")
		return
	}

	res = &apiin.ApiLoginModel{
		UserId:       user.Id,
		Username:     user.Username,
		Nickname:     user.Nickname,
		Avatar:       user.Avatar,
		IsVip:        user.VipExpireAt != nil && user.VipExpireAt.After(gtime.Now()),
		VipExpireAt:  user.VipExpireAt,
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		Expires:      expires,
	}
	return
}

// Register 用户注册
func (s *sSysApiAuth) Register(ctx context.Context, in *apiin.ApiRegisterInp) (res *apiin.ApiRegisterModel, err error) {
	count, err := dao.User.Ctx(ctx).Where(dao.User.Columns().Username, in.Username).Count()
	if err != nil {
		err = gerror.Wrap(err, "校验用户名失败，请稍后重试！")
		return
	}
	if count > 0 {
		err = gerror.New("用户名已被注册")
		return
	}

	if in.Mobile != "" {
		count, err = dao.User.Ctx(ctx).Where(dao.User.Columns().Mobile, in.Mobile).Count()
		if err != nil {
			err = gerror.Wrap(err, "校验手机号失败，请稍后重试！")
			return
		}
		if count > 0 {
			err = gerror.New("手机号已被注册")
			return
		}
	}

	var (
		salt     = grand.S(6)
		nickname = in.Nickname
		clientIp = ""
	)
	if nickname == "" {
		nickname = in.Username
	}
	if r := ghttp.RequestFromCtx(ctx); r != nil {
		clientIp = r.GetClientIp()
	}

	id, err := dao.User.Ctx(ctx).Data(g.Map{
		dao.User.Columns().Username:     in.Username,
		dao.User.Columns().Nickname:     nickname,
		dao.User.Columns().PasswordHash: gmd5.MustEncryptString(in.Password + salt),
		dao.User.Columns().Salt:         salt,
		dao.User.Columns().Mobile:       in.Mobile,
		dao.User.Columns().RegisterIp:   clientIp,
		dao.User.Columns().InviteCode:   grand.S(6),
		dao.User.Columns().Status:       consts.StatusEnabled,
	}).InsertAndGetId()
	if err != nil {
		err = gerror.Wrap(err, "注册失败，请稍后重试！")
		return
	}

	res = &apiin.ApiRegisterModel{
		UserId:   id,
		Username: in.Username,
	}
	return
}

// Refresh 刷新访问令牌（令牌轮换）
func (s *sSysApiAuth) Refresh(ctx context.Context, in *apiin.ApiRefreshInp) (res *apiin.ApiRefreshModel, err error) {
	userId, err := apiFetchUserByRefresh(ctx, in.RefreshToken)
	if err != nil {
		return
	}

	var user *entity.User
	if err = dao.User.Ctx(ctx).WherePri(userId).Scan(&user); err != nil {
		err = gerror.Wrap(err, "获取用户信息失败，请稍后重试！")
		return
	}
	if user == nil {
		err = gerror.New("登录状态已过期，请重新登录")
		return
	}
	if user.Status != consts.StatusEnabled {
		err = gerror.New("账号已被禁用，请联系客服")
		return
	}

	// 校验是否处于封禁状态（封禁后不允许续期）
	if banned, msg, banErr := service.SysUserBan().Check(ctx, user.Id, 0, consts.BanActionLogin); banErr != nil {
		err = banErr
		return
	} else if banned {
		err = gerror.New(msg)
		return
	}

	var (
		accessToken  string
		refreshToken string
		expires      int64
	)
	if accessToken, refreshToken, expires, err = apiIssueTokens(ctx, user); err != nil {
		return
	}

	// 令牌轮换：旧 refresh 立即失效，防止重放
	apiRevokeRefresh(ctx, in.RefreshToken)

	res = &apiin.ApiRefreshModel{
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		Expires:      expires,
	}
	return
}

// Logout 退出登录
func (s *sSysApiAuth) Logout(ctx context.Context, in *apiin.ApiLogoutInp) (err error) {
	// 吊销 access token（复用框架登出逻辑：清除缓存中的令牌状态）
	if r := ghttp.RequestFromCtx(ctx); r != nil {
		_ = token.Logout(r)
	}

	// 吊销 refresh token
	apiRevokeRefresh(ctx, in.RefreshToken)
	return
}
