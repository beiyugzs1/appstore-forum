// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"

	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/model/entity"
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/crypto/gmd5"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
	"github.com/gogf/gf/v2/util/grand"
)

type sSysApiUser struct{}

func NewSysApiUser() *sSysApiUser {
	return &sSysApiUser{}
}

func init() {
	service.RegisterSysApiUser(NewSysApiUser())
}

// apiUserView 用户资料视图（用户表 + 套餐名）
type apiUserView struct {
	Id          int64       `json:"id"`
	Username    string      `json:"username"`
	Nickname    string      `json:"nickname"`
	Avatar      string      `json:"avatar"`
	Mobile      string      `json:"mobile"`
	Email       string      `json:"email"`
	Gender      int         `json:"gender"`
	VipPlanId   int64       `json:"vipPlanId"`
	VipPlanName string      `json:"vipPlanName"`
	VipExpireAt *gtime.Time `json:"vipExpireAt"`
	InviteCode  string      `json:"inviteCode"`
	LastLoginAt *gtime.Time `json:"lastLoginAt"`
	CreatedAt   *gtime.Time `json:"createdAt"`
}

// Info 获取个人资料
func (s *sSysApiUser) Info(ctx context.Context) (res *apiin.ApiUserInfoModel, err error) {
	userId := contexts.GetUserId(ctx)
	if userId <= 0 {
		err = gerror.New("登录身份已失效，请重新登录")
		return
	}

	var user *apiUserView
	if err = dao.User.Ctx(ctx).As("u").
		LeftJoin(dao.VipPlan.Table(), dao.VipPlan.Table()+"."+dao.VipPlan.Columns().Id+" = u."+dao.User.Columns().VipPlanId).
		Fields("u.*, " + dao.VipPlan.Table() + "." + dao.VipPlan.Columns().Name + " as vipPlanName").
		Where("u."+dao.User.Columns().Id, userId).
		Scan(&user); err != nil {
		err = gerror.Wrap(err, "获取个人资料失败，请稍后重试！")
		return
	}
	if user == nil {
		err = gerror.New("用户不存在")
		return
	}

	res = &apiin.ApiUserInfoModel{
		Id:          user.Id,
		Username:    user.Username,
		Nickname:    user.Nickname,
		Avatar:      user.Avatar,
		Mobile:      user.Mobile,
		Email:       user.Email,
		Gender:      user.Gender,
		IsVip:       user.VipExpireAt != nil && user.VipExpireAt.After(gtime.Now()),
		VipPlanId:   user.VipPlanId,
		VipPlanName: user.VipPlanName,
		VipExpireAt: user.VipExpireAt,
		InviteCode:  user.InviteCode,
		LastLoginAt: user.LastLoginAt,
		CreatedAt:   user.CreatedAt,
	}
	return
}

// UpdateProfile 修改个人资料
func (s *sSysApiUser) UpdateProfile(ctx context.Context, in *apiin.ApiUpdateProfileInp) (err error) {
	userId := contexts.GetUserId(ctx)
	if userId <= 0 {
		err = gerror.New("登录身份已失效，请重新登录")
		return
	}

	// 手机号唯一性校验
	if in.Mobile != "" {
		var mobileCount int
		mobileCount, err = dao.User.Ctx(ctx).Where(dao.User.Columns().Mobile, in.Mobile).
			WhereNot(dao.User.Columns().Id, userId).Count()
		if err != nil {
			err = gerror.Wrap(err, "校验手机号失败，请稍后重试！")
			return
		}
		if mobileCount > 0 {
			err = gerror.New("手机号已被其他账号使用")
			return
		}
	}

	if _, err = dao.User.Ctx(ctx).WherePri(userId).Data(g.Map{
		dao.User.Columns().Nickname: in.Nickname,
		dao.User.Columns().Avatar:   in.Avatar,
		dao.User.Columns().Gender:   in.Gender,
		dao.User.Columns().Email:    in.Email,
		dao.User.Columns().Mobile:   in.Mobile,
	}).Update(); err != nil {
		err = gerror.Wrap(err, "修改个人资料失败，请稍后重试！")
		return
	}
	return
}

// UpdatePwd 修改密码
func (s *sSysApiUser) UpdatePwd(ctx context.Context, in *apiin.ApiUpdatePwdInp) (err error) {
	userId := contexts.GetUserId(ctx)
	if userId <= 0 {
		err = gerror.New("登录身份已失效，请重新登录")
		return
	}

	var user *entity.User
	if err = dao.User.Ctx(ctx).WherePri(userId).Scan(&user); err != nil {
		err = gerror.Wrap(err, "获取用户信息失败，请稍后重试！")
		return
	}
	if user == nil {
		err = gerror.New("用户不存在")
		return
	}

	if gmd5.MustEncryptString(in.OldPassword+user.Salt) != user.PasswordHash {
		err = gerror.New("原密码不正确")
		return
	}

	salt := grand.S(6)
	if _, err = dao.User.Ctx(ctx).WherePri(userId).Data(g.Map{
		dao.User.Columns().Salt:         salt,
		dao.User.Columns().PasswordHash: gmd5.MustEncryptString(in.NewPassword + salt),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "修改密码失败，请稍后重试！")
		return
	}
	return
}

// BanStatus 获取我的封禁/禁言状态
func (s *sSysApiUser) BanStatus(ctx context.Context) (res *sysin.UserBanStatusModel, err error) {
	userId := contexts.GetUserId(ctx)
	if userId <= 0 {
		err = gerror.New("登录身份已失效，请重新登录")
		return
	}
	return service.SysUserBan().GetActiveByUser(ctx, userId)
}
