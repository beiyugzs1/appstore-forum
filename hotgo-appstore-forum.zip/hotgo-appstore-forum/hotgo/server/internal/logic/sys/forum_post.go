// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/internal/consts"
	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/library/hgorm/handler"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
)

type sSysForumPost struct{}

func NewSysForumPost() *sSysForumPost {
	return &sSysForumPost{}
}

func init() {
	service.RegisterSysForumPost(NewSysForumPost())
}

// Model 帖子ORM模型
func (s *sSysForumPost) Model(ctx context.Context, option ...*handler.Option) *gdb.Model {
	return handler.Model(dao.ForumPost.Ctx(ctx), option...)
}

// List 获取帖子列表
func (s *sSysForumPost) List(ctx context.Context, in *sysin.ForumPostListInp) (list []*sysin.ForumPostListModel, totalCount int, err error) {
	mod := s.Model(ctx).As("p").
		LeftJoin(dao.ForumBoard.Table(), dao.ForumBoard.Table()+"."+dao.ForumBoard.Columns().Id+" = p."+dao.ForumPost.Columns().BoardId).
		LeftJoin(dao.User.Table(), dao.User.Table()+"."+dao.User.Columns().Id+" = p."+dao.ForumPost.Columns().UserId).
		Fields("p.*, " + dao.ForumBoard.Table() + "." + dao.ForumBoard.Columns().Name + " as boardName, " +
			dao.User.Table() + "." + dao.User.Columns().Nickname + " as userNickname, " +
			dao.User.Table() + "." + dao.User.Columns().Username + " as userAccount")

	if in.Id > 0 {
		mod = mod.Where("p."+dao.ForumPost.Columns().Id, in.Id)
	}
	if in.BoardId > 0 {
		mod = mod.Where("p."+dao.ForumPost.Columns().BoardId, in.BoardId)
	}
	if in.UserId > 0 {
		mod = mod.Where("p."+dao.ForumPost.Columns().UserId, in.UserId)
	}
	if in.Title != "" {
		mod = mod.WhereLike("p."+dao.ForumPost.Columns().Title, "%"+in.Title+"%")
	}
	if in.AuditStatus >= 0 && in.AuditStatus <= 2 {
		mod = mod.Where("p."+dao.ForumPost.Columns().AuditStatus, in.AuditStatus)
	}
	if in.IsTop > 0 {
		mod = mod.Where("p."+dao.ForumPost.Columns().IsTop, in.IsTop)
	}
	if in.Status > 0 {
		mod = mod.Where("p."+dao.ForumPost.Columns().Status, in.Status)
	}
	if len(in.CreatedAt) == 2 {
		mod = mod.WhereBetween("p."+dao.ForumPost.Columns().CreatedAt, in.CreatedAt[0], in.CreatedAt[1])
	}

	mod = mod.Page(in.Page, in.PerPage).
		OrderDesc("p."+dao.ForumPost.Columns().IsTop).
		OrderDesc("p."+dao.ForumPost.Columns().Id)

	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取帖子列表失败，请稍后重试！")
		return
	}
	return
}

// View 获取帖子指定信息
func (s *sSysForumPost) View(ctx context.Context, in *sysin.ForumPostViewInp) (res *sysin.ForumPostViewModel, err error) {
	if err = s.Model(ctx).WherePri(in.Id).Scan(&res); err != nil {
		err = gerror.Wrap(err, "获取帖子信息失败，请稍后重试！")
		return
	}
	return
}

// Edit 修改帖子
func (s *sSysForumPost) Edit(ctx context.Context, in *sysin.ForumPostEditInp) (err error) {
	in.UpdatedBy = contexts.GetUserId(ctx)
	if _, err = s.Model(ctx).
		Fields(sysin.ForumPostUpdateFields{}).
		WherePri(in.Id).Data(in).Update(); err != nil {
		err = gerror.Wrap(err, "修改帖子失败，请稍后重试！")
		return
	}
	return
}

// Delete 删除帖子
func (s *sSysForumPost) Delete(ctx context.Context, in *sysin.ForumPostDeleteInp) (err error) {
	post, err := s.Model(ctx).WherePri(in.Id).One()
	if err != nil {
		err = gerror.Wrap(err, "获取帖子失败，请稍后重试！")
		return
	}
	if post.IsEmpty() {
		err = gerror.New("帖子不存在")
		return
	}

	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.ForumPost.Columns().DeletedBy: contexts.GetUserId(ctx),
		dao.ForumPost.Columns().DeletedAt: gtime.Now(),
	}).Unscoped().Update(); err != nil {
		err = gerror.Wrap(err, "删除帖子失败，请稍后重试！")
		return
	}

	// 同步清理该帖子的评论
	if _, err = dao.ForumComment.Ctx(ctx).Where(dao.ForumComment.Columns().PostId, in.Id).Data(g.Map{
		dao.ForumComment.Columns().DeletedBy: contexts.GetUserId(ctx),
		dao.ForumComment.Columns().DeletedAt: gtime.Now(),
	}).Unscoped().Update(); err != nil {
		err = gerror.Wrap(err, "清理帖子评论失败，请稍后重试！")
		return
	}

	_ = service.SysForumBoard().RefreshPostCount(ctx, post[dao.ForumPost.Columns().BoardId].Int64())
	return
}

// Status 更新帖子状态
func (s *sSysForumPost) Status(ctx context.Context, in *sysin.ForumPostStatusInp) (err error) {
	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.ForumPost.Columns().Status:    in.Status,
		dao.ForumPost.Columns().UpdatedBy: contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "更新帖子状态失败，请稍后重试！")
		return
	}
	return
}

// Audit 审核帖子
func (s *sSysForumPost) Audit(ctx context.Context, in *sysin.ForumPostAuditInp) (err error) {
	post, err := s.Model(ctx).WherePri(in.Id).One()
	if err != nil {
		err = gerror.Wrap(err, "获取帖子失败，请稍后重试！")
		return
	}
	if post.IsEmpty() {
		err = gerror.New("帖子不存在")
		return
	}

	data := g.Map{
		dao.ForumPost.Columns().AuditStatus: in.AuditStatus,
		dao.ForumPost.Columns().AuditRemark: in.AuditRemark,
		dao.ForumPost.Columns().AuditBy:     contexts.GetUserId(ctx),
		dao.ForumPost.Columns().AuditAt:     gtime.Now(),
		dao.ForumPost.Columns().UpdatedBy:   contexts.GetUserId(ctx),
	}

	if _, err = s.Model(ctx).WherePri(in.Id).Data(data).Update(); err != nil {
		err = gerror.Wrap(err, "审核帖子失败，请稍后重试！")
		return
	}

	// 审核通过后刷新版块帖子数
	if in.AuditStatus == consts.AuditStatusPass {
		_ = service.SysForumBoard().RefreshPostCount(ctx, post[dao.ForumPost.Columns().BoardId].Int64())
	}
	return
}
