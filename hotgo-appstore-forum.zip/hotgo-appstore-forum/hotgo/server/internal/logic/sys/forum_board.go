// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/library/hgorm/handler"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
)

type sSysForumBoard struct{}

func NewSysForumBoard() *sSysForumBoard {
	return &sSysForumBoard{}
}

func init() {
	service.RegisterSysForumBoard(NewSysForumBoard())
}

// Model 论坛版块ORM模型
func (s *sSysForumBoard) Model(ctx context.Context, option ...*handler.Option) *gdb.Model {
	return handler.Model(dao.ForumBoard.Ctx(ctx), option...)
}

// List 获取论坛版块列表
func (s *sSysForumBoard) List(ctx context.Context, in *sysin.ForumBoardListInp) (list []*sysin.ForumBoardListModel, totalCount int, err error) {
	mod := s.Model(ctx)

	if in.Id > 0 {
		mod = mod.Where(dao.ForumBoard.Columns().Id, in.Id)
	}

	if in.Name != "" {
		mod = mod.WhereLike(dao.ForumBoard.Columns().Name, "%"+in.Name+"%")
	}

	if in.Status > 0 {
		mod = mod.Where(dao.ForumBoard.Columns().Status, in.Status)
	}

	if in.VipOnly >= 0 {
		mod = mod.Where(dao.ForumBoard.Columns().VipOnly, in.VipOnly)
	}

	mod = mod.Page(in.Page, in.PerPage).
		OrderAsc(dao.ForumBoard.Columns().Sort).
		OrderDesc(dao.ForumBoard.Columns().Id)

	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取论坛版块列表失败，请稍后重试！")
		return
	}
	return
}

// View 获取论坛版块指定信息
func (s *sSysForumBoard) View(ctx context.Context, in *sysin.ForumBoardViewInp) (res *sysin.ForumBoardViewModel, err error) {
	if err = s.Model(ctx).WherePri(in.Id).Scan(&res); err != nil {
		err = gerror.Wrap(err, "获取论坛版块信息失败，请稍后重试！")
		return
	}
	return
}

// Edit 修改/新增论坛版块
func (s *sSysForumBoard) Edit(ctx context.Context, in *sysin.ForumBoardEditInp) (err error) {
	return g.DB().Transaction(ctx, func(ctx context.Context, tx gdb.TX) (err error) {
		exist, err := s.Model(ctx).Where(dao.ForumBoard.Columns().Name, in.Name).
			WhereNot(dao.ForumBoard.Columns().Id, in.Id).Count()
		if err != nil {
			err = gerror.Wrap(err, "校验版块名称失败，请稍后重试！")
			return
		}
		if exist > 0 {
			err = gerror.New("版块名称已存在")
			return
		}

		// 修改
		if in.Id > 0 {
			in.UpdatedBy = contexts.GetUserId(ctx)
			if _, err = s.Model(ctx).
				Fields(sysin.ForumBoardUpdateFields{}).
				WherePri(in.Id).Data(in).Update(); err != nil {
				err = gerror.Wrap(err, "修改论坛版块失败，请稍后重试！")
			}
			return
		}

		// 新增
		in.CreatedBy = contexts.GetUserId(ctx)
		if _, err = s.Model(ctx, &handler.Option{FilterAuth: false}).
			Fields(sysin.ForumBoardInsertFields{}).
			Data(in).OmitEmptyData().Insert(); err != nil {
			err = gerror.Wrap(err, "新增论坛版块失败，请稍后重试！")
		}
		return
	})
}

// Delete 删除论坛版块
func (s *sSysForumBoard) Delete(ctx context.Context, in *sysin.ForumBoardDeleteInp) (err error) {
	count, err := dao.ForumPost.Ctx(ctx).Where(dao.ForumPost.Columns().BoardId, in.Id).Count()
	if err != nil {
		err = gerror.Wrap(err, "校验论坛版块失败，请稍后重试！")
		return
	}
	if count > 0 {
		err = gerror.New("该版块下存在帖子，请先移除或转移后再删除")
		return
	}

	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.ForumBoard.Columns().DeletedBy: contexts.GetUserId(ctx),
		dao.ForumBoard.Columns().DeletedAt: gtime.Now(),
	}).Unscoped().Update(); err != nil {
		err = gerror.Wrap(err, "删除论坛版块失败，请稍后重试！")
		return
	}
	return
}

// Status 更新论坛版块状态
func (s *sSysForumBoard) Status(ctx context.Context, in *sysin.ForumBoardStatusInp) (err error) {
	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.ForumBoard.Columns().Status:    in.Status,
		dao.ForumBoard.Columns().UpdatedBy: contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "更新论坛版块状态失败，请稍后重试！")
		return
	}
	return
}

// RefreshPostCount 刷新版块帖子数
func (s *sSysForumBoard) RefreshPostCount(ctx context.Context, boardId int64) (err error) {
	if boardId <= 0 {
		return
	}

	count, err := dao.ForumPost.Ctx(ctx).
		Where(dao.ForumPost.Columns().BoardId, boardId).
		Where(dao.ForumPost.Columns().AuditStatus, 1).Count()
	if err != nil {
		return
	}

	_, err = s.Model(ctx).WherePri(boardId).Data(g.Map{
		dao.ForumBoard.Columns().PostCount: count,
	}).Update()
	return
}
