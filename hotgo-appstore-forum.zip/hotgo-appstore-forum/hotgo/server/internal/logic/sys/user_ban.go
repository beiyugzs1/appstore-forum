// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"

	"hotgo/internal/consts"
	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/library/hgorm/handler"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
)

type sSysUserBan struct{}

func NewSysUserBan() *sSysUserBan {
	return &sSysUserBan{}
}

func init() {
	service.RegisterSysUserBan(NewSysUserBan())
}

// Model 用户封禁ORM模型
func (s *sSysUserBan) Model(ctx context.Context, option ...*handler.Option) *gdb.Model {
	return handler.Model(dao.UserBan.Ctx(ctx), option...)
}

// List 获取封禁记录列表
func (s *sSysUserBan) List(ctx context.Context, in *sysin.UserBanListInp) (list []*sysin.UserBanListModel, totalCount int, err error) {
	columns := dao.UserBan.Columns()
	mod := s.Model(ctx)

	if in.Id > 0 {
		mod = mod.Where(columns.Id, in.Id)
	}
	if in.UserId > 0 {
		mod = mod.Where(columns.UserId, in.UserId)
	}
	if in.Type > 0 {
		mod = mod.Where(columns.Type, in.Type)
	}
	if in.Scope > 0 {
		mod = mod.Where(columns.Scope, in.Scope)
	}
	if in.Status > 0 {
		mod = mod.Where(columns.Status, in.Status)
	}
	if in.OnlyActive {
		mod = mod.Where(columns.Status, consts.BanStatusActive)
	}
	if in.Keyword != "" {
		var users []*struct {
			Id int64 `json:"id"`
		}
		if err = dao.User.Ctx(ctx).Fields(dao.User.Columns().Id).
			WhereLike(dao.User.Columns().Username, "%"+in.Keyword+"%").
			WhereOrLike(dao.User.Columns().Nickname, "%"+in.Keyword+"%").
			Limit(200).Scan(&users); err != nil {
			err = gerror.Wrap(err, "检索用户失败，请稍后重试！")
			return
		}
		if len(users) == 0 {
			return []*sysin.UserBanListModel{}, 0, nil
		}
		userIds := make([]int64, 0, len(users))
		for _, u := range users {
			userIds = append(userIds, u.Id)
		}
		mod = mod.WhereIn(columns.UserId, userIds)
	}

	mod = mod.Page(in.Page, in.PerPage).OrderDesc(columns.Id)
	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取封禁记录列表失败，请稍后重试！")
		return
	}

	if err = s.fillNames(ctx, list); err != nil {
		return
	}
	return
}

// View 获取封禁记录详情
func (s *sSysUserBan) View(ctx context.Context, in *sysin.UserBanViewInp) (res *sysin.UserBanListModel, err error) {
	if err = s.Model(ctx).WherePri(in.Id).Scan(&res); err != nil {
		err = gerror.Wrap(err, "获取封禁记录失败，请稍后重试！")
		return
	}
	if res == nil {
		err = gerror.New("封禁记录不存在")
		return
	}

	if err = s.fillNames(ctx, []*sysin.UserBanListModel{res}); err != nil {
		return
	}
	return
}

// Edit 新增封禁/禁言（后台管理员操作）
func (s *sSysUserBan) Edit(ctx context.Context, in *sysin.UserBanEditInp) (err error) {
	if err = s.checkUserAndBoard(ctx, in.UserId, in.Scope, in.BoardId); err != nil {
		return
	}

	operatorId := contexts.GetUserId(ctx)
	boardId := int64(0)
	if in.Scope == consts.BanScopeBoard {
		boardId = in.BoardId
	}

	// 避免同类型同范围重复生效
	columns := dao.UserBan.Columns()
	exist, err := dao.UserBan.Ctx(ctx).
		Where(columns.UserId, in.UserId).
		Where(columns.Type, in.Type).
		Where(columns.Scope, in.Scope).
		Where(columns.BoardId, boardId).
		Where(columns.Status, consts.BanStatusActive).
		Count()
	if err != nil {
		err = gerror.Wrap(err, "校验封禁记录失败，请稍后重试！")
		return
	}
	if exist > 0 {
		err = gerror.New("该用户已存在生效中的同类记录，请先解除后再操作")
		return
	}

	if _, err = s.Model(ctx, &handler.Option{FilterAuth: false}).Fields(sysin.UserBanInsertFields{}).
		Data(g.Map{
			columns.UserId:       in.UserId,
			columns.Type:         in.Type,
			columns.Scope:        in.Scope,
			columns.BoardId:      boardId,
			columns.Reason:       in.Reason,
			columns.StartAt:      gtime.Now(),
			columns.ExpireAt:     in.ExpireAt,
			columns.OperatorId:   operatorId,
			columns.OperatorType: consts.BanOperatorAdmin,
			columns.Remark:       in.Remark,
			columns.Status:       consts.BanStatusActive,
			columns.CreatedBy:    operatorId,
		}).OmitEmptyData().Insert(); err != nil {
		err = gerror.Wrap(err, "封禁失败，请稍后重试！")
	}
	return
}

// BanByModerator 版主封禁本版用户
func (s *sSysUserBan) BanByModerator(ctx context.Context, in *sysin.UserBanModeratorBanInp) (err error) {
	if err = s.checkUserAndBoard(ctx, in.UserId, consts.BanScopeBoard, in.BoardId); err != nil {
		return
	}

	var expireAt *gtime.Time
	if in.ExpireAt != "" {
		expireAt = gtime.NewFromStr(in.ExpireAt)
		if expireAt == nil {
			err = gerror.New("到期时间格式不正确，应为 2006-01-02 15:04:05")
			return
		}
		if expireAt.Before(gtime.Now()) {
			err = gerror.New("到期时间必须晚于当前时间")
			return
		}
	}

	columns := dao.UserBan.Columns()
	exist, err := dao.UserBan.Ctx(ctx).
		Where(columns.UserId, in.UserId).
		Where(columns.Scope, consts.BanScopeBoard).
		Where(columns.BoardId, in.BoardId).
		Where(columns.Status, consts.BanStatusActive).
		Count()
	if err != nil {
		err = gerror.Wrap(err, "校验封禁记录失败，请稍后重试！")
		return
	}
	if exist > 0 {
		err = gerror.New("该用户在当前版块已有生效中的处罚记录")
		return
	}

	if _, err = s.Model(ctx, &handler.Option{FilterAuth: false}).Fields(sysin.UserBanInsertFields{}).
		Data(g.Map{
			columns.UserId:       in.UserId,
			columns.Type:         in.Type,
			columns.Scope:        consts.BanScopeBoard,
			columns.BoardId:      in.BoardId,
			columns.Reason:       in.Reason,
			columns.StartAt:      gtime.Now(),
			columns.ExpireAt:     expireAt,
			columns.OperatorId:   in.OperatorId,
			columns.OperatorType: consts.BanOperatorModerator,
			columns.Status:       consts.BanStatusActive,
			columns.CreatedBy:    in.OperatorId,
		}).OmitEmptyData().Insert(); err != nil {
		err = gerror.Wrap(err, "操作失败，请稍后重试！")
	}
	return
}

// Relieve 解除封禁
func (s *sSysUserBan) Relieve(ctx context.Context, in *sysin.UserBanRelieveInp) (err error) {
	columns := dao.UserBan.Columns()
	operatorId := contexts.GetUserId(ctx)

	result, err := s.Model(ctx).WhereIn(columns.Id, in.Ids).Data(g.Map{
		columns.Status:    consts.BanStatusRelieved,
		columns.RelieveAt: gtime.Now(),
		columns.RelieveBy: operatorId,
		columns.UpdatedBy: operatorId,
	}).Update()
	if err != nil {
		err = gerror.Wrap(err, "解除封禁失败，请稍后重试！")
		return
	}

	if affected, _ := result.RowsAffected(); affected == 0 {
		err = gerror.New("没有可解除的生效记录")
		return
	}
	return
}

// Delete 删除封禁记录
func (s *sSysUserBan) Delete(ctx context.Context, in *sysin.UserBanDeleteInp) (err error) {
	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.UserBan.Columns().DeletedBy: contexts.GetUserId(ctx),
		dao.UserBan.Columns().DeletedAt: gtime.Now(),
	}).Unscoped().Update(); err != nil {
		err = gerror.Wrap(err, "删除失败，请稍后重试！")
	}
	return
}

// Check 运行时校验用户是否被限制（含到期惰性判断，不依赖定时任务）
// action 取值见 consts.BanAction*；boardId 仅在版块相关动作时传入。
func (s *sSysUserBan) Check(ctx context.Context, userId, boardId int64, action string) (banned bool, msg string, err error) {
	if userId <= 0 {
		return
	}

	columns := dao.UserBan.Columns()
	now := gtime.Now()

	mod := dao.UserBan.Ctx(ctx).
		Where(columns.UserId, userId).
		Where(columns.Status, consts.BanStatusActive).
		Where("("+columns.StartAt+" IS NULL OR "+columns.StartAt+" <= ?)", now).
		Where("("+columns.ExpireAt+" IS NULL OR "+columns.ExpireAt+" > ?)", now)

	switch {
	case action == consts.BanActionLogin:
		// 登录仅受「全局封禁」影响；全局禁言允许登录
		mod = mod.Where(columns.Type, consts.BanTypeBan).Where(columns.Scope, consts.BanScopeGlobal)
	case boardId > 0:
		// 发言类动作：全局处罚 或 本版处罚 均生效
		mod = mod.Where("(("+columns.Scope+" = ?) OR ("+columns.Scope+" = ? AND "+columns.BoardId+" = ?))",
			consts.BanScopeGlobal, consts.BanScopeBoard, boardId)
	default:
		mod = mod.Where(columns.Scope, consts.BanScopeGlobal)
	}

	var row *struct {
		Type     int         `json:"type"`
		Scope    int         `json:"scope"`
		Reason   string      `json:"reason"`
		ExpireAt *gtime.Time `json:"expireAt"`
	}
	if err = mod.Fields(columns.Type, columns.Scope, columns.Reason, columns.ExpireAt).
		OrderDesc(columns.Type).Limit(1).Scan(&row); err != nil {
		err = gerror.Wrap(err, "校验封禁状态失败，请稍后重试！")
		return
	}
	if row == nil {
		return
	}

	banned = true
	suffix := ""
	if row.ExpireAt != nil {
		suffix = "，解封时间：" + row.ExpireAt.String()
	}
	if row.Type == consts.BanTypeBan {
		msg = "你的账号已被封禁：" + row.Reason + suffix
	} else {
		msg = "你已被禁言：" + row.Reason + suffix
	}
	return
}

// GetActiveByUser 获取用户当前生效中的处罚（供 C 端展示）
func (s *sSysUserBan) GetActiveByUser(ctx context.Context, userId int64) (res *sysin.UserBanStatusModel, err error) {
	res = &sysin.UserBanStatusModel{BoardBans: []*sysin.UserBanStatusItemModel{}}
	if userId <= 0 {
		return
	}

	columns := dao.UserBan.Columns()
	now := gtime.Now()

	var rows []*sysin.UserBanListModel
	if err = dao.UserBan.Ctx(ctx).
		Fields(columns.BoardId, columns.Type, columns.Scope, columns.Reason, columns.ExpireAt).
		Where(columns.UserId, userId).
		Where(columns.Status, consts.BanStatusActive).
		Where("("+columns.StartAt+" IS NULL OR "+columns.StartAt+" <= ?)", now).
		Where("("+columns.ExpireAt+" IS NULL OR "+columns.ExpireAt+" > ?)", now).
		Scan(&rows); err != nil {
		err = gerror.Wrap(err, "获取封禁状态失败，请稍后重试！")
		return
	}

	for _, row := range rows {
		item := &sysin.UserBanStatusItemModel{
			BoardId:  row.BoardId,
			Type:     row.Type,
			Reason:   row.Reason,
			ExpireAt: row.ExpireAt,
		}
		if row.Scope == consts.BanScopeGlobal {
			res.GlobalBan = item
			if row.Type == consts.BanTypeBan {
				res.Banned = true
			} else {
				res.Muted = true
			}
			continue
		}
		res.BoardBans = append(res.BoardBans, item)
	}
	return
}

// SweepExpired 扫描并解除已到期的封禁记录（定时任务调用）
func (s *sSysUserBan) SweepExpired(ctx context.Context) (count int64, err error) {
	columns := dao.UserBan.Columns()
	result, err := dao.UserBan.Ctx(ctx).
		Where(columns.Status, consts.BanStatusActive).
		WhereNotNull(columns.ExpireAt).
		WhereLT(columns.ExpireAt, gtime.Now()).
		Data(g.Map{
			columns.Status:    consts.BanStatusRelieved,
			columns.RelieveAt: gtime.Now(),
			columns.UpdatedBy: 0,
		}).Update()
	if err != nil {
		err = gerror.Wrap(err, "清理到期封禁记录失败")
		return
	}
	count, _ = result.RowsAffected()
	return
}

// fillNames 填充用户、版块、操作人名称
func (s *sSysUserBan) fillNames(ctx context.Context, list []*sysin.UserBanListModel) (err error) {
	if len(list) == 0 {
		return
	}

	var userIds, boardIds, operatorIds []int64
	for _, row := range list {
		userIds = append(userIds, row.UserId)
		if row.BoardId > 0 {
			boardIds = append(boardIds, row.BoardId)
		}
		if row.OperatorId > 0 {
			operatorIds = append(operatorIds, row.OperatorId)
		}
		row.IsExpired = row.ExpireAt != nil && row.ExpireAt.Before(gtime.Now())
	}

	accounts := map[int64]string{}
	nicknames := map[int64]string{}
	if len(userIds) > 0 {
		var rows []*struct {
			Id       int64  `json:"id"`
			Username string `json:"username"`
			Nickname string `json:"nickname"`
		}
		if err = dao.User.Ctx(ctx).
			Fields(dao.User.Columns().Id, dao.User.Columns().Username, dao.User.Columns().Nickname).
			WhereIn(dao.User.Columns().Id, userIds).Scan(&rows); err != nil {
			err = gerror.Wrap(err, "获取用户信息失败，请稍后重试！")
			return
		}
		for _, row := range rows {
			accounts[row.Id] = row.Username
			nicknames[row.Id] = row.Nickname
		}
	}

	boardNames := map[int64]string{}
	if len(boardIds) > 0 {
		var rows []*struct {
			Id   int64  `json:"id"`
			Name string `json:"name"`
		}
		if err = dao.ForumBoard.Ctx(ctx).
			Fields(dao.ForumBoard.Columns().Id, dao.ForumBoard.Columns().Name).
			WhereIn(dao.ForumBoard.Columns().Id, boardIds).Scan(&rows); err != nil {
			err = gerror.Wrap(err, "获取版块信息失败，请稍后重试！")
			return
		}
		for _, row := range rows {
			boardNames[row.Id] = row.Name
		}
	}

	adminNames := map[int64]string{}
	if len(operatorIds) > 0 {
		var rows []*struct {
			Id       int64  `json:"id"`
			Username string `json:"username"`
			RealName string `json:"realName"`
		}
		if err = dao.AdminMember.Ctx(ctx).
			Fields(dao.AdminMember.Columns().Id, dao.AdminMember.Columns().Username, dao.AdminMember.Columns().RealName).
			WhereIn(dao.AdminMember.Columns().Id, operatorIds).Scan(&rows); err != nil {
			err = gerror.Wrap(err, "获取操作人信息失败，请稍后重试！")
			return
		}
		for _, row := range rows {
			name := row.RealName
			if name == "" {
				name = row.Username
			}
			adminNames[row.Id] = name
		}
	}

	for _, row := range list {
		row.UserAccount = accounts[row.UserId]
		row.UserNickname = nicknames[row.UserId]
		row.BoardName = boardNames[row.BoardId]
		if row.OperatorType == consts.BanOperatorModerator {
			row.OperatorName = "版主"
		} else {
			row.OperatorName = adminNames[row.OperatorId]
		}
	}
	return
}

// checkUserAndBoard 校验用户与版块有效性
func (s *sSysUserBan) checkUserAndBoard(ctx context.Context, userId int64, scope int, boardId int64) (err error) {
	userCount, err := dao.User.Ctx(ctx).WherePri(userId).Count()
	if err != nil {
		err = gerror.Wrap(err, "校验用户失败，请稍后重试！")
		return
	}
	if userCount == 0 {
		err = gerror.New("用户不存在")
		return
	}

	if scope == consts.BanScopeBoard {
		if boardId <= 0 {
			err = gerror.New("请选择版块")
			return
		}
		var boardCount int
		boardCount, err = dao.ForumBoard.Ctx(ctx).WherePri(boardId).Count()
		if err != nil {
			err = gerror.Wrap(err, "校验版块失败，请稍后重试！")
			return
		}
		if boardCount == 0 {
			err = gerror.New("版块不存在")
		}
	}
	return
}
