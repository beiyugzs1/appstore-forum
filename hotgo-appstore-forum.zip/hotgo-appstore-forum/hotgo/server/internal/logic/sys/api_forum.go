// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"strings"

	"hotgo/internal/consts"
	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/encoding/gjson"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
	"github.com/gogf/gf/v2/text/gstr"
)

type sSysApiForum struct{}

func NewSysApiForum() *sSysApiForum {
	return &sSysApiForum{}
}

func init() {
	service.RegisterSysApiForum(NewSysApiForum())
}

// apiPostRow 帖子查询行（含关联信息）
type apiPostRow struct {
	Id           int64       `json:"id"`
	BoardId      int64       `json:"boardId"`
	BoardName    string      `json:"boardName"`
	UserId       int64       `json:"userId"`
	UserNickname string      `json:"userNickname"`
	UserAvatar   string      `json:"userAvatar"`
	Title        string      `json:"title"`
	Content      string      `json:"content"`
	Images       *gjson.Json `json:"images"`
	ViewCount    int         `json:"viewCount"`
	LikeCount    int         `json:"likeCount"`
	CommentCount int         `json:"commentCount"`
	IsTop        int         `json:"isTop"`
	IsEssence    int         `json:"isEssence"`
	CreatedAt    *gtime.Time `json:"createdAt"`
}

// BoardList 获取论坛版块列表
func (s *sSysApiForum) BoardList(ctx context.Context) (res *apiin.ApiForumBoardListModel, err error) {
	res = &apiin.ApiForumBoardListModel{List: make([]*apiin.ApiForumBoardModel, 0)}

	if err = dao.ForumBoard.Ctx(ctx).
		Where(dao.ForumBoard.Columns().Status, consts.StatusEnabled).
		Fields(
			dao.ForumBoard.Columns().Id,
			dao.ForumBoard.Columns().Name,
			dao.ForumBoard.Columns().Icon,
			dao.ForumBoard.Columns().Description,
			dao.ForumBoard.Columns().PostCount,
			dao.ForumBoard.Columns().VipOnly,
		).
		OrderAsc(dao.ForumBoard.Columns().Sort).
		OrderAsc(dao.ForumBoard.Columns().Id).
		Scan(&res.List); err != nil {
		err = gerror.Wrap(err, "获取版块列表失败，请稍后重试！")
		return
	}
	if res.List == nil {
		res.List = make([]*apiin.ApiForumBoardModel, 0)
	}

	// 标记可访问性：非会员访问会员专享版块时 accessible=false，App 据此展示会员引导
	isVip, _, _ := currentUserIsVip(ctx)
	for _, board := range res.List {
		board.Accessible = board.VipOnly == 0 || isVip
	}
	return
}

// PostList 获取帖子列表（仅审核通过）
func (s *sSysApiForum) PostList(ctx context.Context, in *apiin.ApiForumPostListInp) (list []*apiin.ApiForumPostModel, totalCount int, err error) {
	mod := dao.ForumPost.Ctx(ctx).As("p").
		LeftJoin(dao.ForumBoard.Table(), dao.ForumBoard.Table()+"."+dao.ForumBoard.Columns().Id+" = p."+dao.ForumPost.Columns().BoardId).
		LeftJoin(dao.User.Table(), dao.User.Table()+"."+dao.User.Columns().Id+" = p."+dao.ForumPost.Columns().UserId).
		Fields("p." + dao.ForumPost.Columns().Id + " as id, " +
			"p." + dao.ForumPost.Columns().BoardId + " as boardId, " +
			"p." + dao.ForumPost.Columns().UserId + " as userId, " +
			"p." + dao.ForumPost.Columns().Title + " as title, " +
			"p." + dao.ForumPost.Columns().Content + " as content, " +
			"p." + dao.ForumPost.Columns().Images + " as images, " +
			"p." + dao.ForumPost.Columns().ViewCount + " as viewCount, " +
			"p." + dao.ForumPost.Columns().LikeCount + " as likeCount, " +
			"p." + dao.ForumPost.Columns().CommentCount + " as commentCount, " +
			"p." + dao.ForumPost.Columns().IsTop + " as isTop, " +
			"p." + dao.ForumPost.Columns().IsEssence + " as isEssence, " +
			"p." + dao.ForumPost.Columns().CreatedAt + " as createdAt, " +
			dao.ForumBoard.Table() + "." + dao.ForumBoard.Columns().Name + " as boardName, " +
			dao.User.Table() + "." + dao.User.Columns().Nickname + " as userNickname, " +
			dao.User.Table() + "." + dao.User.Columns().Avatar + " as userAvatar").
		Where("p."+dao.ForumPost.Columns().AuditStatus, consts.AuditStatusPass).
		Where("p."+dao.ForumPost.Columns().Status, consts.StatusEnabled)

	if in.BoardId > 0 {
		// 指定版块：校验会员专享访问权
		if err = s.checkBoardAccess(ctx, in.BoardId); err != nil {
			return
		}
		mod = mod.Where("p."+dao.ForumPost.Columns().BoardId, in.BoardId)
	} else {
		// 未指定版块：非会员不可见会员专享版块的帖子
		isVip, _, _ := currentUserIsVip(ctx)
		if !isVip {
			var vipBoardIds []int64
			_ = dao.ForumBoard.Ctx(ctx).Fields(dao.ForumBoard.Columns().Id).
				Where(dao.ForumBoard.Columns().VipOnly, 1).Scan(&vipBoardIds)
			if len(vipBoardIds) > 0 {
				mod = mod.WhereNotIn("p."+dao.ForumPost.Columns().BoardId, vipBoardIds)
			}
		}
	}
	if in.UserId > 0 {
		mod = mod.Where("p."+dao.ForumPost.Columns().UserId, in.UserId)
	}
	if in.Keyword != "" {
		mod = mod.WhereLike("p."+dao.ForumPost.Columns().Title, "%"+in.Keyword+"%")
	}

	mod = mod.Page(in.Page, in.PerPage).
		OrderDesc("p."+dao.ForumPost.Columns().IsTop).
		OrderDesc("p."+dao.ForumPost.Columns().Id)

	var rows []*apiPostRow
	if err = mod.ScanAndCount(&rows, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取帖子列表失败，请稍后重试！")
		return
	}

	list = make([]*apiin.ApiForumPostModel, 0, len(rows))
	for _, row := range rows {
		images := jsonToStrings(row.Images)
		cover := ""
		if len(images) > 0 {
			cover = images[0]
		}
		list = append(list, &apiin.ApiForumPostModel{
			Id:           row.Id,
			BoardId:      row.BoardId,
			BoardName:    row.BoardName,
			UserId:       row.UserId,
			UserNickname: row.UserNickname,
			UserAvatar:   row.UserAvatar,
			Title:        row.Title,
			Summary:      gstr.SubStr(gstr.Trim(row.Content), 0, 100),
			Cover:        cover,
			ViewCount:    row.ViewCount,
			LikeCount:    row.LikeCount,
			CommentCount: row.CommentCount,
			IsTop:        row.IsTop,
			IsEssence:    row.IsEssence,
			CreatedAt:    row.CreatedAt,
		})
	}
	return
}

// PostDetail 获取帖子详情
func (s *sSysApiForum) PostDetail(ctx context.Context, in *apiin.ApiForumPostDetailInp) (res *apiin.ApiForumPostDetailModel, err error) {
	var row *apiPostRow
	if err = dao.ForumPost.Ctx(ctx).As("p").
		LeftJoin(dao.ForumBoard.Table(), dao.ForumBoard.Table()+"."+dao.ForumBoard.Columns().Id+" = p."+dao.ForumPost.Columns().BoardId).
		LeftJoin(dao.User.Table(), dao.User.Table()+"."+dao.User.Columns().Id+" = p."+dao.ForumPost.Columns().UserId).
		Fields("p.*, " + dao.ForumBoard.Table() + "." + dao.ForumBoard.Columns().Name + " as boardName, " +
			dao.User.Table() + "." + dao.User.Columns().Nickname + " as userNickname, " +
			dao.User.Table() + "." + dao.User.Columns().Avatar + " as userAvatar").
		Where("p."+dao.ForumPost.Columns().Id, in.Id).
		Where("p."+dao.ForumPost.Columns().AuditStatus, consts.AuditStatusPass).
		Where("p."+dao.ForumPost.Columns().Status, consts.StatusEnabled).
		Scan(&row); err != nil {
		err = gerror.Wrap(err, "获取帖子详情失败，请稍后重试！")
		return
	}
	if row == nil {
		err = gerror.New("帖子不存在或未通过审核")
		return
	}

	// 会员专享版块校验
	if err = s.checkBoardAccess(ctx, row.BoardId); err != nil {
		return
	}

	if _, err = dao.ForumPost.Ctx(ctx).WherePri(in.Id).
		Increment(dao.ForumPost.Columns().ViewCount, 1); err != nil {
		err = nil
	}

	res = &apiin.ApiForumPostDetailModel{
		Id:           row.Id,
		BoardId:      row.BoardId,
		BoardName:    row.BoardName,
		UserId:       row.UserId,
		UserNickname: row.UserNickname,
		UserAvatar:   row.UserAvatar,
		Title:        row.Title,
		Content:      row.Content,
		Images:       jsonToStrings(row.Images),
		ViewCount:    row.ViewCount,
		LikeCount:    row.LikeCount,
		CommentCount: row.CommentCount,
		IsTop:        row.IsTop,
		IsEssence:    row.IsEssence,
		CreatedAt:    row.CreatedAt,
	}
	return
}

// PublishPost 发布帖子（待审核）
func (s *sSysApiForum) PublishPost(ctx context.Context, in *apiin.ApiForumPublishPostInp) (res *apiin.ApiForumPublishPostModel, err error) {
	userId := contexts.GetUserId(ctx)
	if userId <= 0 {
		err = gerror.New("登录身份已失效，请重新登录")
		return
	}

	boardCount, err := dao.ForumBoard.Ctx(ctx).WherePri(in.BoardId).
		Where(dao.ForumBoard.Columns().Status, consts.StatusEnabled).Count()
	if err != nil {
		err = gerror.Wrap(err, "校验版块失败，请稍后重试！")
		return
	}
	if boardCount == 0 {
		err = gerror.New("版块不存在或已禁用")
		return
	}

	// 会员专享版块校验
	if err = s.checkBoardAccess(ctx, in.BoardId); err != nil {
		return
	}

	// 封禁/禁言校验
	if banned, msg, banErr := service.SysUserBan().Check(ctx, userId, in.BoardId, consts.BanActionPost); banErr != nil {
		err = banErr
		return
	} else if banned {
		err = gerror.New(msg)
		return
	}

	// 敏感词过滤
	if in.Title, in.Content, err = s.filterContent(ctx, in.Title, in.Content); err != nil {
		return
	}

	id, err := dao.ForumPost.Ctx(ctx).Data(g.Map{
		dao.ForumPost.Columns().BoardId:     in.BoardId,
		dao.ForumPost.Columns().UserId:      userId,
		dao.ForumPost.Columns().Title:       in.Title,
		dao.ForumPost.Columns().Content:     in.Content,
		dao.ForumPost.Columns().Images:      gjson.MustEncodeString(in.Images),
		dao.ForumPost.Columns().AuditStatus: consts.AuditStatusPending,
		dao.ForumPost.Columns().Status:      consts.StatusEnabled,
	}).InsertAndGetId()
	if err != nil {
		err = gerror.Wrap(err, "发布帖子失败，请稍后重试！")
		return
	}

	res = &apiin.ApiForumPublishPostModel{Id: id}
	return
}

// CommentList 获取帖子评论列表（仅审核通过）
func (s *sSysApiForum) CommentList(ctx context.Context, in *apiin.ApiForumCommentListInp) (list []*apiin.ApiForumCommentModel, totalCount int, err error) {
	// 会员专享版块校验（按帖子反查所属版块）
	var post *struct {
		BoardId int64 `json:"boardId"`
	}
	if err = dao.ForumPost.Ctx(ctx).
		Fields(dao.ForumPost.Columns().BoardId).
		WherePri(in.PostId).Scan(&post); err != nil {
		err = gerror.Wrap(err, "校验帖子失败，请稍后重试！")
		return
	}
	if post == nil {
		err = gerror.New("帖子不存在")
		return
	}
	if err = s.checkBoardAccess(ctx, post.BoardId); err != nil {
		return
	}

	mod := dao.ForumComment.Ctx(ctx).As("c").
		LeftJoin(dao.User.Table(), dao.User.Table()+"."+dao.User.Columns().Id+" = c."+dao.ForumComment.Columns().UserId).
		Fields("c." + dao.ForumComment.Columns().Id + " as id, " +
			"c." + dao.ForumComment.Columns().PostId + " as postId, " +
			"c." + dao.ForumComment.Columns().Pid + " as pid, " +
			"c." + dao.ForumComment.Columns().UserId + " as userId, " +
			"c." + dao.ForumComment.Columns().Content + " as content, " +
			"c." + dao.ForumComment.Columns().LikeCount + " as likeCount, " +
			"c." + dao.ForumComment.Columns().CreatedAt + " as createdAt, " +
			dao.User.Table() + "." + dao.User.Columns().Nickname + " as userNickname, " +
			dao.User.Table() + "." + dao.User.Columns().Avatar + " as userAvatar").
		Where("c."+dao.ForumComment.Columns().PostId, in.PostId).
		Where("c."+dao.ForumComment.Columns().AuditStatus, consts.AuditStatusPass).
		Where("c."+dao.ForumComment.Columns().Status, consts.StatusEnabled).
		Page(in.Page, in.PerPage).
		OrderAsc("c."+dao.ForumComment.Columns().Id)

	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取评论列表失败，请稍后重试！")
		return
	}
	return
}

// PublishComment 发表评论（待审核）
func (s *sSysApiForum) PublishComment(ctx context.Context, in *apiin.ApiForumPublishCommentInp) (res *apiin.ApiForumPublishCommentModel, err error) {
	userId := contexts.GetUserId(ctx)
	if userId <= 0 {
		err = gerror.New("登录身份已失效，请重新登录")
		return
	}

	// 帖子必须存在且已通过审核
	post, err := dao.ForumPost.Ctx(ctx).
		Fields(dao.ForumPost.Columns().BoardId).
		WherePri(in.PostId).
		Where(dao.ForumPost.Columns().AuditStatus, consts.AuditStatusPass).
		Where(dao.ForumPost.Columns().Status, consts.StatusEnabled).One()
	if err != nil {
		err = gerror.Wrap(err, "校验帖子失败，请稍后重试！")
		return
	}
	if post.IsEmpty() {
		err = gerror.New("帖子不存在或未通过审核")
		return
	}

	// 会员专享版块校验
	if err = s.checkBoardAccess(ctx, post[dao.ForumPost.Columns().BoardId].Int64()); err != nil {
		return
	}

	// 封禁/禁言校验
	if banned, msg, banErr := service.SysUserBan().Check(ctx, userId, post[dao.ForumPost.Columns().BoardId].Int64(), consts.BanActionComment); banErr != nil {
		err = banErr
		return
	} else if banned {
		err = gerror.New(msg)
		return
	}

	// 敏感词过滤
	if _, in.Content, err = s.filterContent(ctx, "", in.Content); err != nil {
		return
	}

	// 父评论校验
	if in.Pid > 0 {
		var parent gdb.Record
		parent, err = dao.ForumComment.Ctx(ctx).WherePri(in.Pid).One()
		if err != nil {
			err = gerror.Wrap(err, "校验父评论失败，请稍后重试！")
			return
		}
		if len(parent) == 0 || parent[dao.ForumComment.Columns().PostId].Int64() != in.PostId {
			err = gerror.New("父评论不存在")
			return
		}
	}

	id, err := dao.ForumComment.Ctx(ctx).Data(g.Map{
		dao.ForumComment.Columns().PostId:      in.PostId,
		dao.ForumComment.Columns().UserId:      userId,
		dao.ForumComment.Columns().Pid:         in.Pid,
		dao.ForumComment.Columns().Content:     in.Content,
		dao.ForumComment.Columns().AuditStatus: consts.AuditStatusPending,
		dao.ForumComment.Columns().Status:      consts.StatusEnabled,
	}).InsertAndGetId()
	if err != nil {
		err = gerror.Wrap(err, "发表评论失败，请稍后重试！")
		return
	}

	res = &apiin.ApiForumPublishCommentModel{Id: id}
	return
}

// checkBoardAccess 校验当前用户是否有权访问指定版块（会员专享版块需为会员）
func (s *sSysApiForum) checkBoardAccess(ctx context.Context, boardId int64) (err error) {
	if boardId <= 0 {
		return
	}

	var board *struct {
		Name    string `json:"name"`
		VipOnly int    `json:"vipOnly"`
	}
	if err = dao.ForumBoard.Ctx(ctx).
		Fields(dao.ForumBoard.Columns().Name, dao.ForumBoard.Columns().VipOnly).
		WherePri(boardId).Scan(&board); err != nil {
		err = gerror.Wrap(err, "校验版块失败，请稍后重试！")
		return
	}
	if board == nil {
		err = gerror.New("版块不存在")
		return
	}
	if board.VipOnly != 1 {
		return
	}

	isVip, _, isVipErr := currentUserIsVip(ctx)
	if isVipErr != nil {
		err = isVipErr
		return
	}
	if !isVip {
		err = gerror.Newf("「%s」为会员专享版块，开通会员后即可访问", board.Name)
	}
	return
}

// filterContent 对标题与正文执行敏感词过滤
//
// 策略说明：
//   - 替换：直接把命中词替换为等长掩码后落库；
//   - 拦截：命中后直接拒绝发布；
//   - 转待审：内容进入待审核队列（发帖/评论默认即为待审核状态）。
func (s *sSysApiForum) filterContent(ctx context.Context, title, content string) (newTitle, newContent string, err error) {
	newTitle, newContent = title, content

	if content != "" {
		filtered, strategy, hits, fErr := service.SysSensitiveWord().Filter(ctx, content)
		if fErr != nil {
			err = fErr
			return
		}
		newContent = filtered
		if len(hits) > 0 && strategy == consts.SensitiveStrategyBlock {
			err = gerror.Newf("内容包含违规信息（%s），已被禁止发布", strings.Join(hits, "、"))
			return
		}
	}

	if title != "" {
		filtered, strategy, hits, fErr := service.SysSensitiveWord().Filter(ctx, title)
		if fErr != nil {
			err = fErr
			return
		}
		newTitle = filtered
		if len(hits) > 0 && strategy == consts.SensitiveStrategyBlock {
			err = gerror.Newf("标题包含违规信息（%s），已被禁止发布", strings.Join(hits, "、"))
			return
		}
	}
	return
}
