// Package sys
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sys

import (
	"context"
	"hotgo/internal/dao"
	"hotgo/internal/library/contexts"
	"hotgo/internal/library/hgorm/handler"
	"hotgo/internal/model/input/sysin"
	"hotgo/internal/service"

	"github.com/gogf/gf/v2/crypto/gmd5"
	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
	"github.com/gogf/gf/v2/util/grand"
)

type sSysUser struct{}

func NewSysUser() *sSysUser {
	return &sSysUser{}
}

func init() {
	service.RegisterSysUser(NewSysUser())
}

// Model 用户ORM模型
func (s *sSysUser) Model(ctx context.Context, option ...*handler.Option) *gdb.Model {
	return handler.Model(dao.User.Ctx(ctx), option...)
}

// List 获取用户列表
func (s *sSysUser) List(ctx context.Context, in *sysin.UserListInp) (list []*sysin.UserListModel, totalCount int, err error) {
	mod := s.Model(ctx).As("u").
		LeftJoin(dao.VipPlan.Table(), dao.VipPlan.Table()+"."+dao.VipPlan.Columns().Id+" = u."+dao.User.Columns().VipPlanId).
		Fields("u.*, " + dao.VipPlan.Table() + "." + dao.VipPlan.Columns().Name + " as vipPlanName")

	if in.Id > 0 {
		mod = mod.Where("u."+dao.User.Columns().Id, in.Id)
	}
	if in.Username != "" {
		mod = mod.WhereLike("u."+dao.User.Columns().Username, "%"+in.Username+"%")
	}
	if in.Nickname != "" {
		mod = mod.WhereLike("u."+dao.User.Columns().Nickname, "%"+in.Nickname+"%")
	}
	if in.Mobile != "" {
		mod = mod.WhereLike("u."+dao.User.Columns().Mobile, "%"+in.Mobile+"%")
	}
	if in.Keyword != "" {
		mod = mod.Where("(u."+dao.User.Columns().Username+" LIKE ? OR u."+dao.User.Columns().Nickname+" LIKE ?)",
			"%"+in.Keyword+"%", "%"+in.Keyword+"%")
	}
	if in.Gender > 0 {
		mod = mod.Where("u."+dao.User.Columns().Gender, in.Gender)
	}
	if in.Status > 0 {
		mod = mod.Where("u."+dao.User.Columns().Status, in.Status)
	}
	if in.IsVip == 1 {
		mod = mod.Where("u."+dao.User.Columns().VipExpireAt+" > ?", gtime.Now())
	} else if in.IsVip == 2 {
		mod = mod.Where("u."+dao.User.Columns().VipExpireAt+" IS NULL OR u."+dao.User.Columns().VipExpireAt+" <= ?", gtime.Now())
	}
	if len(in.CreatedAt) == 2 {
		mod = mod.WhereBetween("u."+dao.User.Columns().CreatedAt, in.CreatedAt[0], in.CreatedAt[1])
	}

	mod = mod.Page(in.Page, in.PerPage).OrderDesc("u."+dao.User.Columns().Id)

	if err = mod.ScanAndCount(&list, &totalCount, false); err != nil {
		err = gerror.Wrap(err, "获取用户列表失败，请稍后重试！")
		return
	}

	// 标记VIP是否过期
	var now = gtime.Now()
	for _, v := range list {
		v.VipExpired = v.VipExpireAt == nil || v.VipExpireAt.Before(now)
	}
	return
}

// View 获取用户指定信息
func (s *sSysUser) View(ctx context.Context, in *sysin.UserViewInp) (res *sysin.UserViewModel, err error) {
	if err = s.Model(ctx).WherePri(in.Id).Scan(&res); err != nil {
		err = gerror.Wrap(err, "获取用户信息失败，请稍后重试！")
		return
	}
	return
}

// Edit 修改用户
func (s *sSysUser) Edit(ctx context.Context, in *sysin.UserEditInp) (err error) {
	in.UpdatedBy = contexts.GetUserId(ctx)
	if _, err = s.Model(ctx).
		Fields(sysin.UserUpdateFields{}).
		WherePri(in.Id).Data(in).Update(); err != nil {
		err = gerror.Wrap(err, "修改用户失败，请稍后重试！")
		return
	}
	return
}

// Delete 删除用户
func (s *sSysUser) Delete(ctx context.Context, in *sysin.UserDeleteInp) (err error) {
	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.User.Columns().DeletedBy: contexts.GetUserId(ctx),
		dao.User.Columns().DeletedAt: gtime.Now(),
	}).Unscoped().Update(); err != nil {
		err = gerror.Wrap(err, "删除用户失败，请稍后重试！")
		return
	}
	return
}

// Status 更新用户状态
func (s *sSysUser) Status(ctx context.Context, in *sysin.UserStatusInp) (err error) {
	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.User.Columns().Status:    in.Status,
		dao.User.Columns().UpdatedBy: contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "更新用户状态失败，请稍后重试！")
		return
	}
	return
}

// ResetPwd 重置用户密码
func (s *sSysUser) ResetPwd(ctx context.Context, in *sysin.UserResetPwdInp) (err error) {
	var salt = grand.S(6)
	if _, err = s.Model(ctx).WherePri(in.Id).Data(g.Map{
		dao.User.Columns().Salt:         salt,
		dao.User.Columns().PasswordHash: gmd5.MustEncryptString(in.NewPassword + salt),
		dao.User.Columns().UpdatedBy:    contexts.GetUserId(ctx),
	}).Update(); err != nil {
		err = gerror.Wrap(err, "重置用户密码失败，请稍后重试！")
		return
	}
	return
}
