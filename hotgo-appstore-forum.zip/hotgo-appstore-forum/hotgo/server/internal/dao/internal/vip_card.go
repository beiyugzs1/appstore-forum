// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// VipCardDao is the data access object for the table hg_vip_card.
type VipCardDao struct {
	table    string             // table is the underlying table name of the DAO.
	group    string             // group is the database configuration group name of the current DAO.
	columns  VipCardColumns     // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler // handlers for customized model modification.
}

// VipCardColumns defines and stores column names for the table hg_vip_card.
type VipCardColumns struct {
	Id             string // 卡密ID
	CardNo         string // 卡号
	CardPwd        string // 卡密
	PlanId         string // 绑定套餐ID
	DurationDays   string // 会员时长(天,冗余自套餐)
	BatchNo        string // 批次号
	Channel        string // 来源渠道
	ActivateUserId string // 激活用户ID
	ActivatedAt    string // 激活时间
	Remark         string // 备注
	Status         string // 状态:1未使用,2已使用,3已禁用
	CreatedBy      string // 创建者
	UpdatedBy      string // 更新者
	DeletedBy      string // 删除者
	CreatedAt      string // 创建时间
	UpdatedAt      string // 修改时间
	DeletedAt      string // 删除时间
}

// vipCardColumns holds the columns for the table hg_vip_card.
var vipCardColumns = VipCardColumns{
	Id:             "id",
	CardNo:         "card_no",
	CardPwd:        "card_pwd",
	PlanId:         "plan_id",
	DurationDays:   "duration_days",
	BatchNo:        "batch_no",
	Channel:        "channel",
	ActivateUserId: "activate_user_id",
	ActivatedAt:    "activated_at",
	Remark:         "remark",
	Status:         "status",
	CreatedBy:      "created_by",
	UpdatedBy:      "updated_by",
	DeletedBy:      "deleted_by",
	CreatedAt:      "created_at",
	UpdatedAt:      "updated_at",
	DeletedAt:      "deleted_at",
}

// NewVipCardDao creates and returns a new DAO object for table data access.
func NewVipCardDao(handlers ...gdb.ModelHandler) *VipCardDao {
	return &VipCardDao{
		group:    "default",
		table:    "hg_vip_card",
		columns:  vipCardColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *VipCardDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *VipCardDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *VipCardDao) Columns() VipCardColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *VipCardDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *VipCardDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *VipCardDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
