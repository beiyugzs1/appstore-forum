// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// VipCardLogDao is the data access object for the table hg_vip_card_log.
type VipCardLogDao struct {
	table    string             // table is the underlying table name of the DAO.
	group    string             // group is the database configuration group name of the current DAO.
	columns  VipCardLogColumns  // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler // handlers for customized model modification.
}

// VipCardLogColumns defines and stores column names for the table hg_vip_card_log.
type VipCardLogColumns struct {
	Id             string // 记录ID
	CardId         string // 卡密ID
	CardNo         string // 卡号
	UserId         string // 激活用户ID
	PlanId         string // 套餐ID
	DurationDays   string // 叠加天数
	BeforeExpireAt string // 激活前到期时间
	AfterExpireAt  string // 激活后到期时间
	ActivateIp     string // 激活IP
	CreatedAt      string // 创建时间
	UpdatedAt      string // 修改时间
}

// vipCardLogColumns holds the columns for the table hg_vip_card_log.
var vipCardLogColumns = VipCardLogColumns{
	Id:             "id",
	CardId:         "card_id",
	CardNo:         "card_no",
	UserId:         "user_id",
	PlanId:         "plan_id",
	DurationDays:   "duration_days",
	BeforeExpireAt: "before_expire_at",
	AfterExpireAt:  "after_expire_at",
	ActivateIp:     "activate_ip",
	CreatedAt:      "created_at",
	UpdatedAt:      "updated_at",
}

// NewVipCardLogDao creates and returns a new DAO object for table data access.
func NewVipCardLogDao(handlers ...gdb.ModelHandler) *VipCardLogDao {
	return &VipCardLogDao{
		group:    "default",
		table:    "hg_vip_card_log",
		columns:  vipCardLogColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *VipCardLogDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *VipCardLogDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *VipCardLogDao) Columns() VipCardLogColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *VipCardLogDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *VipCardLogDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *VipCardLogDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
