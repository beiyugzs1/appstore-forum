// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// AppAnnouncementDao is the data access object for the table hg_app_announcement.
type AppAnnouncementDao struct {
	table    string                 // table is the underlying table name of the DAO.
	group    string                 // group is the database configuration group name of the current DAO.
	columns  AppAnnouncementColumns // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler     // handlers for customized model modification.
}

// AppAnnouncementColumns defines and stores column names for the table hg_app_announcement.
type AppAnnouncementColumns struct {
	Id             string // 公告ID
	Title          string // 公告标题
	Type           string // 类型:1通知,2公告,3活动
	Summary        string // 摘要
	Content        string // 正文(富文本HTML)
	Cover          string // 封面图
	Target         string // 跳转:0无,1站内,2外链
	LinkUrl        string // 跳转地址
	IsTop          string // 是否置顶:0否,1是
	IsPopup        string // 是否参与启动弹窗:0否,1是
	PopupFrequency string // 弹窗频率:0每次,1每日一次,2仅一次
	Platform       string // 投放平台:all/android/ios
	PublishAt      string // 发布时间
	ExpireAt       string // 过期时间
	ViewCount      string // 阅读量
	Published      string // 发布状态:0草稿,1已发布
	Sort           string // 排序
	Status         string // 状态:1正常,2禁用
	CreatedBy      string // 创建者
	UpdatedBy      string // 更新者
	DeletedBy      string // 删除者
	CreatedAt      string // 创建时间
	UpdatedAt      string // 修改时间
	DeletedAt      string // 删除时间
}

// appAnnouncementColumns holds the columns for the table hg_app_announcement.
var appAnnouncementColumns = AppAnnouncementColumns{
	Id:             "id",
	Title:          "title",
	Type:           "type",
	Summary:        "summary",
	Content:        "content",
	Cover:          "cover",
	Target:         "target",
	LinkUrl:        "link_url",
	IsTop:          "is_top",
	IsPopup:        "is_popup",
	PopupFrequency: "popup_frequency",
	Platform:       "platform",
	PublishAt:      "publish_at",
	ExpireAt:       "expire_at",
	ViewCount:      "view_count",
	Published:      "published",
	Sort:           "sort",
	Status:         "status",
	CreatedBy:      "created_by",
	UpdatedBy:      "updated_by",
	DeletedBy:      "deleted_by",
	CreatedAt:      "created_at",
	UpdatedAt:      "updated_at",
	DeletedAt:      "deleted_at",
}

// NewAppAnnouncementDao creates and returns a new DAO object for table data access.
func NewAppAnnouncementDao(handlers ...gdb.ModelHandler) *AppAnnouncementDao {
	return &AppAnnouncementDao{
		group:    "default",
		table:    "hg_app_announcement",
		columns:  appAnnouncementColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *AppAnnouncementDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *AppAnnouncementDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *AppAnnouncementDao) Columns() AppAnnouncementColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *AppAnnouncementDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *AppAnnouncementDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *AppAnnouncementDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
