// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// ReportDao is the data access object for the table hg_report.
type ReportDao struct {
	table    string             // table is the underlying table name of the DAO.
	group    string             // group is the database configuration group name of the current DAO.
	columns  ReportColumns      // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler // handlers for customized model modification.
}

// ReportColumns defines and stores column names for the table hg_report.
type ReportColumns struct {
	Id           string // 举报ID
	UserId       string // 举报人用户ID
	TargetType   string // 类型:1帖子,2评论,3用户,4应用
	TargetId     string // 被举报对象ID
	Reason       string // 举报原因
	Description  string // 补充说明
	Images       string // 凭证图片
	HandleStatus string // 处理:0待处理,1已处理,2驳回
	HandleRemark string // 处理备注
	HandleBy     string // 处理人ID
	HandleAt     string // 处理时间
	Status       string // 状态:1正常,2禁用
	CreatedBy    string // 创建者
	UpdatedBy    string // 更新者
	DeletedBy    string // 删除者
	CreatedAt    string // 创建时间
	UpdatedAt    string // 修改时间
	DeletedAt    string // 删除时间
}

// reportColumns holds the columns for the table hg_report.
var reportColumns = ReportColumns{
	Id:           "id",
	UserId:       "user_id",
	TargetType:   "target_type",
	TargetId:     "target_id",
	Reason:       "reason",
	Description:  "description",
	Images:       "images",
	HandleStatus: "handle_status",
	HandleRemark: "handle_remark",
	HandleBy:     "handle_by",
	HandleAt:     "handle_at",
	Status:       "status",
	CreatedBy:    "created_by",
	UpdatedBy:    "updated_by",
	DeletedBy:    "deleted_by",
	CreatedAt:    "created_at",
	UpdatedAt:    "updated_at",
	DeletedAt:    "deleted_at",
}

// NewReportDao creates and returns a new DAO object for table data access.
func NewReportDao(handlers ...gdb.ModelHandler) *ReportDao {
	return &ReportDao{
		group:    "default",
		table:    "hg_report",
		columns:  reportColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *ReportDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *ReportDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *ReportDao) Columns() ReportColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *ReportDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *ReportDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *ReportDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
