// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// ForumModeratorDao is the data access object for the table hg_forum_moderator.
type ForumModeratorDao struct {
	table    string                // table is the underlying table name of the DAO.
	group    string                // group is the database configuration group name of the current DAO.
	columns  ForumModeratorColumns // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler    // handlers for customized model modification.
}

// ForumModeratorColumns defines and stores column names for the table hg_forum_moderator.
type ForumModeratorColumns struct {
	Id          string // 主键
	BoardId     string // 版块ID
	UserId      string // 版主用户ID
	Permissions string // 权限位图
	Remark      string // 任命备注
	AppointedBy string // 任命人(后台管理员ID)
	AppointedAt string // 任命时间
	Status      string // 状态:1正常,2禁用
	CreatedAt   string // 创建时间
	UpdatedAt   string // 更新时间
	DeletedAt   string // 删除时间
	CreatedBy   string // 创建者
	UpdatedBy   string // 更新者
	DeletedBy   string // 删除者
}

// forumModeratorColumns holds the columns for the table hg_forum_moderator.
var forumModeratorColumns = ForumModeratorColumns{
	Id:          "id",
	BoardId:     "board_id",
	UserId:      "user_id",
	Permissions: "permissions",
	Remark:      "remark",
	AppointedBy: "appointed_by",
	AppointedAt: "appointed_at",
	Status:      "status",
	CreatedAt:   "created_at",
	UpdatedAt:   "updated_at",
	DeletedAt:   "deleted_at",
	CreatedBy:   "created_by",
	UpdatedBy:   "updated_by",
	DeletedBy:   "deleted_by",
}

// NewForumModeratorDao creates and returns a new DAO object for table data access.
func NewForumModeratorDao(handlers ...gdb.ModelHandler) *ForumModeratorDao {
	return &ForumModeratorDao{
		group:    "default",
		table:    "hg_forum_moderator",
		columns:  forumModeratorColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *ForumModeratorDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *ForumModeratorDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *ForumModeratorDao) Columns() ForumModeratorColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *ForumModeratorDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *ForumModeratorDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *ForumModeratorDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
