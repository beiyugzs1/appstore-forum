// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// AdsDao is the data access object for the table hg_ads.
type AdsDao struct {
	table    string             // table is the underlying table name of the DAO.
	group    string             // group is the database configuration group name of the current DAO.
	columns  AdsColumns         // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler // handlers for customized model modification.
}

// AdsColumns defines and stores column names for the table hg_ads.
type AdsColumns struct {
	Id         string // 广告ID
	PositionId string // 广告位ID
	Title      string // 广告标题
	Type       string // 类型:1图片,2视频,3文字,4H5
	Image      string // 图片地址
	VideoUrl   string // 视频地址
	Text       string // 文字内容
	LinkType   string // 跳转类型:0无,1站内,2外链
	LinkUrl    string // 跳转地址
	AppId      string // 关联应用ID(站内跳转应用详情)
	StartAt    string // 投放开始时间
	EndAt      string // 投放结束时间
	Weight     string // 权重(轮播排序)
	ViewCount  string // 曝光量
	ClickCount string // 点击量
	Sort       string // 排序
	Status     string // 状态:1正常,2禁用
	CreatedBy  string // 创建者
	UpdatedBy  string // 更新者
	DeletedBy  string // 删除者
	CreatedAt  string // 创建时间
	UpdatedAt  string // 修改时间
	DeletedAt  string // 删除时间
}

// adsColumns holds the columns for the table hg_ads.
var adsColumns = AdsColumns{
	Id:         "id",
	PositionId: "position_id",
	Title:      "title",
	Type:       "type",
	Image:      "image",
	VideoUrl:   "video_url",
	Text:       "text",
	LinkType:   "link_type",
	LinkUrl:    "link_url",
	AppId:      "app_id",
	StartAt:    "start_at",
	EndAt:      "end_at",
	Weight:     "weight",
	ViewCount:  "view_count",
	ClickCount: "click_count",
	Sort:       "sort",
	Status:     "status",
	CreatedBy:  "created_by",
	UpdatedBy:  "updated_by",
	DeletedBy:  "deleted_by",
	CreatedAt:  "created_at",
	UpdatedAt:  "updated_at",
	DeletedAt:  "deleted_at",
}

// NewAdsDao creates and returns a new DAO object for table data access.
func NewAdsDao(handlers ...gdb.ModelHandler) *AdsDao {
	return &AdsDao{
		group:    "default",
		table:    "hg_ads",
		columns:  adsColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *AdsDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *AdsDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *AdsDao) Columns() AdsColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *AdsDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *AdsDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *AdsDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
