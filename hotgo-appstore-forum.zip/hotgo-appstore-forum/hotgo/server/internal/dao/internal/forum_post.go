// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// ForumPostDao is the data access object for the table hg_forum_post.
type ForumPostDao struct {
	table    string             // table is the underlying table name of the DAO.
	group    string             // group is the database configuration group name of the current DAO.
	columns  ForumPostColumns   // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler // handlers for customized model modification.
}

// ForumPostColumns defines and stores column names for the table hg_forum_post.
type ForumPostColumns struct {
	Id           string // 帖子ID
	BoardId      string // 版块ID
	UserId       string // 发帖用户ID
	Title        string // 帖子标题
	Content      string // 帖子内容
	Images       string // 帖子图片
	AuditStatus  string // 审核:0待审,1通过,2驳回
	AuditRemark  string // 审核备注
	AuditBy      string // 审核人ID
	AuditAt      string // 审核时间
	ViewCount    string // 浏览量
	LikeCount    string // 点赞数
	CommentCount string // 评论数
	IsTop        string // 是否置顶:0否,1是
	IsEssence    string // 是否加精:0否,1是
	Status       string // 状态:1正常,2禁用
	CreatedBy    string // 创建者
	UpdatedBy    string // 更新者
	DeletedBy    string // 删除者
	CreatedAt    string // 创建时间
	UpdatedAt    string // 修改时间
	DeletedAt    string // 删除时间
}

// forumPostColumns holds the columns for the table hg_forum_post.
var forumPostColumns = ForumPostColumns{
	Id:           "id",
	BoardId:      "board_id",
	UserId:       "user_id",
	Title:        "title",
	Content:      "content",
	Images:       "images",
	AuditStatus:  "audit_status",
	AuditRemark:  "audit_remark",
	AuditBy:      "audit_by",
	AuditAt:      "audit_at",
	ViewCount:    "view_count",
	LikeCount:    "like_count",
	CommentCount: "comment_count",
	IsTop:        "is_top",
	IsEssence:    "is_essence",
	Status:       "status",
	CreatedBy:    "created_by",
	UpdatedBy:    "updated_by",
	DeletedBy:    "deleted_by",
	CreatedAt:    "created_at",
	UpdatedAt:    "updated_at",
	DeletedAt:    "deleted_at",
}

// NewForumPostDao creates and returns a new DAO object for table data access.
func NewForumPostDao(handlers ...gdb.ModelHandler) *ForumPostDao {
	return &ForumPostDao{
		group:    "default",
		table:    "hg_forum_post",
		columns:  forumPostColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *ForumPostDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *ForumPostDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *ForumPostDao) Columns() ForumPostColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *ForumPostDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *ForumPostDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *ForumPostDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
