// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// ForumBoardDao is the data access object for the table hg_forum_board.
type ForumBoardDao struct {
	table    string             // table is the underlying table name of the DAO.
	group    string             // group is the database configuration group name of the current DAO.
	columns  ForumBoardColumns  // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler // handlers for customized model modification.
}

// ForumBoardColumns defines and stores column names for the table hg_forum_board.
type ForumBoardColumns struct {
	Id          string // 版块ID
	Name        string // 版块名称
	Icon        string // 版块图标
	Description string // 版块描述
	Sort        string // 排序
	PostCount   string // 帖子数
	Status      string // 状态:1正常,2禁用
	VipOnly     string // 是否会员专享:0否,1是
	CreatedBy   string // 创建者
	UpdatedBy   string // 更新者
	DeletedBy   string // 删除者
	CreatedAt   string // 创建时间
	UpdatedAt   string // 修改时间
	DeletedAt   string // 删除时间
}

// forumBoardColumns holds the columns for the table hg_forum_board.
var forumBoardColumns = ForumBoardColumns{
	Id:          "id",
	Name:        "name",
	Icon:        "icon",
	Description: "description",
	Sort:        "sort",
	PostCount:   "post_count",
	Status:      "status",
	VipOnly:     "vip_only",
	CreatedBy:   "created_by",
	UpdatedBy:   "updated_by",
	DeletedBy:   "deleted_by",
	CreatedAt:   "created_at",
	UpdatedAt:   "updated_at",
	DeletedAt:   "deleted_at",
}

// NewForumBoardDao creates and returns a new DAO object for table data access.
func NewForumBoardDao(handlers ...gdb.ModelHandler) *ForumBoardDao {
	return &ForumBoardDao{
		group:    "default",
		table:    "hg_forum_board",
		columns:  forumBoardColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *ForumBoardDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *ForumBoardDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *ForumBoardDao) Columns() ForumBoardColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *ForumBoardDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *ForumBoardDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *ForumBoardDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
