// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// AdPositionDao is the data access object for the table hg_ad_position.
type AdPositionDao struct {
	table    string             // table is the underlying table name of the DAO.
	group    string             // group is the database configuration group name of the current DAO.
	columns  AdPositionColumns  // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler // handlers for customized model modification.
}

// AdPositionColumns defines and stores column names for the table hg_ad_position.
type AdPositionColumns struct {
	Id          string // 广告位ID
	Code        string // 广告位编码(唯一，App按此拉取)
	Name        string // 广告位名称
	Platform    string // 平台:all/android/ios
	Width       string // 建议宽度(px)
	Height      string // 建议高度(px)
	Description string // 说明
	Sort        string // 排序
	Status      string // 状态:1正常,2禁用
	CreatedBy   string // 创建者
	UpdatedBy   string // 更新者
	DeletedBy   string // 删除者
	CreatedAt   string // 创建时间
	UpdatedAt   string // 修改时间
	DeletedAt   string // 删除时间
}

// adPositionColumns holds the columns for the table hg_ad_position.
var adPositionColumns = AdPositionColumns{
	Id:          "id",
	Code:        "code",
	Name:        "name",
	Platform:    "platform",
	Width:       "width",
	Height:      "height",
	Description: "description",
	Sort:        "sort",
	Status:      "status",
	CreatedBy:   "created_by",
	UpdatedBy:   "updated_by",
	DeletedBy:   "deleted_by",
	CreatedAt:   "created_at",
	UpdatedAt:   "updated_at",
	DeletedAt:   "deleted_at",
}

// NewAdPositionDao creates and returns a new DAO object for table data access.
func NewAdPositionDao(handlers ...gdb.ModelHandler) *AdPositionDao {
	return &AdPositionDao{
		group:    "default",
		table:    "hg_ad_position",
		columns:  adPositionColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *AdPositionDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *AdPositionDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *AdPositionDao) Columns() AdPositionColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *AdPositionDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *AdPositionDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *AdPositionDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
