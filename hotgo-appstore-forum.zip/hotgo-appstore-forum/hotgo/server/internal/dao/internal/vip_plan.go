// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// VipPlanDao is the data access object for the table hg_vip_plan.
type VipPlanDao struct {
	table    string             // table is the underlying table name of the DAO.
	group    string             // group is the database configuration group name of the current DAO.
	columns  VipPlanColumns     // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler // handlers for customized model modification.
}

// VipPlanColumns defines and stores column names for the table hg_vip_plan.
type VipPlanColumns struct {
	Id            string // 套餐ID
	Name          string // 套餐名称
	Type          string // 类型:1月卡,2季卡,3年卡
	DurationDays  string // 会员时长(天)
	Price         string // 售价
	OriginalPrice string // 原价
	Description   string // 套餐描述
	Sort          string // 排序
	Remark        string // 备注
	Status        string // 状态:1上架,2下架
	CreatedBy     string // 创建者
	UpdatedBy     string // 更新者
	DeletedBy     string // 删除者
	CreatedAt     string // 创建时间
	UpdatedAt     string // 修改时间
	DeletedAt     string // 删除时间
}

// vipPlanColumns holds the columns for the table hg_vip_plan.
var vipPlanColumns = VipPlanColumns{
	Id:            "id",
	Name:          "name",
	Type:          "type",
	DurationDays:  "duration_days",
	Price:         "price",
	OriginalPrice: "original_price",
	Description:   "description",
	Sort:          "sort",
	Remark:        "remark",
	Status:        "status",
	CreatedBy:     "created_by",
	UpdatedBy:     "updated_by",
	DeletedBy:     "deleted_by",
	CreatedAt:     "created_at",
	UpdatedAt:     "updated_at",
	DeletedAt:     "deleted_at",
}

// NewVipPlanDao creates and returns a new DAO object for table data access.
func NewVipPlanDao(handlers ...gdb.ModelHandler) *VipPlanDao {
	return &VipPlanDao{
		group:    "default",
		table:    "hg_vip_plan",
		columns:  vipPlanColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *VipPlanDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *VipPlanDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *VipPlanDao) Columns() VipPlanColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *VipPlanDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *VipPlanDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *VipPlanDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
