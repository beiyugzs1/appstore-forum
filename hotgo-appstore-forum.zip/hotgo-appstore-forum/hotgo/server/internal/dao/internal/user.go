// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// UserDao is the data access object for the table hg_user.
type UserDao struct {
	table    string             // table is the underlying table name of the DAO.
	group    string             // group is the database configuration group name of the current DAO.
	columns  UserColumns        // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler // handlers for customized model modification.
}

// UserColumns defines and stores column names for the table hg_user.
type UserColumns struct {
	Id           string // 用户ID
	Username     string // 用户名
	Nickname     string // 昵称
	PasswordHash string // 密码
	Salt         string // 密码盐
	Avatar       string // 头像
	Mobile       string // 手机号
	Email        string // 邮箱
	Gender       string // 性别:0未知,1男,2女
	VipPlanId    string // 当前VIP套餐ID
	VipExpireAt  string // VIP到期时间
	InviteCode   string // 邀请码
	Pid          string // 上级用户ID
	RegisterIp   string // 注册IP
	LastLoginAt  string // 最后登录时间
	LastLoginIp  string // 最后登录IP
	Remark       string // 备注
	Status       string // 状态:1正常,2禁用
	CreatedBy    string // 创建者
	UpdatedBy    string // 更新者
	DeletedBy    string // 删除者
	CreatedAt    string // 创建时间
	UpdatedAt    string // 修改时间
	DeletedAt    string // 删除时间
}

// userColumns holds the columns for the table hg_user.
var userColumns = UserColumns{
	Id:           "id",
	Username:     "username",
	Nickname:     "nickname",
	PasswordHash: "password_hash",
	Salt:         "salt",
	Avatar:       "avatar",
	Mobile:       "mobile",
	Email:        "email",
	Gender:       "gender",
	VipPlanId:    "vip_plan_id",
	VipExpireAt:  "vip_expire_at",
	InviteCode:   "invite_code",
	Pid:          "pid",
	RegisterIp:   "register_ip",
	LastLoginAt:  "last_login_at",
	LastLoginIp:  "last_login_ip",
	Remark:       "remark",
	Status:       "status",
	CreatedBy:    "created_by",
	UpdatedBy:    "updated_by",
	DeletedBy:    "deleted_by",
	CreatedAt:    "created_at",
	UpdatedAt:    "updated_at",
	DeletedAt:    "deleted_at",
}

// NewUserDao creates and returns a new DAO object for table data access.
func NewUserDao(handlers ...gdb.ModelHandler) *UserDao {
	return &UserDao{
		group:    "default",
		table:    "hg_user",
		columns:  userColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *UserDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *UserDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *UserDao) Columns() UserColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *UserDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *UserDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *UserDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
