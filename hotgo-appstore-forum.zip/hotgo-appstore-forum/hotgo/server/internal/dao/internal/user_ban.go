// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// UserBanDao is the data access object for the table hg_user_ban.
type UserBanDao struct {
	table    string             // table is the underlying table name of the DAO.
	group    string             // group is the database configuration group name of the current DAO.
	columns  UserBanColumns     // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler // handlers for customized model modification.
}

// UserBanColumns defines and stores column names for the table hg_user_ban.
type UserBanColumns struct {
	Id           string // 主键
	UserId       string // C端用户ID
	Type         string // 类型:1封禁,2禁言
	Scope        string // 范围:1全局,2指定版块
	BoardId      string // 版块ID,scope=1时为0
	Reason       string // 封禁原因
	StartAt      string // 生效时间
	ExpireAt     string // 到期时间,NULL为永久
	OperatorId   string // 操作人ID
	OperatorType string // 操作人类型:1后台管理员,2版主
	RelieveAt    string // 解除时间
	RelieveBy    string // 解除人ID
	Remark       string // 备注
	Status       string // 状态:1生效中,2已解除
	CreatedAt    string // 创建时间
	UpdatedAt    string // 更新时间
	DeletedAt    string // 删除时间
	CreatedBy    string // 创建者
	UpdatedBy    string // 更新者
	DeletedBy    string // 删除者
}

// userBanColumns holds the columns for the table hg_user_ban.
var userBanColumns = UserBanColumns{
	Id:           "id",
	UserId:       "user_id",
	Type:         "type",
	Scope:        "scope",
	BoardId:      "board_id",
	Reason:       "reason",
	StartAt:      "start_at",
	ExpireAt:     "expire_at",
	OperatorId:   "operator_id",
	OperatorType: "operator_type",
	RelieveAt:    "relieve_at",
	RelieveBy:    "relieve_by",
	Remark:       "remark",
	Status:       "status",
	CreatedAt:    "created_at",
	UpdatedAt:    "updated_at",
	DeletedAt:    "deleted_at",
	CreatedBy:    "created_by",
	UpdatedBy:    "updated_by",
	DeletedBy:    "deleted_by",
}

// NewUserBanDao creates and returns a new DAO object for table data access.
func NewUserBanDao(handlers ...gdb.ModelHandler) *UserBanDao {
	return &UserBanDao{
		group:    "default",
		table:    "hg_user_ban",
		columns:  userBanColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *UserBanDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *UserBanDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *UserBanDao) Columns() UserBanColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *UserBanDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *UserBanDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *UserBanDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
