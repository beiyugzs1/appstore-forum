// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// AppCategoryDao is the data access object for the table hg_app_category.
type AppCategoryDao struct {
	table    string             // table is the underlying table name of the DAO.
	group    string             // group is the database configuration group name of the current DAO.
	columns  AppCategoryColumns // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler // handlers for customized model modification.
}

// AppCategoryColumns defines and stores column names for the table hg_app_category.
type AppCategoryColumns struct {
	Id          string // 分类ID
	Name        string // 分类名称
	Icon        string // 分类图标
	Description string // 分类描述
	Sort        string // 排序
	Status      string // 状态:1正常,2禁用
	CreatedBy   string // 创建者
	UpdatedBy   string // 更新者
	DeletedBy   string // 删除者
	CreatedAt   string // 创建时间
	UpdatedAt   string // 修改时间
	DeletedAt   string // 删除时间
}

// appCategoryColumns holds the columns for the table hg_app_category.
var appCategoryColumns = AppCategoryColumns{
	Id:          "id",
	Name:        "name",
	Icon:        "icon",
	Description: "description",
	Sort:        "sort",
	Status:      "status",
	CreatedBy:   "created_by",
	UpdatedBy:   "updated_by",
	DeletedBy:   "deleted_by",
	CreatedAt:   "created_at",
	UpdatedAt:   "updated_at",
	DeletedAt:   "deleted_at",
}

// NewAppCategoryDao creates and returns a new DAO object for table data access.
func NewAppCategoryDao(handlers ...gdb.ModelHandler) *AppCategoryDao {
	return &AppCategoryDao{
		group:    "default",
		table:    "hg_app_category",
		columns:  appCategoryColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *AppCategoryDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *AppCategoryDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *AppCategoryDao) Columns() AppCategoryColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *AppCategoryDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *AppCategoryDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *AppCategoryDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
