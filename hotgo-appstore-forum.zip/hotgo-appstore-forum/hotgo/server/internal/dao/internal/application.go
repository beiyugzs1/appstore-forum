// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// ApplicationDao is the data access object for the table hg_application.
type ApplicationDao struct {
	table    string             // table is the underlying table name of the DAO.
	group    string             // group is the database configuration group name of the current DAO.
	columns  ApplicationColumns // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler // handlers for customized model modification.
}

// ApplicationColumns defines and stores column names for the table hg_application.
type ApplicationColumns struct {
	Id            string // 应用ID
	CategoryId    string // 分类ID
	Name          string // 应用名称
	Logo          string // 应用图标
	PackageName   string // 包名
	VersionName   string // 版本名称
	VersionCode   string // 版本号
	FileSize      string // 安装包大小(字节)
	FileMd5       string // 安装包MD5
	Description   string // 应用简介
	Screenshots   string // 应用截图
	DownloadUrl   string // 下载地址
	DeveloperId   string // 开发者用户ID
	DeveloperName string // 开发者名称
	SubmitType    string // 来源:1后台录入,2开发者提交
	AuditStatus   string // 审核:0待审,1通过,2驳回
	AuditRemark   string // 审核备注
	AuditBy       string // 审核人ID
	AuditAt       string // 审核时间
	ShelfStatus   string // 上架:1上架,2下架
	VipOnly       string // 是否会员专属:0否,1是
	DownloadCount string // 下载量
	ViewCount     string // 浏览量
	Sort          string // 排序
	Status        string // 状态:1正常,2禁用
	CreatedBy     string // 创建者
	UpdatedBy     string // 更新者
	DeletedBy     string // 删除者
	CreatedAt     string // 创建时间
	UpdatedAt     string // 修改时间
	DeletedAt     string // 删除时间
}

// applicationColumns holds the columns for the table hg_application.
var applicationColumns = ApplicationColumns{
	Id:            "id",
	CategoryId:    "category_id",
	Name:          "name",
	Logo:          "logo",
	PackageName:   "package_name",
	VersionName:   "version_name",
	VersionCode:   "version_code",
	FileSize:      "file_size",
	FileMd5:       "file_md5",
	Description:   "description",
	Screenshots:   "screenshots",
	DownloadUrl:   "download_url",
	DeveloperId:   "developer_id",
	DeveloperName: "developer_name",
	SubmitType:    "submit_type",
	AuditStatus:   "audit_status",
	AuditRemark:   "audit_remark",
	AuditBy:       "audit_by",
	AuditAt:       "audit_at",
	ShelfStatus:   "shelf_status",
	VipOnly:       "vip_only",
	DownloadCount: "download_count",
	ViewCount:     "view_count",
	Sort:          "sort",
	Status:        "status",
	CreatedBy:     "created_by",
	UpdatedBy:     "updated_by",
	DeletedBy:     "deleted_by",
	CreatedAt:     "created_at",
	UpdatedAt:     "updated_at",
	DeletedAt:     "deleted_at",
}

// NewApplicationDao creates and returns a new DAO object for table data access.
func NewApplicationDao(handlers ...gdb.ModelHandler) *ApplicationDao {
	return &ApplicationDao{
		group:    "default",
		table:    "hg_application",
		columns:  applicationColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *ApplicationDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *ApplicationDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *ApplicationDao) Columns() ApplicationColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *ApplicationDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *ApplicationDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *ApplicationDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
