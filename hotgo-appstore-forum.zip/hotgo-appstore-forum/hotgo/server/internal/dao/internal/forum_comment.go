// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// ForumCommentDao is the data access object for the table hg_forum_comment.
type ForumCommentDao struct {
	table    string              // table is the underlying table name of the DAO.
	group    string              // group is the database configuration group name of the current DAO.
	columns  ForumCommentColumns // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler  // handlers for customized model modification.
}

// ForumCommentColumns defines and stores column names for the table hg_forum_comment.
type ForumCommentColumns struct {
	Id          string // 评论ID
	PostId      string // 帖子ID
	UserId      string // 评论用户ID
	Pid         string // 父评论ID
	Content     string // 评论内容
	AuditStatus string // 审核:0待审,1通过,2驳回
	AuditRemark string // 审核备注
	AuditBy     string // 审核人ID
	AuditAt     string // 审核时间
	LikeCount   string // 点赞数
	Status      string // 状态:1正常,2禁用
	CreatedBy   string // 创建者
	UpdatedBy   string // 更新者
	DeletedBy   string // 删除者
	CreatedAt   string // 创建时间
	UpdatedAt   string // 修改时间
	DeletedAt   string // 删除时间
}

// forumCommentColumns holds the columns for the table hg_forum_comment.
var forumCommentColumns = ForumCommentColumns{
	Id:          "id",
	PostId:      "post_id",
	UserId:      "user_id",
	Pid:         "pid",
	Content:     "content",
	AuditStatus: "audit_status",
	AuditRemark: "audit_remark",
	AuditBy:     "audit_by",
	AuditAt:     "audit_at",
	LikeCount:   "like_count",
	Status:      "status",
	CreatedBy:   "created_by",
	UpdatedBy:   "updated_by",
	DeletedBy:   "deleted_by",
	CreatedAt:   "created_at",
	UpdatedAt:   "updated_at",
	DeletedAt:   "deleted_at",
}

// NewForumCommentDao creates and returns a new DAO object for table data access.
func NewForumCommentDao(handlers ...gdb.ModelHandler) *ForumCommentDao {
	return &ForumCommentDao{
		group:    "default",
		table:    "hg_forum_comment",
		columns:  forumCommentColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *ForumCommentDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *ForumCommentDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *ForumCommentDao) Columns() ForumCommentColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *ForumCommentDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *ForumCommentDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *ForumCommentDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
