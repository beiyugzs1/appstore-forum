// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// AppVersionDao is the data access object for the table hg_app_version.
type AppVersionDao struct {
	table    string             // table is the underlying table name of the DAO.
	group    string             // group is the database configuration group name of the current DAO.
	columns  AppVersionColumns  // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler // handlers for customized model modification.
}

// AppVersionColumns defines and stores column names for the table hg_app_version.
type AppVersionColumns struct {
	Id             string // 版本ID
	Platform       string // 平台:1Android,2iOS
	Channel        string // 渠道(多包时区分)
	VersionName    string // 版本名(1.2.0)
	VersionCode    string // 版本号(递增)
	Title          string // 更新标题
	Changelog      string // 更新日志
	DownloadUrl    string // 下载地址
	FileSize       string // 包大小(字节)
	FileMd5        string // 安装包MD5
	ForceUpdate    string // 是否强制更新:0否,1是
	MinSupportCode string // 低于此版本号强制更新(0取全局配置)
	GraySwitch     string // 灰度发布开关:0关闭,1开启
	GrayRatio      string // 灰度比例(0-100)
	PublishAt      string // 发布时间
	Sort           string // 排序
	Status         string // 状态:1正常,2禁用
	CreatedBy      string // 创建者
	UpdatedBy      string // 更新者
	DeletedBy      string // 删除者
	CreatedAt      string // 创建时间
	UpdatedAt      string // 修改时间
	DeletedAt      string // 删除时间
}

// appVersionColumns holds the columns for the table hg_app_version.
var appVersionColumns = AppVersionColumns{
	Id:             "id",
	Platform:       "platform",
	Channel:        "channel",
	VersionName:    "version_name",
	VersionCode:    "version_code",
	Title:          "title",
	Changelog:      "changelog",
	DownloadUrl:    "download_url",
	FileSize:       "file_size",
	FileMd5:        "file_md5",
	ForceUpdate:    "force_update",
	MinSupportCode: "min_support_code",
	GraySwitch:     "gray_switch",
	GrayRatio:      "gray_ratio",
	PublishAt:      "publish_at",
	Sort:           "sort",
	Status:         "status",
	CreatedBy:      "created_by",
	UpdatedBy:      "updated_by",
	DeletedBy:      "deleted_by",
	CreatedAt:      "created_at",
	UpdatedAt:      "updated_at",
	DeletedAt:      "deleted_at",
}

// NewAppVersionDao creates and returns a new DAO object for table data access.
func NewAppVersionDao(handlers ...gdb.ModelHandler) *AppVersionDao {
	return &AppVersionDao{
		group:    "default",
		table:    "hg_app_version",
		columns:  appVersionColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *AppVersionDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *AppVersionDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *AppVersionDao) Columns() AppVersionColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *AppVersionDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *AppVersionDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *AppVersionDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
