// Package crons
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package crons

import (
	"context"

	"hotgo/internal/library/cron"
	"hotgo/internal/service"
)

func init() {
	cron.Register(UserBanSweep)
}

// UserBanSweep 自动解除已到期的封禁/禁言记录
var UserBanSweep = &cUserBanSweep{name: "user_ban_sweep"}

type cUserBanSweep struct {
	name string
}

func (c *cUserBanSweep) GetName() string {
	return c.name
}

// Execute 执行任务
func (c *cUserBanSweep) Execute(ctx context.Context, parser *cron.Parser) (err error) {
	count, err := service.SysUserBan().SweepExpired(ctx)
	if err != nil {
		parser.Logger.Warning(ctx, "cron UserBanSweep Execute err:%+v", err)
		return
	}
	if count > 0 {
		parser.Logger.Info(ctx, "cron UserBanSweep relieved %d expired ban records", count)
	}
	return
}
