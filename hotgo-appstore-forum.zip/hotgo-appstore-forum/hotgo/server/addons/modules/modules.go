// Package modules
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2023 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
//
// 插件模块注册入口。
// 需要启用插件时，在此处匿名导入对应插件包，例如：
//
//	import _ "hotgo/addons/myaddon"
package modules
