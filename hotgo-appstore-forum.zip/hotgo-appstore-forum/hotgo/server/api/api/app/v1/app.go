// Package v1
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package v1

import (
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/model/input/form"

	"github.com/gogf/gf/v2/frame/g"
)

// CategoryListReq 应用分类列表
type CategoryListReq struct {
	g.Meta `path:"/app/categoryList" method:"get" tags:"C端-应用" summary:"获取应用分类列表"`
}

type CategoryListRes struct {
	*apiin.ApiAppCategoryListModel
}

// ListReq 应用列表
type ListReq struct {
	g.Meta `path:"/app/list" method:"get" tags:"C端-应用" summary:"获取应用列表(仅已上架)"`
	apiin.ApiAppListInp
}

type ListRes struct {
	form.PageRes
	List []*apiin.ApiAppListModel `json:"list" dc:"应用列表"`
}

// DetailReq 应用详情
type DetailReq struct {
	g.Meta `path:"/app/detail" method:"get" tags:"C端-应用" summary:"获取应用详情"`
	apiin.ApiAppDetailInp
}

type DetailRes struct {
	*apiin.ApiAppDetailModel
}

// SubmitReq 开发者提交应用
type SubmitReq struct {
	g.Meta `path:"/app/submit" method:"post" tags:"C端-应用" summary:"开发者提交应用(待审核)"`
	apiin.ApiAppSubmitInp
}

type SubmitRes struct {
	*apiin.ApiAppSubmitModel
}

// MyListReq 我提交的应用
type MyListReq struct {
	g.Meta `path:"/app/myList" method:"get" tags:"C端-应用" summary:"获取我提交的应用"`
	apiin.ApiAppMyListInp
}

type MyListRes struct {
	form.PageRes
	List []*apiin.ApiAppMyListModel `json:"list" dc:"应用列表"`
}
