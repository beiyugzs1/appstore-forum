// Package v1
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package v1

import (
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// InfoReq 获取个人资料
type InfoReq struct {
	g.Meta `path:"/user/info" method:"get" tags:"C端-用户" summary:"获取个人资料"`
}

type InfoRes struct {
	*apiin.ApiUserInfoModel
}

// UpdateProfileReq 修改个人资料
type UpdateProfileReq struct {
	g.Meta `path:"/user/updateProfile" method:"post" tags:"C端-用户" summary:"修改个人资料"`
	apiin.ApiUpdateProfileInp
}

type UpdateProfileRes struct{}

// UpdatePwdReq 修改密码
type UpdatePwdReq struct {
	g.Meta `path:"/user/updatePwd" method:"post" tags:"C端-用户" summary:"修改登录密码"`
	apiin.ApiUpdatePwdInp
}

type UpdatePwdRes struct{}

// BanStatusReq 我的封禁/禁言状态
type BanStatusReq struct {
	g.Meta `path:"/user/banStatus" method:"get" tags:"C端-用户" summary:"获取我的封禁禁言状态"`
}

type BanStatusRes struct {
	*sysin.UserBanStatusModel
}
