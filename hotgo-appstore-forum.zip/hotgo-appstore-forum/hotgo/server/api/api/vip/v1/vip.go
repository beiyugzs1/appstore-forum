// Package v1
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package v1

import (
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/model/input/form"

	"github.com/gogf/gf/v2/frame/g"
)

// PlanListReq VIP套餐列表
type PlanListReq struct {
	g.Meta `path:"/vip/planList" method:"get" tags:"C端-VIP" summary:"获取VIP套餐列表"`
}

type PlanListRes struct {
	*apiin.ApiVipPlanListModel
}

// ActivateReq 卡密激活VIP
type ActivateReq struct {
	g.Meta `path:"/vip/activate" method:"post" tags:"C端-VIP" summary:"使用卡密激活VIP"`
	apiin.ApiVipActivateInp
}

type ActivateRes struct {
	*apiin.ApiVipActivateModel
}

// MyCardLogReq 我的激活记录
type MyCardLogReq struct {
	g.Meta `path:"/vip/myCardLog" method:"get" tags:"C端-VIP" summary:"获取我的卡密激活记录"`
	apiin.ApiVipCardLogListInp
}

type MyCardLogRes struct {
	form.PageRes
	List []*apiin.ApiVipCardLogModel `json:"list" dc:"激活记录"`
}
