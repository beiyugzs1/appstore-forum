// Package v1
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package v1

import (
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/model/input/form"

	"github.com/gogf/gf/v2/frame/g"
)

// MyBoardsReq 我管理的版块列表
type MyBoardsReq struct {
	g.Meta `path:"/moderator/myBoards" method:"get" tags:"C端-版主工作台" summary:"获取我担任版主的版块列表"`
}

type MyBoardsRes struct {
	*apiin.ApiModeratorMyBoardsModel
}

// PermissionReq 我在指定版块的权限
type PermissionReq struct {
	g.Meta `path:"/moderator/permission" method:"get" tags:"C端-版主工作台" summary:"获取我在指定版块的版主权限"`
	apiin.ApiModeratorPermissionInp
}

type PermissionRes struct {
	*apiin.ApiModeratorPermissionModel
}

// PendingPostsReq 本版待审帖子
type PendingPostsReq struct {
	g.Meta `path:"/moderator/pendingPosts" method:"get" tags:"C端-版主工作台" summary:"获取本版待审帖子列表"`
	apiin.ApiModeratorPendingPostListInp
}

type PendingPostsRes struct {
	form.PageRes
	List []*apiin.ApiModeratorPendingPostModel `json:"list" dc:"待审帖子列表"`
}

// PendingCommentsReq 本版待审评论
type PendingCommentsReq struct {
	g.Meta `path:"/moderator/pendingComments" method:"get" tags:"C端-版主工作台" summary:"获取本版待审评论列表"`
	apiin.ApiModeratorPendingCommentListInp
}

type PendingCommentsRes struct {
	form.PageRes
	List []*apiin.ApiModeratorPendingCommentModel `json:"list" dc:"待审评论列表"`
}

// AuditPostReq 版主审核帖子
type AuditPostReq struct {
	g.Meta `path:"/moderator/auditPost" method:"post" tags:"C端-版主工作台" summary:"版主审核帖子"`
	apiin.ApiModeratorAuditPostInp
}

type AuditPostRes struct {
	*apiin.ApiModeratorOperateModel
}

// AuditCommentReq 版主审核评论
type AuditCommentReq struct {
	g.Meta `path:"/moderator/auditComment" method:"post" tags:"C端-版主工作台" summary:"版主审核评论"`
	apiin.ApiModeratorAuditCommentInp
}

type AuditCommentRes struct {
	*apiin.ApiModeratorOperateModel
}

// TopPostReq 版主置顶/取消置顶
type TopPostReq struct {
	g.Meta `path:"/moderator/topPost" method:"post" tags:"C端-版主工作台" summary:"版主置顶或取消置顶帖子"`
	apiin.ApiModeratorTopPostInp
}

type TopPostRes struct {
	*apiin.ApiModeratorOperateModel
}

// EssencePostReq 版主加精/取消加精
type EssencePostReq struct {
	g.Meta `path:"/moderator/essencePost" method:"post" tags:"C端-版主工作台" summary:"版主加精或取消加精帖子"`
	apiin.ApiModeratorEssencePostInp
}

type EssencePostRes struct {
	*apiin.ApiModeratorOperateModel
}

// DeletePostReq 版主删除帖子
type DeletePostReq struct {
	g.Meta `path:"/moderator/deletePost" method:"post" tags:"C端-版主工作台" summary:"版主删除帖子"`
	apiin.ApiModeratorIdInp
}

type DeletePostRes struct {
	*apiin.ApiModeratorOperateModel
}

// DeleteCommentReq 版主删除评论
type DeleteCommentReq struct {
	g.Meta `path:"/moderator/deleteComment" method:"post" tags:"C端-版主工作台" summary:"版主删除评论"`
	apiin.ApiModeratorIdInp
}

type DeleteCommentRes struct {
	*apiin.ApiModeratorOperateModel
}

// BanUserReq 版主封禁/禁言本版用户
type BanUserReq struct {
	g.Meta `path:"/moderator/banUser" method:"post" tags:"C端-版主工作台" summary:"版主封禁或禁言本版用户"`
	apiin.ApiModeratorBanUserInp
}

type BanUserRes struct {
	*apiin.ApiModeratorOperateModel
}
