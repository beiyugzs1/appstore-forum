// Package v1
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package v1

import (
	"hotgo/internal/model/input/apiin"

	"github.com/gogf/gf/v2/frame/g"
)

// SubmitReq 提交举报
type SubmitReq struct {
	g.Meta `path:"/report/submit" method:"post" tags:"C端-举报" summary:"提交举报"`
	apiin.ApiReportSubmitInp
}

type SubmitRes struct {
	*apiin.ApiReportSubmitModel
}
