// Package v1
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package v1

import (
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/model/input/form"

	"github.com/gogf/gf/v2/frame/g"
)

// BoardListReq 版块列表
type BoardListReq struct {
	g.Meta `path:"/forum/boardList" method:"get" tags:"C端-论坛" summary:"获取论坛版块列表"`
}

type BoardListRes struct {
	*apiin.ApiForumBoardListModel
}

// PostListReq 帖子列表
type PostListReq struct {
	g.Meta `path:"/forum/postList" method:"get" tags:"C端-论坛" summary:"获取帖子列表(仅已通过)"`
	apiin.ApiForumPostListInp
}

type PostListRes struct {
	form.PageRes
	List []*apiin.ApiForumPostModel `json:"list" dc:"帖子列表"`
}

// PostDetailReq 帖子详情
type PostDetailReq struct {
	g.Meta `path:"/forum/postDetail" method:"get" tags:"C端-论坛" summary:"获取帖子详情"`
	apiin.ApiForumPostDetailInp
}

type PostDetailRes struct {
	*apiin.ApiForumPostDetailModel
}

// PublishPostReq 发布帖子
type PublishPostReq struct {
	g.Meta `path:"/forum/publishPost" method:"post" tags:"C端-论坛" summary:"发布帖子(待审核)"`
	apiin.ApiForumPublishPostInp
}

type PublishPostRes struct {
	*apiin.ApiForumPublishPostModel
}

// CommentListReq 评论列表
type CommentListReq struct {
	g.Meta `path:"/forum/commentList" method:"get" tags:"C端-论坛" summary:"获取帖子评论列表(仅已通过)"`
	apiin.ApiForumCommentListInp
}

type CommentListRes struct {
	form.PageRes
	List []*apiin.ApiForumCommentModel `json:"list" dc:"评论列表"`
}

// PublishCommentReq 发表评论
type PublishCommentReq struct {
	g.Meta `path:"/forum/publishComment" method:"post" tags:"C端-论坛" summary:"发表评论或回复(待审核)"`
	apiin.ApiForumPublishCommentInp
}

type PublishCommentRes struct {
	*apiin.ApiForumPublishCommentModel
}
