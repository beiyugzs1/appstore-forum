// Package v1
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package v1

import (
	"hotgo/internal/model/input/apiin"

	"github.com/gogf/gf/v2/frame/g"
)

// LoginReq 账号登录
type LoginReq struct {
	g.Meta `path:"/site/login" method:"post" tags:"C端-认证" summary:"账号密码登录(返回双令牌)"`
	apiin.ApiLoginInp
}

type LoginRes struct {
	*apiin.ApiLoginModel
}

// RegisterReq 用户注册
type RegisterReq struct {
	g.Meta `path:"/site/register" method:"post" tags:"C端-认证" summary:"用户注册"`
	apiin.ApiRegisterInp
}

type RegisterRes struct {
	*apiin.ApiRegisterModel
}

// RefreshReq 刷新令牌
type RefreshReq struct {
	g.Meta `path:"/site/refresh" method:"post" tags:"C端-认证" summary:"刷新访问令牌(令牌轮换)"`
	apiin.ApiRefreshInp
}

type RefreshRes struct {
	*apiin.ApiRefreshModel
}

// LogoutReq 退出登录
type LogoutReq struct {
	g.Meta `path:"/site/logout" method:"post" tags:"C端-认证" summary:"退出登录"`
	apiin.ApiLogoutInp
}

type LogoutRes struct{}
