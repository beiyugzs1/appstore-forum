// Package v1
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package v1

import (
	"hotgo/internal/model/input/apiin"
	"hotgo/internal/model/input/form"

	"github.com/gogf/gf/v2/frame/g"
)

// AndroidConfigReq 获取Android端配置
type AndroidConfigReq struct {
	g.Meta `path:"/ops/androidConfig" method:"get" tags:"C端-运营" summary:"获取App端配置"`
}

type AndroidConfigRes struct {
	*apiin.ApiAndroidConfigModel
}

// AnnouncementListReq App公告列表
type AnnouncementListReq struct {
	g.Meta `path:"/ops/announcement/list" method:"get" tags:"C端-运营" summary:"获取App公告列表(仅已发布)"`
	apiin.ApiAnnouncementListInp
}

type AnnouncementListRes struct {
	form.PageRes
	List []*apiin.ApiAnnouncementListModel `json:"list" dc:"公告列表"`
}

// AnnouncementDetailReq App公告详情
type AnnouncementDetailReq struct {
	g.Meta `path:"/ops/announcement/detail" method:"get" tags:"C端-运营" summary:"获取App公告详情"`
	apiin.ApiAnnouncementDetailInp
}

type AnnouncementDetailRes struct {
	*apiin.ApiAnnouncementDetailModel
}

// VersionCheckReq 检查版本更新
type VersionCheckReq struct {
	g.Meta `path:"/ops/versionCheck" method:"get" tags:"C端-运营" summary:"检查版本更新"`
	apiin.ApiVersionCheckInp
}

type VersionCheckRes struct {
	*apiin.ApiVersionCheckModel
}

// AdListReq 按广告位取广告
type AdListReq struct {
	g.Meta `path:"/ops/ad/list" method:"get" tags:"C端-运营" summary:"按广告位获取广告"`
	apiin.ApiAdListInp
}

type AdListRes struct {
	*apiin.ApiAdListModel
}

// AdReportReq 广告曝光/点击上报
type AdReportReq struct {
	g.Meta `path:"/ops/ad/report" method:"post" tags:"C端-运营" summary:"广告曝光/点击上报"`
	apiin.ApiAdReportInp
}

type AdReportRes struct{}
