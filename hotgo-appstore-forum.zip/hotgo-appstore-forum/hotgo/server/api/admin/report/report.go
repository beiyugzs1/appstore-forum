// Package report
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package report

import (
	"hotgo/internal/model/input/form"
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// ListReq 查询举报列表
type ListReq struct {
	g.Meta `path:"/report/list" method:"get" tags:"举报管理" summary:"获取举报列表"`
	sysin.ReportListInp
}

type ListRes struct {
	form.PageRes
	List []*sysin.ReportListModel `json:"list" dc:"数据列表"`
}

// ViewReq 获取举报指定信息
type ViewReq struct {
	g.Meta `path:"/report/view" method:"get" tags:"举报管理" summary:"获取举报指定信息"`
	sysin.ReportViewInp
}

type ViewRes struct {
	*sysin.ReportViewModel
}

// HandleReq 处理举报
type HandleReq struct {
	g.Meta `path:"/report/handle" method:"post" tags:"举报管理" summary:"处理举报"`
	sysin.ReportHandleInp
}

type HandleRes struct{}

// DeleteReq 删除举报
type DeleteReq struct {
	g.Meta `path:"/report/delete" method:"post" tags:"举报管理" summary:"删除举报"`
	sysin.ReportDeleteInp
}

type DeleteRes struct{}
