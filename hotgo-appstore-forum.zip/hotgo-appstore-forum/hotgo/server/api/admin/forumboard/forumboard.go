// Package forumboard
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package forumboard

import (
	"hotgo/internal/model/input/form"
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// ListReq 查询论坛版块列表
type ListReq struct {
	g.Meta `path:"/forumBoard/list" method:"get" tags:"论坛版块" summary:"获取论坛版块列表"`
	sysin.ForumBoardListInp
}

type ListRes struct {
	form.PageRes
	List []*sysin.ForumBoardListModel `json:"list" dc:"数据列表"`
}

// ViewReq 获取论坛版块指定信息
type ViewReq struct {
	g.Meta `path:"/forumBoard/view" method:"get" tags:"论坛版块" summary:"获取论坛版块指定信息"`
	sysin.ForumBoardViewInp
}

type ViewRes struct {
	*sysin.ForumBoardViewModel
}

// EditReq 修改/新增论坛版块
type EditReq struct {
	g.Meta `path:"/forumBoard/edit" method:"post" tags:"论坛版块" summary:"修改/新增论坛版块"`
	sysin.ForumBoardEditInp
}

type EditRes struct{}

// DeleteReq 删除论坛版块
type DeleteReq struct {
	g.Meta `path:"/forumBoard/delete" method:"post" tags:"论坛版块" summary:"删除论坛版块"`
	sysin.ForumBoardDeleteInp
}

type DeleteRes struct{}

// StatusReq 更新论坛版块状态
type StatusReq struct {
	g.Meta `path:"/forumBoard/status" method:"post" tags:"论坛版块" summary:"更新论坛版块状态"`
	sysin.ForumBoardStatusInp
}

type StatusRes struct{}
