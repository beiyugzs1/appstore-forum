// Package appversion
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package appversion

import (
	"hotgo/internal/model/input/form"
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// ListReq 查询App版本列表
type ListReq struct {
	g.Meta `path:"/appVersion/list" method:"get" tags:"App版本" summary:"获取App版本列表"`
	sysin.AppVersionListInp
}

type ListRes struct {
	form.PageRes
	List []*sysin.AppVersionListModel `json:"list" dc:"数据列表"`
}

// ViewReq 获取App版本详情
type ViewReq struct {
	g.Meta `path:"/appVersion/view" method:"get" tags:"App版本" summary:"获取App版本详情"`
	sysin.AppVersionViewInp
}

type ViewRes struct {
	*sysin.AppVersionListModel
}

// EditReq 修改/新增App版本
type EditReq struct {
	g.Meta `path:"/appVersion/edit" method:"post" tags:"App版本" summary:"修改/新增App版本"`
	sysin.AppVersionEditInp
}

type EditRes struct{}

// DeleteReq 删除App版本
type DeleteReq struct {
	g.Meta `path:"/appVersion/delete" method:"post" tags:"App版本" summary:"删除App版本"`
	sysin.AppVersionDeleteInp
}

type DeleteRes struct{}

// StatusReq 更新App版本状态
type StatusReq struct {
	g.Meta `path:"/appVersion/status" method:"post" tags:"App版本" summary:"更新App版本状态"`
	sysin.AppVersionStatusInp
}

type StatusRes struct{}

// PublishReq 发布App版本
type PublishReq struct {
	g.Meta `path:"/appVersion/publish" method:"post" tags:"App版本" summary:"发布App版本"`
	sysin.AppVersionPublishInp
}

type PublishRes struct{}
