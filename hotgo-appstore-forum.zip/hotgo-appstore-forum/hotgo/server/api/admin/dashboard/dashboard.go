// Package dashboard
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package dashboard

import (
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// StatisticsReq 获取看板统计数据
type StatisticsReq struct {
	g.Meta `path:"/dashboard/statistics" method:"get" tags:"数据看板" summary:"获取看板统计数据"`
	sysin.DashboardStatisticsInp
}

type StatisticsRes struct {
	*sysin.DashboardStatisticsModel
}
