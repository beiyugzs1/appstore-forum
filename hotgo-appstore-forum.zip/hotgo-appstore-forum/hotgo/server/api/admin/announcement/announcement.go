// Package announcement
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package announcement

import (
	"hotgo/internal/model/input/form"
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// ListReq 查询App公告列表
type ListReq struct {
	g.Meta `path:"/announcement/list" method:"get" tags:"App公告" summary:"获取App公告列表"`
	sysin.AnnouncementListInp
}

type ListRes struct {
	form.PageRes
	List []*sysin.AnnouncementListModel `json:"list" dc:"数据列表"`
}

// ViewReq 获取App公告详情
type ViewReq struct {
	g.Meta `path:"/announcement/view" method:"get" tags:"App公告" summary:"获取App公告详情"`
	sysin.AnnouncementViewInp
}

type ViewRes struct {
	*sysin.AnnouncementListModel
}

// EditReq 修改/新增App公告
type EditReq struct {
	g.Meta `path:"/announcement/edit" method:"post" tags:"App公告" summary:"修改/新增App公告"`
	sysin.AnnouncementEditInp
}

type EditRes struct{}

// DeleteReq 删除App公告
type DeleteReq struct {
	g.Meta `path:"/announcement/delete" method:"post" tags:"App公告" summary:"删除App公告"`
	sysin.AnnouncementDeleteInp
}

type DeleteRes struct{}

// StatusReq 更新App公告状态
type StatusReq struct {
	g.Meta `path:"/announcement/status" method:"post" tags:"App公告" summary:"更新App公告状态"`
	sysin.AnnouncementStatusInp
}

type StatusRes struct{}

// PublishReq 发布/撤回App公告
type PublishReq struct {
	g.Meta `path:"/announcement/publish" method:"post" tags:"App公告" summary:"发布/撤回App公告"`
	sysin.AnnouncementPublishInp
}

type PublishRes struct{}
