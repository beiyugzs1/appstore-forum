// Package application
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package application

import (
	"hotgo/internal/model/input/form"
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// ListReq 查询应用列表
type ListReq struct {
	g.Meta `path:"/application/list" method:"get" tags:"应用管理" summary:"获取应用列表"`
	sysin.ApplicationListInp
}

type ListRes struct {
	form.PageRes
	List []*sysin.ApplicationListModel `json:"list" dc:"数据列表"`
}

// ViewReq 获取应用指定信息
type ViewReq struct {
	g.Meta `path:"/application/view" method:"get" tags:"应用管理" summary:"获取应用指定信息"`
	sysin.ApplicationViewInp
}

type ViewRes struct {
	*sysin.ApplicationViewModel
}

// EditReq 修改/新增应用
type EditReq struct {
	g.Meta `path:"/application/edit" method:"post" tags:"应用管理" summary:"修改/新增应用"`
	sysin.ApplicationEditInp
}

type EditRes struct{}

// DeleteReq 删除应用
type DeleteReq struct {
	g.Meta `path:"/application/delete" method:"post" tags:"应用管理" summary:"删除应用"`
	sysin.ApplicationDeleteInp
}

type DeleteRes struct{}

// StatusReq 更新应用状态
type StatusReq struct {
	g.Meta `path:"/application/status" method:"post" tags:"应用管理" summary:"更新应用状态"`
	sysin.ApplicationStatusInp
}

type StatusRes struct{}

// AuditReq 审核应用
type AuditReq struct {
	g.Meta `path:"/application/audit" method:"post" tags:"应用管理" summary:"审核应用"`
	sysin.ApplicationAuditInp
}

type AuditRes struct{}

// ShelfReq 应用上下架
type ShelfReq struct {
	g.Meta `path:"/application/shelf" method:"post" tags:"应用管理" summary:"应用上下架"`
	sysin.ApplicationShelfInp
}

type ShelfRes struct{}
