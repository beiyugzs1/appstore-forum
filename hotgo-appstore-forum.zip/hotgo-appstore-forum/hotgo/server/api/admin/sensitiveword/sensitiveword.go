// Package sensitiveword
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package sensitiveword

import (
	"hotgo/internal/model/input/form"
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// ListReq 查询敏感词列表
type ListReq struct {
	g.Meta `path:"/sensitiveWord/list" method:"get" tags:"敏感词" summary:"获取敏感词列表"`
	sysin.SensitiveWordListInp
}

type ListRes struct {
	form.PageRes
	List []*sysin.SensitiveWordListModel `json:"list" dc:"数据列表"`
}

// ViewReq 获取敏感词详情
type ViewReq struct {
	g.Meta `path:"/sensitiveWord/view" method:"get" tags:"敏感词" summary:"获取敏感词详情"`
	sysin.SensitiveWordViewInp
}

type ViewRes struct {
	*sysin.SensitiveWordListModel
}

// EditReq 修改/新增敏感词
type EditReq struct {
	g.Meta `path:"/sensitiveWord/edit" method:"post" tags:"敏感词" summary:"修改/新增敏感词"`
	sysin.SensitiveWordEditInp
}

type EditRes struct{}

// DeleteReq 删除敏感词
type DeleteReq struct {
	g.Meta `path:"/sensitiveWord/delete" method:"post" tags:"敏感词" summary:"删除敏感词"`
	sysin.SensitiveWordDeleteInp
}

type DeleteRes struct{}

// StatusReq 更新敏感词状态
type StatusReq struct {
	g.Meta `path:"/sensitiveWord/status" method:"post" tags:"敏感词" summary:"更新敏感词状态"`
	sysin.SensitiveWordStatusInp
}

type StatusRes struct{}
