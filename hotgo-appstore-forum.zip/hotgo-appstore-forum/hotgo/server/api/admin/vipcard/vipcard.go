// Package vipcard
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package vipcard

import (
	"hotgo/internal/model/input/form"
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// ListReq 查询卡密列表
type ListReq struct {
	g.Meta `path:"/vipCard/list" method:"get" tags:"卡密管理" summary:"获取卡密列表"`
	sysin.VipCardListInp
}

type ListRes struct {
	form.PageRes
	List []*sysin.VipCardListModel `json:"list" dc:"数据列表"`
}

// ViewReq 获取卡密指定信息
type ViewReq struct {
	g.Meta `path:"/vipCard/view" method:"get" tags:"卡密管理" summary:"获取卡密指定信息"`
	sysin.VipCardViewInp
}

type ViewRes struct {
	*sysin.VipCardViewModel
}

// GenerateReq 批量生成卡密
type GenerateReq struct {
	g.Meta `path:"/vipCard/generate" method:"post" tags:"卡密管理" summary:"批量生成卡密"`
	sysin.VipCardGenerateInp
}

type GenerateRes struct {
	*sysin.VipCardGenerateModel
}

// DeleteReq 删除卡密
type DeleteReq struct {
	g.Meta `path:"/vipCard/delete" method:"post" tags:"卡密管理" summary:"删除卡密"`
	sysin.VipCardDeleteInp
}

type DeleteRes struct{}

// StatusReq 更新卡密状态
type StatusReq struct {
	g.Meta `path:"/vipCard/status" method:"post" tags:"卡密管理" summary:"更新卡密状态"`
	sysin.VipCardStatusInp
}

type StatusRes struct{}

// LogListReq 查询卡密激活记录
type LogListReq struct {
	g.Meta `path:"/vipCard/logList" method:"get" tags:"卡密管理" summary:"获取卡密激活记录"`
	sysin.VipCardLogListInp
}

type LogListRes struct {
	form.PageRes
	List []*sysin.VipCardLogListModel `json:"list" dc:"数据列表"`
}
