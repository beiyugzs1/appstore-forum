// Package forumpost
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package forumpost

import (
	"hotgo/internal/model/input/form"
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// ListReq 查询帖子列表
type ListReq struct {
	g.Meta `path:"/forumPost/list" method:"get" tags:"论坛帖子" summary:"获取帖子列表"`
	sysin.ForumPostListInp
}

type ListRes struct {
	form.PageRes
	List []*sysin.ForumPostListModel `json:"list" dc:"数据列表"`
}

// ViewReq 获取帖子指定信息
type ViewReq struct {
	g.Meta `path:"/forumPost/view" method:"get" tags:"论坛帖子" summary:"获取帖子指定信息"`
	sysin.ForumPostViewInp
}

type ViewRes struct {
	*sysin.ForumPostViewModel
}

// EditReq 修改帖子
type EditReq struct {
	g.Meta `path:"/forumPost/edit" method:"post" tags:"论坛帖子" summary:"修改帖子"`
	sysin.ForumPostEditInp
}

type EditRes struct{}

// DeleteReq 删除帖子
type DeleteReq struct {
	g.Meta `path:"/forumPost/delete" method:"post" tags:"论坛帖子" summary:"删除帖子"`
	sysin.ForumPostDeleteInp
}

type DeleteRes struct{}

// StatusReq 更新帖子状态
type StatusReq struct {
	g.Meta `path:"/forumPost/status" method:"post" tags:"论坛帖子" summary:"更新帖子状态"`
	sysin.ForumPostStatusInp
}

type StatusRes struct{}

// AuditReq 审核帖子
type AuditReq struct {
	g.Meta `path:"/forumPost/audit" method:"post" tags:"论坛帖子" summary:"审核帖子"`
	sysin.ForumPostAuditInp
}

type AuditRes struct{}
