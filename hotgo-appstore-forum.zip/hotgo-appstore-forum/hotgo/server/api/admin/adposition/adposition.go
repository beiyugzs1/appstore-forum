// Package adposition
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package adposition

import (
	"hotgo/internal/model"
	"hotgo/internal/model/input/form"
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// ListReq 查询广告位列表
type ListReq struct {
	g.Meta `path:"/adPosition/list" method:"get" tags:"广告位" summary:"获取广告位列表"`
	sysin.AdPositionListInp
}

type ListRes struct {
	form.PageRes
	List []*sysin.AdPositionListModel `json:"list" dc:"数据列表"`
}

// ViewReq 获取广告位详情
type ViewReq struct {
	g.Meta `path:"/adPosition/view" method:"get" tags:"广告位" summary:"获取广告位详情"`
	sysin.AdPositionViewInp
}

type ViewRes struct {
	*sysin.AdPositionListModel
}

// EditReq 修改/新增广告位
type EditReq struct {
	g.Meta `path:"/adPosition/edit" method:"post" tags:"广告位" summary:"修改/新增广告位"`
	sysin.AdPositionEditInp
}

type EditRes struct{}

// DeleteReq 删除广告位
type DeleteReq struct {
	g.Meta `path:"/adPosition/delete" method:"post" tags:"广告位" summary:"删除广告位"`
	sysin.AdPositionDeleteInp
}

type DeleteRes struct{}

// StatusReq 更新广告位状态
type StatusReq struct {
	g.Meta `path:"/adPosition/status" method:"post" tags:"广告位" summary:"更新广告位状态"`
	sysin.AdPositionStatusInp
}

type StatusRes struct{}

// OptionReq 获取广告位选项
type OptionReq struct {
	g.Meta `path:"/adPosition/option" method:"get" tags:"广告位" summary:"获取广告位选项"`
}

type OptionRes struct {
	List []*model.Option `json:"list" dc:"选项列表"`
}
