// Package userban
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package userban

import (
	"hotgo/internal/model/input/form"
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// ListReq 查询封禁记录列表
type ListReq struct {
	g.Meta `path:"/userBan/list" method:"get" tags:"用户封禁" summary:"获取用户封禁禁言列表"`
	sysin.UserBanListInp
}

type ListRes struct {
	form.PageRes
	List []*sysin.UserBanListModel `json:"list" dc:"数据列表"`
}

// ViewReq 获取封禁记录详情
type ViewReq struct {
	g.Meta `path:"/userBan/view" method:"get" tags:"用户封禁" summary:"获取封禁记录详情"`
	sysin.UserBanViewInp
}

type ViewRes struct {
	*sysin.UserBanListModel
}

// EditReq 封禁/禁言用户
type EditReq struct {
	g.Meta `path:"/userBan/edit" method:"post" tags:"用户封禁" summary:"封禁或禁言用户"`
	sysin.UserBanEditInp
}

type EditRes struct{}

// RelieveReq 解除封禁
type RelieveReq struct {
	g.Meta `path:"/userBan/relieve" method:"post" tags:"用户封禁" summary:"解除用户封禁或禁言"`
	sysin.UserBanRelieveInp
}

type RelieveRes struct{}

// DeleteReq 删除封禁记录
type DeleteReq struct {
	g.Meta `path:"/userBan/delete" method:"post" tags:"用户封禁" summary:"删除封禁记录"`
	sysin.UserBanDeleteInp
}

type DeleteRes struct{}
