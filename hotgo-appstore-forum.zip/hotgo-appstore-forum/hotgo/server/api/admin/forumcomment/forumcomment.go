// Package forumcomment
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package forumcomment

import (
	"hotgo/internal/model/input/form"
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// ListReq 查询评论列表
type ListReq struct {
	g.Meta `path:"/forumComment/list" method:"get" tags:"论坛评论" summary:"获取评论列表"`
	sysin.ForumCommentListInp
}

type ListRes struct {
	form.PageRes
	List []*sysin.ForumCommentListModel `json:"list" dc:"数据列表"`
}

// ViewReq 获取评论指定信息
type ViewReq struct {
	g.Meta `path:"/forumComment/view" method:"get" tags:"论坛评论" summary:"获取评论指定信息"`
	sysin.ForumCommentViewInp
}

type ViewRes struct {
	*sysin.ForumCommentViewModel
}

// DeleteReq 删除评论
type DeleteReq struct {
	g.Meta `path:"/forumComment/delete" method:"post" tags:"论坛评论" summary:"删除评论"`
	sysin.ForumCommentDeleteInp
}

type DeleteRes struct{}

// StatusReq 更新评论状态
type StatusReq struct {
	g.Meta `path:"/forumComment/status" method:"post" tags:"论坛评论" summary:"更新评论状态"`
	sysin.ForumCommentStatusInp
}

type StatusRes struct{}

// AuditReq 审核评论
type AuditReq struct {
	g.Meta `path:"/forumComment/audit" method:"post" tags:"论坛评论" summary:"审核评论"`
	sysin.ForumCommentAuditInp
}

type AuditRes struct{}
