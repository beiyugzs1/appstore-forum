// Package forummoderator
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package forummoderator

import (
	"hotgo/internal/model/input/form"
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// ListReq 查询论坛版主列表
type ListReq struct {
	g.Meta `path:"/forumModerator/list" method:"get" tags:"论坛版主" summary:"获取论坛版主列表"`
	sysin.ForumModeratorListInp
}

type ListRes struct {
	form.PageRes
	List []*sysin.ForumModeratorListModel `json:"list" dc:"数据列表"`
}

// ViewReq 获取论坛版主指定信息
type ViewReq struct {
	g.Meta `path:"/forumModerator/view" method:"get" tags:"论坛版主" summary:"获取论坛版主指定信息"`
	sysin.ForumModeratorViewInp
}

type ViewRes struct {
	*sysin.ForumModeratorListModel
}

// EditReq 修改/新增论坛版主
type EditReq struct {
	g.Meta `path:"/forumModerator/edit" method:"post" tags:"论坛版主" summary:"任命/修改版主"`
	sysin.ForumModeratorEditInp
}

type EditRes struct{}

// DeleteReq 删除论坛版主
type DeleteReq struct {
	g.Meta `path:"/forumModerator/delete" method:"post" tags:"论坛版主" summary:"撤销版主"`
	sysin.ForumModeratorDeleteInp
}

type DeleteRes struct{}

// StatusReq 更新论坛版主状态
type StatusReq struct {
	g.Meta `path:"/forumModerator/status" method:"post" tags:"论坛版主" summary:"更新版主状态"`
	sysin.ForumModeratorStatusInp
}

type StatusRes struct{}
