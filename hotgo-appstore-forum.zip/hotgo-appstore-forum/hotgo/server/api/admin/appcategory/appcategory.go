// Package appcategory
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package appcategory

import (
	"hotgo/internal/model/input/form"
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// ListReq 查询应用分类列表
type ListReq struct {
	g.Meta `path:"/appCategory/list" method:"get" tags:"应用分类" summary:"获取应用分类列表"`
	sysin.AppCategoryListInp
}

type ListRes struct {
	form.PageRes
	List []*sysin.AppCategoryListModel `json:"list" dc:"数据列表"`
}

// ViewReq 获取应用分类指定信息
type ViewReq struct {
	g.Meta `path:"/appCategory/view" method:"get" tags:"应用分类" summary:"获取应用分类指定信息"`
	sysin.AppCategoryViewInp
}

type ViewRes struct {
	*sysin.AppCategoryViewModel
}

// EditReq 修改/新增应用分类
type EditReq struct {
	g.Meta `path:"/appCategory/edit" method:"post" tags:"应用分类" summary:"修改/新增应用分类"`
	sysin.AppCategoryEditInp
}

type EditRes struct{}

// DeleteReq 删除应用分类
type DeleteReq struct {
	g.Meta `path:"/appCategory/delete" method:"post" tags:"应用分类" summary:"删除应用分类"`
	sysin.AppCategoryDeleteInp
}

type DeleteRes struct{}

// StatusReq 更新应用分类状态
type StatusReq struct {
	g.Meta `path:"/appCategory/status" method:"post" tags:"应用分类" summary:"更新应用分类状态"`
	sysin.AppCategoryStatusInp
}

type StatusRes struct{}
