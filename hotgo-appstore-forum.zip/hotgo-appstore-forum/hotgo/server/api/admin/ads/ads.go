// Package ads
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package ads

import (
	"hotgo/internal/model/input/form"
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// ListReq 查询广告素材列表
type ListReq struct {
	g.Meta `path:"/ads/list" method:"get" tags:"广告素材" summary:"获取广告素材列表"`
	sysin.AdsListInp
}

type ListRes struct {
	form.PageRes
	List []*sysin.AdsListModel `json:"list" dc:"数据列表"`
}

// ViewReq 获取广告素材详情
type ViewReq struct {
	g.Meta `path:"/ads/view" method:"get" tags:"广告素材" summary:"获取广告素材详情"`
	sysin.AdsViewInp
}

type ViewRes struct {
	*sysin.AdsListModel
}

// EditReq 修改/新增广告素材
type EditReq struct {
	g.Meta `path:"/ads/edit" method:"post" tags:"广告素材" summary:"修改/新增广告素材"`
	sysin.AdsEditInp
}

type EditRes struct{}

// DeleteReq 删除广告素材
type DeleteReq struct {
	g.Meta `path:"/ads/delete" method:"post" tags:"广告素材" summary:"删除广告素材"`
	sysin.AdsDeleteInp
}

type DeleteRes struct{}

// StatusReq 更新广告素材状态
type StatusReq struct {
	g.Meta `path:"/ads/status" method:"post" tags:"广告素材" summary:"更新广告素材状态"`
	sysin.AdsStatusInp
}

type StatusRes struct{}
