// Package vipplan
// @Link  https://github.com/bufanyun/hotgo
// @Copyright  Copyright (c) 2025 HotGo CLI
// @Author  Ms <133814250@qq.com>
// @License  https://github.com/bufanyun/hotgo/blob/master/LICENSE
package vipplan

import (
	"hotgo/internal/model/input/form"
	"hotgo/internal/model/input/sysin"

	"github.com/gogf/gf/v2/frame/g"
)

// ListReq 查询VIP套餐列表
type ListReq struct {
	g.Meta `path:"/vipPlan/list" method:"get" tags:"VIP套餐" summary:"获取VIP套餐列表"`
	sysin.VipPlanListInp
}

type ListRes struct {
	form.PageRes
	List []*sysin.VipPlanListModel `json:"list" dc:"数据列表"`
}

// ViewReq 获取VIP套餐指定信息
type ViewReq struct {
	g.Meta `path:"/vipPlan/view" method:"get" tags:"VIP套餐" summary:"获取VIP套餐指定信息"`
	sysin.VipPlanViewInp
}

type ViewRes struct {
	*sysin.VipPlanViewModel
}

// EditReq 修改/新增VIP套餐
type EditReq struct {
	g.Meta `path:"/vipPlan/edit" method:"post" tags:"VIP套餐" summary:"修改/新增VIP套餐"`
	sysin.VipPlanEditInp
}

type EditRes struct{}

// DeleteReq 删除VIP套餐
type DeleteReq struct {
	g.Meta `path:"/vipPlan/delete" method:"post" tags:"VIP套餐" summary:"删除VIP套餐"`
	sysin.VipPlanDeleteInp
}

type DeleteRes struct{}

// StatusReq 更新VIP套餐状态
type StatusReq struct {
	g.Meta `path:"/vipPlan/status" method:"post" tags:"VIP套餐" summary:"更新VIP套餐状态"`
	sysin.VipPlanStatusInp
}

type StatusRes struct{}
