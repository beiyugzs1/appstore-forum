-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: hotgo
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hg_sys_gen_curd_demo`
--

DROP TABLE IF EXISTS `hg_sys_gen_curd_demo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hg_sys_gen_curd_demo` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `category_id` bigint DEFAULT '0' COMMENT '分类ID',
  `title` varchar(64) NOT NULL COMMENT '标题',
  `description` varchar(255) DEFAULT '' COMMENT '描述',
  `content` text COMMENT '内容',
  `image` varchar(255) DEFAULT NULL COMMENT '单图',
  `attachfile` varchar(255) DEFAULT NULL COMMENT '附件',
  `city_id` bigint DEFAULT '0' COMMENT '所在城市',
  `switch` int DEFAULT '1' COMMENT '显示开关',
  `sort` int DEFAULT NULL COMMENT '排序',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态',
  `created_by` bigint DEFAULT '0' COMMENT '创建者',
  `updated_by` bigint DEFAULT '0' COMMENT '更新者',
  `deleted_by` bigint DEFAULT '0' COMMENT '删除者',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统_生成curd演示';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hg_sys_gen_curd_demo`
--

LOCK TABLES `hg_sys_gen_curd_demo` WRITE;
/*!40000 ALTER TABLE `hg_sys_gen_curd_demo` DISABLE KEYS */;
INSERT INTO `hg_sys_gen_curd_demo` VALUES (1,1,'测试标题','这是一个CRUD生成演示，关联测试分类','<h2><strong>不知道写点啥！</strong></h2><p><br></p><iframe class=\"ql-video\" frameborder=\"0\" allowfullscreen=\"true\" src=\"https://media.w3.org/2010/05/sintel/trailer.mp4\"></iframe><p><br></p><p><img src=\"https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdq9iuv0phsg8patk.png\"></p>','https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqamvhlq4w3ki6bl.webp','http://localhost:8000/attachment/2024-07-25/d2yh86z5wxgoyuuyv7.png',120102,1,10,1,1,1,NULL,'2022-12-15 19:30:14','2024-07-25 16:28:31',NULL);
/*!40000 ALTER TABLE `hg_sys_gen_curd_demo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hg_sys_gen_tree_demo`
--

DROP TABLE IF EXISTS `hg_sys_gen_tree_demo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hg_sys_gen_tree_demo` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` bigint DEFAULT NULL COMMENT '上级ID',
  `level` int DEFAULT '1' COMMENT '关系树级别',
  `tree` varchar(512) DEFAULT NULL COMMENT '关系树',
  `category_id` bigint DEFAULT '0' COMMENT '分类ID',
  `title` varchar(64) NOT NULL COMMENT '标题',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `sort` int DEFAULT NULL COMMENT '排序',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态',
  `created_by` bigint DEFAULT '0' COMMENT '创建者',
  `updated_by` bigint DEFAULT '0' COMMENT '更新者',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统_生成树表演示';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hg_sys_gen_tree_demo`
--

LOCK TABLES `hg_sys_gen_tree_demo` WRITE;
/*!40000 ALTER TABLE `hg_sys_gen_tree_demo` DISABLE KEYS */;
INSERT INTO `hg_sys_gen_tree_demo` VALUES (1,0,1,NULL,1,'道生一','这是一个普通树形表格的生成演示。',10,1,1,1,'2022-12-15 19:30:14','2024-07-20 23:38:07',NULL),(14,1,2,'tr_1 ',1,'一生二','',20,1,1,1,'2024-04-09 17:07:55','2024-07-21 00:20:15',NULL),(15,14,3,'tr_1 tr_14 ',2,'二生三','',30,1,1,1,'2024-04-09 17:08:03','2024-07-21 00:17:21',NULL),(16,15,4,'tr_1 tr_14 tr_15 ',4,'三生万物','',40,1,1,1,'2024-04-09 17:13:54','2024-07-21 00:17:24',NULL),(17,0,1,'',1,'一帆风顺','',50,1,1,1,'2024-04-09 17:24:58','2024-07-21 00:18:13',NULL),(19,17,2,'tr_17 ',1,'二龙戏珠','',60,1,1,1,'2024-04-09 17:27:40','2024-07-21 00:17:30',NULL),(20,19,3,'tr_17 tr_19 ',1,'三心二意','',70,1,1,1,'2024-04-09 17:27:44','2024-07-21 00:17:33',NULL);
/*!40000 ALTER TABLE `hg_sys_gen_tree_demo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hg_test_category`
--

DROP TABLE IF EXISTS `hg_test_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hg_test_category` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(255) NOT NULL COMMENT '分类名称',
  `short_name` varchar(128) DEFAULT NULL COMMENT '简称',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `sort` int NOT NULL COMMENT '排序',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='测试分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hg_test_category`
--

LOCK TABLES `hg_test_category` WRITE;
/*!40000 ALTER TABLE `hg_test_category` DISABLE KEYS */;
INSERT INTO `hg_test_category` VALUES (1,'官方新闻','G','用于演示关联表和字典选项生成和使用。',10,'',1,'2023-01-03 00:00:00','2023-01-03 00:00:00',NULL),(2,'移动应用','Y','',20,'',1,'2023-01-03 00:00:00','2023-01-03 00:00:00',NULL),(3,'微信公众号','W','',30,'',1,'2023-01-03 00:00:00','2023-01-03 00:00:00',NULL),(4,'系统搭建','X','',40,'',1,'2023-01-03 00:00:00','2023-01-03 00:00:00',NULL);
/*!40000 ALTER TABLE `hg_test_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hg_sys_gen_codes`
--

DROP TABLE IF EXISTS `hg_sys_gen_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hg_sys_gen_codes` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '生成ID',
  `gen_type` int unsigned NOT NULL COMMENT '生成类型',
  `gen_template` int DEFAULT '0' COMMENT '生成模板',
  `var_name` varchar(255) NOT NULL COMMENT '实体命名',
  `options` json DEFAULT NULL COMMENT '配置选项',
  `db_name` varchar(128) DEFAULT NULL COMMENT '数据库名称',
  `table_name` varchar(255) NOT NULL COMMENT '主表名称',
  `table_comment` varchar(255) DEFAULT NULL COMMENT '主表注释',
  `dao_name` varchar(255) DEFAULT NULL COMMENT '主表dao模型',
  `master_columns` json DEFAULT NULL COMMENT '主表字段',
  `addon_name` varchar(128) DEFAULT NULL COMMENT '插件名称',
  `status` tinyint(1) DEFAULT '1' COMMENT '生成状态',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统_代码生成记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hg_sys_gen_codes`
--

LOCK TABLES `hg_sys_gen_codes` WRITE;
/*!40000 ALTER TABLE `hg_sys_gen_codes` DISABLE KEYS */;
INSERT INTO `hg_sys_gen_codes` VALUES (1,10,0,'CurdDemo','{\"join\": [{\"uuid\": \"pgJsFoqfaGjqgKjy\", \"alias\": \"testCategory\", \"field\": \"id\", \"columns\": [{\"dc\": \"分类ID\", \"id\": 1, \"name\": \"id\", \"extra\": \"auto_increment\", \"index\": \"PRI\", \"goName\": \"TestCategoryId\", \"goType\": \"int64\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"testCategoryId\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": 0, \"formMode\": \"\", \"formRole\": \"\", \"isExport\": false, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"NO\", \"defaultValue\": 0}, {\"dc\": \"关联分类\", \"id\": 2, \"name\": \"name\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"TestCategoryName\", \"goType\": \"string\", \"isEdit\": false, \"isList\": true, \"isSort\": false, \"length\": 255, \"tsName\": \"testCategoryName\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"varchar(255)\", \"dataType\": \"varchar\", \"dictType\": 0, \"formMode\": \"\", \"formRole\": \"\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"NO\", \"defaultValue\": \"\"}, {\"dc\": \"分类简称\", \"id\": 3, \"name\": \"short_name\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"TestCategoryShortName\", \"goType\": \"string\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 128, \"tsName\": \"testCategoryShortName\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"varchar(128)\", \"dataType\": \"varchar\", \"dictType\": 0, \"formMode\": \"\", \"formRole\": \"\", \"isExport\": false, \"required\": false, \"queryWhere\": \"LIKE %...%\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}, {\"dc\": \"描述\", \"id\": 3, \"name\": \"description\", \"extra\": \"\", \"index\": \"\", \"goName\": \"TestCategoryDescription\", \"goType\": \"string\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 255, \"tsName\": \"testCategoryDescription\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"varchar(255)\", \"dataType\": \"varchar\", \"dictType\": 0, \"formMode\": \"\", \"formRole\": \"\", \"isExport\": false, \"required\": false, \"queryWhere\": \"LIKE\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\"}, {\"dc\": \"排序\", \"id\": 4, \"name\": \"sort\", \"extra\": \"\", \"index\": \"\", \"goName\": \"TestCategorySort\", \"goType\": \"int\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"testCategorySort\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"int(11)\", \"dataType\": \"int\", \"dictType\": 0, \"formMode\": \"\", \"formRole\": \"\", \"isExport\": false, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"NO\", \"defaultValue\": 0}, {\"dc\": \"备注\", \"id\": 5, \"name\": \"remark\", \"extra\": \"\", \"index\": \"\", \"goName\": \"TestCategoryRemark\", \"goType\": \"string\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 255, \"tsName\": \"testCategoryRemark\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"varchar(255)\", \"dataType\": \"varchar\", \"dictType\": 0, \"formMode\": \"\", \"formRole\": \"\", \"isExport\": false, \"required\": false, \"queryWhere\": \"LIKE\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\"}, {\"dc\": \"状态\", \"id\": 6, \"name\": \"status\", \"extra\": \"\", \"index\": \"\", \"goName\": \"TestCategoryStatus\", \"goType\": \"int\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"testCategoryStatus\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"tinyint(1)\", \"dataType\": \"tinyint\", \"dictType\": 0, \"formMode\": \"\", \"formRole\": \"\", \"isExport\": false, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 1}, {\"dc\": \"创建时间\", \"id\": 7, \"name\": \"created_at\", \"extra\": \"\", \"index\": \"\", \"goName\": \"TestCategoryCreatedAt\", \"goType\": \"*gtime.Time\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"testCategoryCreatedAt\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"datetime\", \"dataType\": \"datetime\", \"dictType\": 0, \"formMode\": \"\", \"formRole\": \"\", \"isExport\": false, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\"}, {\"dc\": \"修改时间\", \"id\": 8, \"name\": \"updated_at\", \"extra\": \"\", \"index\": \"\", \"goName\": \"TestCategoryUpdatedAt\", \"goType\": \"*gtime.Time\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"testCategoryUpdatedAt\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"datetime\", \"dataType\": \"datetime\", \"dictType\": 0, \"formMode\": \"\", \"formRole\": \"\", \"isExport\": false, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\"}, {\"dc\": \"删除时间\", \"id\": 9, \"name\": \"deleted_at\", \"extra\": \"\", \"index\": \"\", \"goName\": \"TestCategoryDeletedAt\", \"goType\": \"*gtime.Time\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"testCategoryDeletedAt\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"datetime\", \"dataType\": \"datetime\", \"dictType\": 0, \"formMode\": \"\", \"formRole\": \"\", \"isExport\": false, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\"}], \"daoName\": \"TestCategory\", \"linkMode\": 1, \"linkTable\": \"hg_test_category\", \"masterField\": \"category_id\"}], \"menu\": {\"pid\": 2366, \"icon\": \"\", \"sort\": 10}, \"tree\": {\"styleType\": 1, \"titleColumn\": null}, \"autoOps\": [\"genMenuPermissions\", \"runDao\", \"runService\", \"forcedCover\"], \"headOps\": [\"add\", \"batchDel\", \"export\"], \"funcDict\": {\"labelColumn\": \"title\", \"valueColumn\": \"id\"}, \"columnOps\": [\"edit\", \"del\", \"switch\", \"check\", \"status\"], \"presetStep\": {\"formGridCols\": 2}}','default','hg_sys_gen_curd_demo','CURD列表','SysGenCurdDemo','[{\"dc\": \"ID\", \"id\": 1, \"name\": \"id\", \"align\": \"left\", \"extra\": \"auto_increment\", \"index\": \"PRI\", \"width\": 50, \"goName\": \"Id\", \"goType\": \"int64\", \"isEdit\": false, \"isList\": true, \"isSort\": true, \"length\": 0, \"tsName\": \"id\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": null, \"formMode\": \"Input\", \"formRole\": \"none\", \"isExport\": true, \"required\": true, \"queryWhere\": \"=\", \"isAllowNull\": \"NO\", \"defaultValue\": 0, \"formGridSpan\": 1}, {\"dc\": \"测试分类\", \"id\": 2, \"name\": \"category_id\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"CategoryId\", \"goType\": \"int64\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"categoryId\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": -300004223237244, \"formMode\": \"Select\", \"formRole\": \"none\", \"isExport\": false, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"NO\", \"defaultValue\": 0, \"formGridSpan\": 1}, {\"dc\": \"标题\", \"id\": 3, \"name\": \"title\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 150, \"goName\": \"Title\", \"goType\": \"string\", \"isEdit\": true, \"isList\": true, \"isSort\": false, \"length\": 64, \"tsName\": \"title\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"varchar(64)\", \"dataType\": \"varchar\", \"dictType\": null, \"formMode\": \"Input\", \"formRole\": \"none\", \"isExport\": true, \"required\": true, \"queryWhere\": \"LIKE %...%\", \"isAllowNull\": \"NO\", \"defaultValue\": \"\", \"formGridSpan\": 1}, {\"dc\": \"描述\", \"id\": 4, \"name\": \"description\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 300, \"goName\": \"Description\", \"goType\": \"string\", \"isEdit\": true, \"isList\": true, \"isSort\": false, \"length\": 255, \"tsName\": \"description\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"varchar(255)\", \"dataType\": \"varchar\", \"dictType\": null, \"formMode\": \"InputTextarea\", \"formRole\": \"none\", \"isExport\": true, \"required\": true, \"queryWhere\": \"LIKE %...%\", \"isAllowNull\": \"NO\", \"defaultValue\": \"\", \"formGridSpan\": 2}, {\"dc\": \"内容\", \"id\": 5, \"name\": \"content\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"Content\", \"goType\": \"string\", \"isEdit\": true, \"isList\": false, \"isSort\": false, \"length\": 65535, \"tsName\": \"content\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"text\", \"dataType\": \"text\", \"dictType\": null, \"formMode\": \"InputEditor\", \"formRole\": \"none\", \"isExport\": false, \"required\": true, \"queryWhere\": \"LIKE %...%\", \"isAllowNull\": \"NO\", \"defaultValue\": \"\", \"formGridSpan\": 2}, {\"dc\": \"单图\", \"id\": 6, \"name\": \"image\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"Image\", \"goType\": \"string\", \"isEdit\": true, \"isList\": true, \"isSort\": false, \"length\": 255, \"tsName\": \"image\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"varchar(255)\", \"dataType\": \"varchar\", \"dictType\": null, \"formMode\": \"UploadImage\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"LIKE\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}, {\"dc\": \"附件\", \"id\": 7, \"name\": \"attachfile\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"Attachfile\", \"goType\": \"string\", \"isEdit\": true, \"isList\": true, \"isSort\": false, \"length\": 255, \"tsName\": \"attachfile\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"varchar(255)\", \"dataType\": \"varchar\", \"dictType\": null, \"formMode\": \"UploadFile\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"LIKE\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}, {\"dc\": \"所在城市\", \"id\": 8, \"name\": \"city_id\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"CityId\", \"goType\": \"int64\", \"isEdit\": true, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"cityId\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": null, \"formMode\": \"CitySelector\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 0, \"formGridSpan\": 1}, {\"dc\": \"显示开关\", \"id\": 9, \"name\": \"switch\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 150, \"goName\": \"Switch\", \"goType\": \"int\", \"isEdit\": true, \"isList\": true, \"isSort\": false, \"length\": 0, \"tsName\": \"switch\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"int(11)\", \"dataType\": \"int\", \"dictType\": null, \"formMode\": \"Switch\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 1, \"formGridSpan\": 1}, {\"dc\": \"排序\", \"id\": 10, \"name\": \"sort\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"Sort\", \"goType\": \"int\", \"isEdit\": true, \"isList\": true, \"isSort\": true, \"length\": 0, \"tsName\": \"sort\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"int(11)\", \"dataType\": \"int\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": true, \"required\": true, \"queryWhere\": \"=\", \"isAllowNull\": \"NO\", \"defaultValue\": 0, \"formGridSpan\": 1}, {\"dc\": \"状态\", \"id\": 11, \"name\": \"status\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"Status\", \"goType\": \"int\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"status\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"tinyint(1)\", \"dataType\": \"tinyint\", \"dictType\": 3, \"formMode\": \"Select\", \"formRole\": \"none\", \"isExport\": false, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 1, \"formGridSpan\": 1}, {\"dc\": \"创建者\", \"id\": 12, \"name\": \"created_by\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 150, \"goName\": \"CreatedBy\", \"goType\": \"int64\", \"isEdit\": false, \"isList\": true, \"isSort\": false, \"length\": 0, \"tsName\": \"createdBy\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 0, \"formGridSpan\": 1}, {\"dc\": \"更新者\", \"id\": 13, \"name\": \"updated_by\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 150, \"goName\": \"UpdatedBy\", \"goType\": \"int64\", \"isEdit\": false, \"isList\": true, \"isSort\": false, \"length\": 0, \"tsName\": \"updatedBy\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 0, \"formGridSpan\": 1}, {\"dc\": \"删除者\", \"id\": 14, \"name\": \"deleted_by\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"DeletedBy\", \"goType\": \"int64\", \"isEdit\": false, \"isList\": true, \"isSort\": false, \"length\": 0, \"tsName\": \"deletedBy\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 0, \"formGridSpan\": 1}, {\"dc\": \"创建时间\", \"id\": 14, \"name\": \"created_at\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 180, \"goName\": \"CreatedAt\", \"goType\": \"*gtime.Time\", \"isEdit\": false, \"isList\": true, \"isSort\": false, \"length\": 0, \"tsName\": \"createdAt\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"datetime\", \"dataType\": \"datetime\", \"dictType\": null, \"formMode\": \"TimeRange\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"BETWEEN\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}, {\"dc\": \"修改时间\", \"id\": 15, \"name\": \"updated_at\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 180, \"goName\": \"UpdatedAt\", \"goType\": \"*gtime.Time\", \"isEdit\": false, \"isList\": true, \"isSort\": false, \"length\": 0, \"tsName\": \"updatedAt\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"datetime\", \"dataType\": \"datetime\", \"dictType\": null, \"formMode\": \"Time\", \"formRole\": \"none\", \"isExport\": false, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}, {\"dc\": \"删除时间\", \"id\": 16, \"name\": \"deleted_at\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"DeletedAt\", \"goType\": \"*gtime.Time\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"deletedAt\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"datetime\", \"dataType\": \"datetime\", \"dictType\": null, \"formMode\": \"Time\", \"formRole\": \"none\", \"isExport\": false, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}]','',1,'2023-01-18 11:51:22','2024-08-27 18:45:04'),(8,10,0,'TestCategory','{\"join\": [], \"menu\": {\"pid\": 2366, \"icon\": \"\", \"sort\": 1000}, \"tree\": {\"styleType\": 1, \"titleColumn\": null}, \"autoOps\": [\"genMenuPermissions\", \"runService\", \"genFuncDict\", \"forcedCover\"], \"headOps\": [\"add\", \"batchDel\"], \"funcDict\": {\"labelColumn\": \"name\", \"valueColumn\": \"id\"}, \"columnOps\": [\"edit\", \"del\", \"check\", \"status\"], \"presetStep\": {\"formGridCols\": 2}}','default','hg_test_category','测试分类','TestCategory','[{\"dc\": \"分类ID\", \"id\": 1, \"name\": \"id\", \"align\": \"left\", \"extra\": \"auto_increment\", \"index\": \"PRI\", \"width\": 80, \"goName\": \"Id\", \"goType\": \"int64\", \"isEdit\": false, \"isList\": true, \"isSort\": true, \"length\": 0, \"tsName\": \"id\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": true, \"required\": true, \"queryWhere\": \"=\", \"isAllowNull\": \"NO\", \"defaultValue\": 0, \"formGridSpan\": 2}, {\"dc\": \"分类名称\", \"id\": 2, \"name\": \"name\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"Name\", \"goType\": \"string\", \"isEdit\": true, \"isList\": true, \"isSort\": false, \"length\": 255, \"tsName\": \"name\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"varchar(255)\", \"dataType\": \"varchar\", \"dictType\": null, \"formMode\": \"Input\", \"formRole\": \"none\", \"isExport\": true, \"required\": true, \"queryWhere\": \"LIKE %...%\", \"isAllowNull\": \"NO\", \"defaultValue\": \"\", \"formGridSpan\": 2}, {\"dc\": \"简称\", \"id\": 3, \"name\": \"short_name\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 80, \"goName\": \"ShortName\", \"goType\": \"string\", \"isEdit\": true, \"isList\": true, \"isSort\": false, \"length\": 128, \"tsName\": \"shortName\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"varchar(128)\", \"dataType\": \"varchar\", \"dictType\": null, \"formMode\": \"Input\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"LIKE\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 2}, {\"dc\": \"描述\", \"id\": 3, \"name\": \"description\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 300, \"goName\": \"Description\", \"goType\": \"string\", \"isEdit\": true, \"isList\": true, \"isSort\": false, \"length\": 255, \"tsName\": \"description\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"varchar(255)\", \"dataType\": \"varchar\", \"dictType\": null, \"formMode\": \"InputTextarea\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"LIKE\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 2}, {\"dc\": \"排序\", \"id\": 4, \"name\": \"sort\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"Sort\", \"goType\": \"int\", \"isEdit\": true, \"isList\": false, \"isSort\": true, \"length\": 0, \"tsName\": \"sort\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"int(11)\", \"dataType\": \"int\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": true, \"required\": true, \"queryWhere\": \"=\", \"isAllowNull\": \"NO\", \"defaultValue\": 0, \"formGridSpan\": 1}, {\"dc\": \"状态\", \"id\": 6, \"name\": \"status\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"Status\", \"goType\": \"int\", \"isEdit\": true, \"isList\": true, \"isSort\": false, \"length\": 0, \"tsName\": \"status\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"tinyint(1)\", \"dataType\": \"tinyint\", \"dictType\": 3, \"formMode\": \"Select\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 1, \"formGridSpan\": 1}, {\"dc\": \"备注\", \"id\": 5, \"name\": \"remark\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"Remark\", \"goType\": \"string\", \"isEdit\": true, \"isList\": false, \"isSort\": false, \"length\": 255, \"tsName\": \"remark\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"varchar(255)\", \"dataType\": \"varchar\", \"dictType\": null, \"formMode\": \"InputTextarea\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"LIKE\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 2}, {\"dc\": \"创建时间\", \"id\": 7, \"name\": \"created_at\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 180, \"goName\": \"CreatedAt\", \"goType\": \"*gtime.Time\", \"isEdit\": false, \"isList\": true, \"isSort\": false, \"length\": 0, \"tsName\": \"createdAt\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"datetime\", \"dataType\": \"datetime\", \"dictType\": null, \"formMode\": \"TimeRange\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"BETWEEN\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}, {\"dc\": \"修改时间\", \"id\": 8, \"name\": \"updated_at\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"UpdatedAt\", \"goType\": \"*gtime.Time\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"updatedAt\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"datetime\", \"dataType\": \"datetime\", \"dictType\": null, \"formMode\": \"Time\", \"formRole\": \"none\", \"isExport\": false, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}, {\"dc\": \"删除时间\", \"id\": 9, \"name\": \"deleted_at\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"DeletedAt\", \"goType\": \"*gtime.Time\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"deletedAt\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"datetime\", \"dataType\": \"datetime\", \"dictType\": null, \"formMode\": \"Time\", \"formRole\": \"none\", \"isExport\": false, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}]','hgexample',1,'2024-04-08 15:18:07','2024-07-20 21:41:45'),(9,11,0,'NormalTreeDemo','{\"join\": [], \"menu\": {\"pid\": 2366, \"icon\": \"\", \"sort\": 200}, \"tree\": {\"styleType\": 1, \"titleColumn\": \"title\"}, \"autoOps\": [\"genMenuPermissions\", \"runDao\", \"runService\", \"forcedCover\"], \"headOps\": [\"add\", \"batchDel\"], \"funcDict\": {\"labelColumn\": null, \"valueColumn\": null}, \"columnOps\": [\"edit\", \"del\", \"check\"], \"presetStep\": {\"formGridCols\": 2}}','default','hg_sys_gen_tree_demo','普通树表','SysGenTreeDemo','[{\"dc\": \"标题\", \"id\": 6, \"name\": \"title\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 200, \"goName\": \"Title\", \"goType\": \"string\", \"isEdit\": true, \"isList\": true, \"isSort\": false, \"length\": 64, \"tsName\": \"title\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"varchar(64)\", \"dataType\": \"varchar\", \"dictType\": null, \"formMode\": \"Input\", \"formRole\": \"none\", \"isExport\": true, \"required\": true, \"queryWhere\": \"LIKE %...%\", \"isAllowNull\": \"NO\", \"defaultValue\": \"\", \"formGridSpan\": 2}, {\"dc\": \"ID\", \"id\": 1, \"name\": \"id\", \"align\": \"left\", \"extra\": \"auto_increment\", \"index\": \"PRI\", \"width\": 100, \"goName\": \"Id\", \"goType\": \"int64\", \"isEdit\": false, \"isList\": false, \"isSort\": true, \"length\": 0, \"tsName\": \"id\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": true, \"required\": true, \"queryWhere\": \"=\", \"isAllowNull\": \"NO\", \"defaultValue\": 0, \"formGridSpan\": 1}, {\"dc\": \"上级\", \"id\": 2, \"name\": \"pid\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"Pid\", \"goType\": \"int64\", \"isEdit\": true, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"pid\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 0, \"formGridSpan\": 2}, {\"dc\": \"关系树级别\", \"id\": 3, \"name\": \"level\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"Level\", \"goType\": \"int\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"level\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"int(11)\", \"dataType\": \"int\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": false, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 1, \"formGridSpan\": 1}, {\"dc\": \"关系树\", \"id\": 4, \"name\": \"tree\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"Tree\", \"goType\": \"string\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 4294967295, \"tsName\": \"tree\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"longtext\", \"dataType\": \"longtext\", \"dictType\": null, \"formMode\": \"InputEditor\", \"formRole\": \"none\", \"isExport\": false, \"required\": false, \"queryWhere\": \"LIKE %...%\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}, {\"dc\": \"测试分类\", \"id\": 5, \"name\": \"category_id\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"CategoryId\", \"goType\": \"int64\", \"isEdit\": true, \"isList\": true, \"isSort\": false, \"length\": 0, \"tsName\": \"categoryId\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": -300004223237244, \"formMode\": \"Select\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 0, \"formGridSpan\": 2}, {\"dc\": \"描述\", \"id\": 7, \"name\": \"description\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 300, \"goName\": \"Description\", \"goType\": \"string\", \"isEdit\": true, \"isList\": true, \"isSort\": false, \"length\": 255, \"tsName\": \"description\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"varchar(255)\", \"dataType\": \"varchar\", \"dictType\": null, \"formMode\": \"Input\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"LIKE\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 2}, {\"dc\": \"排序\", \"id\": 8, \"name\": \"sort\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"Sort\", \"goType\": \"int\", \"isEdit\": true, \"isList\": false, \"isSort\": true, \"length\": 0, \"tsName\": \"sort\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"int(11)\", \"dataType\": \"int\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 0, \"formGridSpan\": 1}, {\"dc\": \"状态\", \"id\": 9, \"name\": \"status\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 150, \"goName\": \"Status\", \"goType\": \"int\", \"isEdit\": true, \"isList\": true, \"isSort\": false, \"length\": 0, \"tsName\": \"status\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"tinyint(1)\", \"dataType\": \"tinyint\", \"dictType\": 3, \"formMode\": \"Select\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 1, \"formGridSpan\": 1}, {\"dc\": \"创建者\", \"id\": 10, \"name\": \"created_by\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"CreatedBy\", \"goType\": \"int64\", \"isEdit\": false, \"isList\": true, \"isSort\": false, \"length\": 0, \"tsName\": \"createdBy\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 0, \"formGridSpan\": 1}, {\"dc\": \"更新者\", \"id\": 11, \"name\": \"updated_by\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"UpdatedBy\", \"goType\": \"int64\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"updatedBy\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 0, \"formGridSpan\": 1}, {\"dc\": \"创建时间\", \"id\": 12, \"name\": \"created_at\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 180, \"goName\": \"CreatedAt\", \"goType\": \"*gtime.Time\", \"isEdit\": false, \"isList\": true, \"isSort\": false, \"length\": 0, \"tsName\": \"createdAt\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"datetime\", \"dataType\": \"datetime\", \"dictType\": null, \"formMode\": \"TimeRange\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"BETWEEN\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}, {\"dc\": \"修改时间\", \"id\": 13, \"name\": \"updated_at\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 180, \"goName\": \"UpdatedAt\", \"goType\": \"*gtime.Time\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"updatedAt\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"datetime\", \"dataType\": \"datetime\", \"dictType\": null, \"formMode\": \"Time\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}, {\"dc\": \"删除时间\", \"id\": 14, \"name\": \"deleted_at\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"DeletedAt\", \"goType\": \"*gtime.Time\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"deletedAt\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"datetime\", \"dataType\": \"datetime\", \"dictType\": null, \"formMode\": \"Time\", \"formRole\": \"none\", \"isExport\": false, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}]','',1,'2024-04-09 16:06:13','2024-07-25 16:34:59'),(10,11,0,'OptionTreeDemo','{\"join\": [], \"menu\": {\"pid\": 2366, \"icon\": \"\", \"sort\": 300}, \"tree\": {\"styleType\": 2, \"titleColumn\": \"title\"}, \"autoOps\": [\"genMenuPermissions\", \"runDao\", \"runService\", \"forcedCover\"], \"headOps\": [\"add\", \"batchDel\"], \"funcDict\": {\"labelColumn\": null, \"valueColumn\": null}, \"columnOps\": [\"edit\", \"del\", \"check\"], \"presetStep\": {\"formGridCols\": 2}}','default','hg_sys_gen_tree_demo','选项树表','SysGenTreeDemo','[{\"dc\": \"标题\", \"id\": 6, \"name\": \"title\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"Title\", \"goType\": \"string\", \"isEdit\": true, \"isList\": true, \"isSort\": false, \"length\": 64, \"tsName\": \"title\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"varchar(64)\", \"dataType\": \"varchar\", \"dictType\": null, \"formMode\": \"Input\", \"formRole\": \"none\", \"isExport\": true, \"required\": true, \"queryWhere\": \"LIKE %...%\", \"isAllowNull\": \"NO\", \"defaultValue\": \"\", \"formGridSpan\": 2}, {\"dc\": \"ID\", \"id\": 1, \"name\": \"id\", \"align\": \"left\", \"extra\": \"auto_increment\", \"index\": \"PRI\", \"width\": 100, \"goName\": \"Id\", \"goType\": \"int64\", \"isEdit\": false, \"isList\": false, \"isSort\": true, \"length\": 0, \"tsName\": \"id\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": true, \"required\": true, \"queryWhere\": \"=\", \"isAllowNull\": \"NO\", \"defaultValue\": 0, \"formGridSpan\": 1}, {\"dc\": \"上级\", \"id\": 2, \"name\": \"pid\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"Pid\", \"goType\": \"int64\", \"isEdit\": true, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"pid\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 0, \"formGridSpan\": 2}, {\"dc\": \"关系树级别\", \"id\": 3, \"name\": \"level\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"Level\", \"goType\": \"int\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"level\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"int(11)\", \"dataType\": \"int\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": false, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 1, \"formGridSpan\": 1}, {\"dc\": \"关系树\", \"id\": 4, \"name\": \"tree\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"Tree\", \"goType\": \"string\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 4294967295, \"tsName\": \"tree\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"longtext\", \"dataType\": \"longtext\", \"dictType\": 3, \"formMode\": \"SelectMultiple\", \"formRole\": \"none\", \"isExport\": false, \"required\": false, \"queryWhere\": \"LIKE %...%\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}, {\"dc\": \"测试分类\", \"id\": 5, \"name\": \"category_id\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"CategoryId\", \"goType\": \"int64\", \"isEdit\": true, \"isList\": true, \"isSort\": false, \"length\": 0, \"tsName\": \"categoryId\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": -300004223237244, \"formMode\": \"Select\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 0, \"formGridSpan\": 2}, {\"dc\": \"描述\", \"id\": 7, \"name\": \"description\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 300, \"goName\": \"Description\", \"goType\": \"string\", \"isEdit\": true, \"isList\": false, \"isSort\": false, \"length\": 255, \"tsName\": \"description\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"varchar(255)\", \"dataType\": \"varchar\", \"dictType\": null, \"formMode\": \"Input\", \"formRole\": \"none\", \"isExport\": false, \"required\": false, \"queryWhere\": \"LIKE\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 2}, {\"dc\": \"排序\", \"id\": 8, \"name\": \"sort\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"Sort\", \"goType\": \"int\", \"isEdit\": true, \"isList\": false, \"isSort\": true, \"length\": 0, \"tsName\": \"sort\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"int(11)\", \"dataType\": \"int\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 0, \"formGridSpan\": 1}, {\"dc\": \"状态\", \"id\": 9, \"name\": \"status\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 150, \"goName\": \"Status\", \"goType\": \"int\", \"isEdit\": true, \"isList\": true, \"isSort\": false, \"length\": 0, \"tsName\": \"status\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"tinyint(1)\", \"dataType\": \"tinyint\", \"dictType\": 3, \"formMode\": \"Select\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 1, \"formGridSpan\": 1}, {\"dc\": \"创建者\", \"id\": 10, \"name\": \"created_by\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"CreatedBy\", \"goType\": \"int64\", \"isEdit\": false, \"isList\": true, \"isSort\": false, \"length\": 0, \"tsName\": \"createdBy\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 0, \"formGridSpan\": 1}, {\"dc\": \"更新者\", \"id\": 11, \"name\": \"updated_by\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 100, \"goName\": \"UpdatedBy\", \"goType\": \"int64\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"updatedBy\", \"tsType\": \"number\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"bigint(20)\", \"dataType\": \"bigint\", \"dictType\": null, \"formMode\": \"InputNumber\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": 0, \"formGridSpan\": 1}, {\"dc\": \"创建时间\", \"id\": 12, \"name\": \"created_at\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 180, \"goName\": \"CreatedAt\", \"goType\": \"*gtime.Time\", \"isEdit\": false, \"isList\": true, \"isSort\": false, \"length\": 0, \"tsName\": \"createdAt\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": true, \"sqlType\": \"datetime\", \"dataType\": \"datetime\", \"dictType\": null, \"formMode\": \"TimeRange\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"BETWEEN\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}, {\"dc\": \"修改时间\", \"id\": 13, \"name\": \"updated_at\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": 180, \"goName\": \"UpdatedAt\", \"goType\": \"*gtime.Time\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"updatedAt\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"datetime\", \"dataType\": \"datetime\", \"dictType\": null, \"formMode\": \"Time\", \"formRole\": \"none\", \"isExport\": true, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}, {\"dc\": \"删除时间\", \"id\": 14, \"name\": \"deleted_at\", \"align\": \"left\", \"extra\": \"\", \"index\": \"\", \"width\": null, \"goName\": \"DeletedAt\", \"goType\": \"*gtime.Time\", \"isEdit\": false, \"isList\": false, \"isSort\": false, \"length\": 0, \"tsName\": \"deletedAt\", \"tsType\": \"string\", \"unique\": false, \"isQuery\": false, \"sqlType\": \"datetime\", \"dataType\": \"datetime\", \"dictType\": null, \"formMode\": \"Time\", \"formRole\": \"none\", \"isExport\": false, \"required\": false, \"queryWhere\": \"=\", \"isAllowNull\": \"YES\", \"defaultValue\": \"\", \"formGridSpan\": 1}]','',1,'2024-04-09 17:20:33','2024-07-25 16:35:34');
/*!40000 ALTER TABLE `hg_sys_gen_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hg_addon_hgexample_table`
--

DROP TABLE IF EXISTS `hg_addon_hgexample_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hg_addon_hgexample_table` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` bigint DEFAULT '0' COMMENT '上级ID',
  `level` int DEFAULT '1' COMMENT '树等级',
  `tree` varchar(512) DEFAULT NULL COMMENT '关系树',
  `category_id` bigint DEFAULT NULL COMMENT '分类ID',
  `flag` json DEFAULT NULL COMMENT '标签',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `content` longtext COMMENT '内容',
  `image` varchar(255) DEFAULT NULL COMMENT '单图',
  `images` json DEFAULT NULL COMMENT '多图',
  `attachfile` varchar(255) DEFAULT NULL COMMENT '附件',
  `attachfiles` json DEFAULT NULL COMMENT '多附件',
  `map` json DEFAULT NULL COMMENT '动态键值对',
  `star` decimal(5,1) DEFAULT '0.0' COMMENT '推荐星',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
  `views` bigint DEFAULT NULL COMMENT '浏览次数',
  `activity_at` date DEFAULT NULL COMMENT '活动时间',
  `start_at` datetime DEFAULT NULL COMMENT '开启时间',
  `end_at` datetime DEFAULT NULL COMMENT '结束时间',
  `switch` tinyint(1) DEFAULT NULL COMMENT '开关',
  `sort` int DEFAULT NULL COMMENT '排序',
  `avatar` varchar(255) DEFAULT '' COMMENT '头像',
  `sex` tinyint(1) DEFAULT NULL COMMENT '性别',
  `qq` varchar(20) DEFAULT '' COMMENT 'qq',
  `email` varchar(60) DEFAULT '' COMMENT '邮箱',
  `mobile` varchar(20) DEFAULT '' COMMENT '手机号码',
  `hobby` json DEFAULT NULL COMMENT '爱好',
  `channel` int DEFAULT '1' COMMENT '渠道',
  `city_id` bigint DEFAULT '0' COMMENT '所在城市',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态',
  `created_by` bigint DEFAULT '0' COMMENT '创建者',
  `updated_by` bigint DEFAULT '0' COMMENT '更新者',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='插件_案例_表格';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hg_addon_hgexample_table`
--

LOCK TABLES `hg_addon_hgexample_table` WRITE;
/*!40000 ALTER TABLE `hg_addon_hgexample_table` DISABLE KEYS */;
INSERT INTO `hg_addon_hgexample_table` VALUES (1,0,1,'',1,'[1, 2]','测试标题','描述','<p>这是内容............</p>','https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqamvhlq4w3ki6bl.webp','[\"https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqap5l9brk2lkavu.jpg\", \"https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqaqua7fw8ukbbp5.jpg\"]','http://localhost:8000/attachment/2023-07-18/cu54ama4z54oejf5xx.mp3','[\"https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqawg96ba4cuezvv.xlsx\", \"https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqaup19k9oznyixz.doc\"]','[{\"key\": \"qwe\", \"value\": \"123\"}, {\"key\": \"asd\", \"value\": \"456\"}]',3.0,88.00,10,'2022-12-23','2022-12-01 00:00:00','2022-12-31 23:59:59',1,20,'',15,'133814250','133814250@qq.com','15303830571','[3, 2, 1]',1,140406,'备注！',1,1,1,'2022-12-15 19:30:14','2023-07-18 20:05:45',NULL),(2,0,1,'',0,'[1]','测试2','描述','<h2><strong>不知道写点啥！</strong></h2><p><br></p><p><img src=\"https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqbknawlkgdttuxl.png\"></p>','https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqbmxmtaq06gbnqa.jpeg','[\"https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqborf529kf4cxbm.jpeg\"]','https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqawg96ba4cuezvv.xlsx','[\"https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqaup19k9oznyixz.doc\"]','{}',2.5,10.00,0,'2023-02-18',NULL,NULL,2,30,'',0,'','1561561@qq.com','15303830571','[2, 1]',3,140214,'',1,1,1,'2023-02-06 14:17:11','2023-11-13 17:18:18',NULL),(3,1,2,'tr_1 ',0,'[1]','AAA','','','https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqamvhlq4w3ki6bl.webp','[\"https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqborf529kf4cxbm.jpeg\"]','','{}','{}',1.0,10.00,0,'2023-11-13',NULL,NULL,1,40,'',0,'13311','1331@qq.cc','15303830571','{}',0,0,'',1,1,1,'2023-11-13 17:34:42','2023-11-13 17:55:26',NULL),(4,1,2,'tr_1 ',0,'[1]','BBB','','','https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqamvhlq4w3ki6bl.webp','[\"https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqborf529kf4cxbm.jpeg\"]','','{}','{}',2.5,10.00,0,'2023-11-13',NULL,NULL,0,50,'',0,'12212','165165@q.cc','15303830561','{}',0,0,'',1,1,1,'2023-11-13 17:43:58','2023-11-13 17:43:58',NULL),(5,3,3,'tr_1 tr_3',0,'[1]','A1','','','https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqamvhlq4w3ki6bl.webp','[\"https://gmycos.facms.cn/hotgo/attachment/2023-02-09/cqdqborf529kf4cxbm.jpeg\"]','','{}','{}',1.0,10.00,0,'2023-11-13',NULL,NULL,1,60,'',0,'10121212','122112@qq.cc','15303830571','{}',3,0,'',1,1,1,'2023-11-13 17:45:22','2024-07-21 21:55:01',NULL);
/*!40000 ALTER TABLE `hg_addon_hgexample_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hg_addon_hgexample_tenant_order`
--

DROP TABLE IF EXISTS `hg_addon_hgexample_tenant_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hg_addon_hgexample_tenant_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tenant_id` bigint DEFAULT NULL COMMENT '租户ID',
  `merchant_id` bigint NOT NULL COMMENT '商户ID',
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `product_name` varchar(255) DEFAULT NULL COMMENT '购买产品',
  `order_sn` varchar(64) DEFAULT NULL COMMENT '订单号',
  `money` decimal(10,2) NOT NULL COMMENT '充值金额',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `status` tinyint DEFAULT '1' COMMENT '订单状态',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `order_sn` (`order_sn`),
  KEY `member_id` (`user_id`),
  KEY `merchant_id` (`merchant_id`),
  KEY `agent_id` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='多租户_充值订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hg_addon_hgexample_tenant_order`
--

LOCK TABLES `hg_addon_hgexample_tenant_order` WRITE;
/*!40000 ALTER TABLE `hg_addon_hgexample_tenant_order` DISABLE KEYS */;
INSERT INTO `hg_addon_hgexample_tenant_order` VALUES (1,8,11,12,'羊毛混纺大衣','20230502074731zsv1Vh',99.90,'',1,'2024-04-10 00:00:00','2024-04-19 00:00:00');
/*!40000 ALTER TABLE `hg_addon_hgexample_tenant_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hg_sys_addons_config`
--

DROP TABLE IF EXISTS `hg_sys_addons_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hg_sys_addons_config` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `addon_name` varchar(128) NOT NULL COMMENT '插件名称',
  `group` varchar(128) NOT NULL COMMENT '分组',
  `name` varchar(100) DEFAULT '' COMMENT '参数名称',
  `type` varchar(32) NOT NULL COMMENT '键值类型:string,int,uint,bool,datetime,date',
  `key` varchar(100) DEFAULT '' COMMENT '参数键名',
  `value` varchar(500) DEFAULT '' COMMENT '参数键值',
  `default_value` varchar(500) NOT NULL COMMENT '默认值',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `tip` varchar(500) DEFAULT NULL COMMENT '变量描述',
  `is_default` tinyint(1) DEFAULT '0' COMMENT '是否为系统默认',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `addon_name_2` (`addon_name`,`key`),
  KEY `addon_name` (`addon_name`),
  KEY `addon_name_3` (`addon_name`,`group`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统_插件配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hg_sys_addons_config`
--

LOCK TABLES `hg_sys_addons_config` WRITE;
/*!40000 ALTER TABLE `hg_sys_addons_config` DISABLE KEYS */;
INSERT INTO `hg_sys_addons_config` VALUES (1,'hgexample','basic','测试参数','string','basicTest','HotGo','HotGo',10,'测试参数，可以按需添加配置自定义参数',0,1,'2023-02-14 10:56:01','2024-07-21 21:54:49');
/*!40000 ALTER TABLE `hg_sys_addons_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hg_sys_addons_install`
--

DROP TABLE IF EXISTS `hg_sys_addons_install`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hg_sys_addons_install` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) NOT NULL COMMENT '插件名称',
  `version` varchar(128) NOT NULL DEFAULT '' COMMENT '版本号',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统_插件安装记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hg_sys_addons_install`
--

LOCK TABLES `hg_sys_addons_install` WRITE;
/*!40000 ALTER TABLE `hg_sys_addons_install` DISABLE KEYS */;
INSERT INTO `hg_sys_addons_install` VALUES (1,'hgexample','v1.0.0',1,'2023-02-02 00:00:00','2024-07-21 19:05:44');
/*!40000 ALTER TABLE `hg_sys_addons_install` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hg_admin_cash`
--

DROP TABLE IF EXISTS `hg_admin_cash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hg_admin_cash` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `member_id` bigint NOT NULL COMMENT '管理员ID',
  `money` decimal(10,2) NOT NULL COMMENT '提现金额',
  `fee` decimal(10,2) NOT NULL COMMENT '手续费',
  `last_money` decimal(10,2) NOT NULL COMMENT '最终到账金额',
  `ip` varchar(128) NOT NULL COMMENT '申请人IP',
  `status` bigint NOT NULL COMMENT '状态码',
  `msg` varchar(128) DEFAULT NULL COMMENT '处理结果',
  `handle_at` datetime DEFAULT NULL COMMENT '处理时间',
  `created_at` datetime NOT NULL COMMENT '申请时间',
  PRIMARY KEY (`id`),
  KEY `admin_id` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='管理员_提现记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hg_admin_cash`
--

LOCK TABLES `hg_admin_cash` WRITE;
/*!40000 ALTER TABLE `hg_admin_cash` DISABLE KEYS */;
INSERT INTO `hg_admin_cash` VALUES (1,1,100.00,3.00,97.00,'127.0.0.1',2,'','2023-05-29 14:17:17','2023-05-29 14:16:57');
/*!40000 ALTER TABLE `hg_admin_cash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hg_admin_credits_log`
--

DROP TABLE IF EXISTS `hg_admin_credits_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hg_admin_credits_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '变动ID',
  `member_id` bigint DEFAULT '0' COMMENT '管理员ID',
  `app_id` varchar(64) DEFAULT NULL COMMENT '应用id',
  `addons_name` varchar(100) NOT NULL DEFAULT '' COMMENT '插件名称',
  `credit_type` varchar(32) NOT NULL DEFAULT '' COMMENT '变动类型',
  `credit_group` varchar(32) DEFAULT NULL COMMENT '变动组别',
  `before_num` decimal(10,2) DEFAULT '0.00' COMMENT '变动前',
  `num` decimal(10,2) DEFAULT '0.00' COMMENT '变动数据',
  `after_num` decimal(10,2) DEFAULT '0.00' COMMENT '变动后',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `ip` varchar(20) DEFAULT NULL COMMENT '操作人IP',
  `map_id` bigint DEFAULT '0' COMMENT '关联ID',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='管理员_资产变动表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hg_admin_credits_log`
--

LOCK TABLES `hg_admin_credits_log` WRITE;
/*!40000 ALTER TABLE `hg_admin_credits_log` DISABLE KEYS */;
INSERT INTO `hg_admin_credits_log` VALUES (1,1,'admin','','balance','apply_cash',99391.78,-100.00,99291.78,'后台申请提现','127.0.0.1',1,0,'2023-05-29 14:16:57','2023-05-29 14:16:57'),(2,1,'admin','','balance','op_incr',99291.78,-1.00,99290.78,'为后台用户:8 操作增加余额:1','127.0.0.1',0,0,'2023-07-06 17:17:39','2023-07-06 17:17:39'),(3,8,'admin','','balance','incr',3.22,1.00,4.22,'后台用户:1 为你操作增加余额:1','127.0.0.1',0,0,'2023-07-06 17:17:39','2023-07-06 17:17:39'),(4,1,'admin','','balance','op_incr',99290.78,-1.00,99289.78,'为后台用户:13 操作增加余额:1','::1',0,1,'2024-07-21 21:49:40','2024-07-21 21:49:40'),(5,13,'admin','','balance','incr',0.00,1.00,1.00,'后台用户:1 为你操作增加余额:1','::1',0,1,'2024-07-21 21:49:40','2024-07-21 21:49:40'),(6,1,'admin','','integral','op_incr',89.00,-1.00,88.00,'为后台用户:12 操作增加积分:1','::1',0,1,'2024-07-21 21:49:46','2024-07-21 21:49:46'),(7,12,'admin','','integral','incr',0.00,1.00,1.00,'后台用户:1 为你操作增加积分:1','::1',0,1,'2024-07-21 21:49:46','2024-07-21 21:49:46');
/*!40000 ALTER TABLE `hg_admin_credits_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hg_admin_order`
--

DROP TABLE IF EXISTS `hg_admin_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hg_admin_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
  `member_id` bigint DEFAULT '0' COMMENT '管理员id',
  `order_type` varchar(32) NOT NULL COMMENT '订单类型',
  `product_id` bigint DEFAULT NULL COMMENT '产品id',
  `order_sn` varchar(64) DEFAULT '' COMMENT '关联订单号',
  `money` decimal(10,2) NOT NULL COMMENT '充值金额',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `refund_reason` varchar(255) DEFAULT NULL COMMENT '退款原因',
  `reject_refund_reason` varchar(255) DEFAULT NULL COMMENT '拒绝退款原因',
  `status` tinyint DEFAULT '1' COMMENT '状态',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `order_sn` (`order_sn`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='管理员_充值订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hg_admin_order`
--

LOCK TABLES `hg_admin_order` WRITE;
/*!40000 ALTER TABLE `hg_admin_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `hg_admin_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hg_pay_log`
--

DROP TABLE IF EXISTS `hg_pay_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hg_pay_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
  `member_id` bigint DEFAULT '0' COMMENT '会员ID',
  `app_id` varchar(50) DEFAULT NULL COMMENT '应用ID',
  `addons_name` varchar(100) DEFAULT '' COMMENT '插件名称',
  `order_sn` varchar(64) DEFAULT '' COMMENT '关联订单号',
  `order_group` varchar(32) DEFAULT '' COMMENT '组别[默认统一支付类型]',
  `openid` varchar(50) DEFAULT '' COMMENT 'openid',
  `mch_id` varchar(20) DEFAULT '' COMMENT '商户支付账户',
  `subject` varchar(255) DEFAULT NULL COMMENT '订单标题',
  `detail` json DEFAULT NULL COMMENT '支付商品详情',
  `auth_code` varchar(50) DEFAULT '' COMMENT '刷卡码',
  `out_trade_no` varchar(128) DEFAULT '' COMMENT '商户订单号',
  `transaction_id` varchar(128) DEFAULT NULL COMMENT '交易号',
  `pay_type` varchar(32) NOT NULL COMMENT '支付类型',
  `pay_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '支付金额',
  `actual_amount` decimal(10,2) DEFAULT NULL COMMENT '实付金额',
  `pay_status` tinyint DEFAULT '0' COMMENT '支付状态',
  `pay_at` datetime DEFAULT NULL COMMENT '支付时间',
  `trade_type` varchar(16) DEFAULT '' COMMENT '交易类型',
  `refund_sn` varchar(128) DEFAULT NULL COMMENT '退款单号',
  `is_refund` tinyint DEFAULT '0' COMMENT '是否退款 ',
  `custom` text COMMENT '自定义参数',
  `create_ip` varchar(128) DEFAULT NULL COMMENT '创建者IP',
  `pay_ip` varchar(128) DEFAULT NULL COMMENT '支付者IP',
  `notify_url` varchar(255) DEFAULT NULL COMMENT '支付通知回调地址',
  `return_url` varchar(255) DEFAULT NULL COMMENT '买家付款成功跳转地址',
  `trace_ids` json DEFAULT NULL COMMENT '链路ID集合',
  `status` tinyint DEFAULT '1' COMMENT '状态',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_sn` (`order_sn`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='支付_支付日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hg_pay_log`
--

LOCK TABLES `hg_pay_log` WRITE;
/*!40000 ALTER TABLE `hg_pay_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `hg_pay_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hg_pay_refund`
--

DROP TABLE IF EXISTS `hg_pay_refund`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hg_pay_refund` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `member_id` bigint DEFAULT '0' COMMENT '会员ID',
  `app_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '应用ID',
  `order_sn` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '业务订单号',
  `refund_trade_no` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '退款交易号',
  `refund_money` decimal(10,2) DEFAULT NULL COMMENT '退款金额',
  `refund_way` tinyint DEFAULT '1' COMMENT '退款方式',
  `ip` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '申请者IP',
  `reason` varchar(255) DEFAULT NULL COMMENT '申请退款原因',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '退款备注',
  `status` tinyint DEFAULT '1' COMMENT '退款状态',
  `created_at` datetime DEFAULT NULL COMMENT '申请时间',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `order_sn` (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='支付_退款记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hg_pay_refund`
--

LOCK TABLES `hg_pay_refund` WRITE;
/*!40000 ALTER TABLE `hg_pay_refund` DISABLE KEYS */;
/*!40000 ALTER TABLE `hg_pay_refund` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-12 18:37:01
